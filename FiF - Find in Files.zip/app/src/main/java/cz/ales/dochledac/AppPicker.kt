package cz.ales.dochledac

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Otevírání souborů v jiných aplikacích. Pro každý typ souboru (TXT, PDF…) si lze zapamatovat
 * vlastní výchozí aplikaci – nezávisle na tom, co má nastavené systém.
 */
object AppPicker {
    private fun baseIntent(act: AppCompatActivity, doc: Doc): Intent {
        val uri = shareableUri(act, doc)
        return Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, Formats.mime(doc.ext))
            .addFlags(grantFlags(act, doc, uri))
    }

    /**
     * Tlačítko ↗: výchozí aplikace podle systému. Jen když si uživatel v DocHledači výslovně
     * zvolil jinou (přes ⋮), použije se ta.
     */
    fun openDefault(act: AppCompatActivity, doc: Doc) {
        val app = act.application as App
        val key = Formats.key(doc.ext)
        val saved = app.prefs.getOpenWith(key)
        val base = try {
            baseIntent(act, doc)
        } catch (e: Exception) {
            Toast.makeText(act, R.string.no_app, Toast.LENGTH_SHORT).show()
            return
        }
        if (saved != null) {
            try {
                act.startActivity(Intent(base).setClassName(saved.first, saved.second))
                return
            } catch (e: Exception) {
                app.prefs.setOpenWith(key, null) // aplikace byla odinstalována
            }
        }
        try {
            act.startActivity(base) // Android použije výchozí aplikaci, nebo se sám zeptá
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(act, R.string.no_app, Toast.LENGTH_SHORT).show()
        }
    }

    /** Výběr aplikace; rememberChecked = předvyplněné „vždy otevírat v této aplikaci“. */
    fun pick(act: AppCompatActivity, doc: Doc, rememberChecked: Boolean) {
        val app = act.application as App
        val key = Formats.key(doc.ext)
        val base = try {
            baseIntent(act, doc)
        } catch (e: Exception) {
            Toast.makeText(act, R.string.no_app, Toast.LENGTH_SHORT).show()
            return
        }
        val pm = act.packageManager
        val apps = pm.queryIntentActivities(base, PackageManager.MATCH_DEFAULT_ONLY)
            .filter { it.activityInfo.packageName != act.packageName }
            .distinctBy { it.activityInfo.packageName + "/" + it.activityInfo.name }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        if (apps.isEmpty()) {
            Toast.makeText(act, R.string.no_app, Toast.LENGTH_SHORT).show()
            return
        }
        val dp = act.resources.displayMetrics.density
        val list = ListView(act)
        list.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(position: Int): Any = apps[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val ri: ResolveInfo = apps[position]
                val row = LinearLayout(act).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    val p = (12 * dp).toInt()
                    setPadding((24 * dp).toInt(), p, p, p)
                }
                val icon = ImageView(act).apply { setImageDrawable(ri.loadIcon(pm)) }
                row.addView(icon, LinearLayout.LayoutParams((36 * dp).toInt(), (36 * dp).toInt()))
                row.addView(TextView(act).apply {
                    text = ri.loadLabel(pm)
                    textSize = 16f
                    setPadding((16 * dp).toInt(), 0, 0, 0)
                })
                return row
            }
        }
        val remember = MaterialCheckBox(act).apply {
            text = act.getString(R.string.picker_remember, doc.ext.uppercase())
            isChecked = rememberChecked
        }
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        box.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        box.addView(remember, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            marginStart = (16 * dp).toInt()
        })
        box.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (minOf(apps.size, 6) * 62 * dp + 60 * dp).toInt())
        val dialog = MaterialAlertDialogBuilder(act)
            .setTitle(R.string.open_with)
            .setView(box)
            .setNegativeButton(R.string.cancel, null)
            .create()
        list.setOnItemClickListener { _, _, position, _ ->
            val ai = apps[position].activityInfo
            if (remember.isChecked) app.prefs.setOpenWith(key, ai.packageName to ai.name)
            dialog.dismiss()
            try {
                act.startActivity(Intent(base).setClassName(ai.packageName, ai.name))
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(act, R.string.no_app, Toast.LENGTH_SHORT).show()
            } catch (e: SecurityException) {
                Toast.makeText(act, R.string.no_app, Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
        // výšku seznamu omezíme, aby se checkbox vešel pod něj
        val h = (minOf(apps.size, 6) * 62 * dp + 60 * dp).toInt()
        box.layoutParams = box.layoutParams.apply { height = h }
    }

    /** Popisek zapamatované aplikace pro Nastavení. */
    fun label(act: AppCompatActivity, pkg: String, cls: String): String = try {
        val pm = act.packageManager
        pm.getActivityInfo(android.content.ComponentName(pkg, cls), 0).loadLabel(pm).toString()
    } catch (e: Exception) {
        pkg
    }
}
