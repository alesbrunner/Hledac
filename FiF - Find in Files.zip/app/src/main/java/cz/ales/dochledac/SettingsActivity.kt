package cz.ales.dochledac

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.provider.DocumentsContract
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import android.view.View
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class SettingsActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_ADD_FOLDER = "addFolder"
    }

    private val app get() = application as App
    private lateinit var foldersBox: LinearLayout
    private lateinit var excludedBox: LinearLayout
    private lateinit var appsBox: LinearLayout
    private lateinit var stats: TextView
    private lateinit var indexStatus: TextView
    private lateinit var progress: ProgressBar
    private var dirty = false
    private var waitingForAllFiles = false
    private var lastVersion = -1

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) onFolderPicked(uri)
    }
    private val askReadPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) browseStorage()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupScreen(R.layout.activity_settings, true)
        supportActionBar?.setTitle(R.string.settings)

        foldersBox = findViewById(R.id.folders)
        excludedBox = findViewById(R.id.excluded)
        appsBox = findViewById(R.id.openApps)
        stats = findViewById(R.id.stats)
        indexStatus = findViewById(R.id.indexStatus)
        progress = findViewById(R.id.progress)

        findViewById<Button>(R.id.addFolder).setOnClickListener { chooseAddMethod() }
        findViewById<Button>(R.id.addExcludedFolder).setOnClickListener { browseExcluded() }
        findViewById<Button>(R.id.addExcludedName).setOnClickListener { askExcludedName() }

        // formáty
        val formatsBox = findViewById<LinearLayout>(R.id.formats)
        val selected = app.prefs.exts.toMutableSet()
        val summary = findViewById<TextView>(R.id.formatsSummary)
        fun updateSummary() {
            val all = Formats.GROUPS.flatMap { it.formats }
            val on = all.filter { it.key in selected }.map { it.key.uppercase() }
            summary.text = getString(R.string.formats_summary, on.size, all.size, on.joinToString(", "))
        }
        updateSummary()
        findViewById<View>(R.id.formatsHeader).setOnClickListener {
            val open = formatsBox.visibility != View.VISIBLE
            formatsBox.visibility = if (open) View.VISIBLE else View.GONE
            findViewById<View>(R.id.formatsArrow).animate().rotation(if (open) 180f else 0f).setDuration(150).start()
        }
        for (g in Formats.GROUPS) {
            formatsBox.addView(TextView(this).apply {
                setText(g.title)
                textSize = 13f
                alpha = 0.7f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, (10 * resources.displayMetrics.density).toInt(), 0, 0)
            })
            for (f in g.formats) {
            val cb = MaterialCheckBox(this)
            cb.setText(f.label)
            cb.isChecked = f.key in selected
            cb.setOnCheckedChangeListener { _, on ->
                if (on) selected.add(f.key) else selected.remove(f.key)
                app.prefs.exts = selected
                dirty = true
                updateSummary()
            }
            formatsBox.addView(cb)
            }
        }

        val stem = findViewById<MaterialSwitch>(R.id.stem)
        stem.isChecked = app.prefs.stem
        stem.setOnCheckedChangeListener { _, on -> app.prefs.stem = on }

        val ocr = findViewById<MaterialSwitch>(R.id.ocr)
        ocr.isChecked = app.prefs.ocr
        ocr.setOnCheckedChangeListener { _, on ->
            app.prefs.ocr = on
            dirty = true
            if (on) lifecycleScope.launch(Dispatchers.IO) { Repo.markScannedPdfsDirty(app) }
        }

        // vzhled
        val theme = findViewById<RadioGroup>(R.id.themeGroup)
        theme.check(
            when (app.prefs.theme) {
                ThemeMode.LIGHT -> R.id.themeLight
                ThemeMode.DARK -> R.id.themeDark
                ThemeMode.SUN -> R.id.themeSun
                else -> R.id.themeSystem
            }
        )
        val (sunrise, sunset) = Sun.times()
        findViewById<TextView>(R.id.themeSunNote).text = getString(R.string.theme_sun_note, Sun.fmt(sunrise), Sun.fmt(sunset))
        theme.setOnCheckedChangeListener { _, id ->
            app.prefs.theme = when (id) {
                R.id.themeLight -> ThemeMode.LIGHT
                R.id.themeDark -> ThemeMode.DARK
                R.id.themeSun -> ThemeMode.SUN
                else -> ThemeMode.SYSTEM
            }
            ThemeMode.apply(app)
        }

        // indexace
        val auto = findViewById<MaterialSwitch>(R.id.auto)
        auto.isChecked = app.prefs.autoUpdate
        auto.setOnCheckedChangeListener { _, on -> app.prefs.autoUpdate = on }

        val bg = findViewById<RadioGroup>(R.id.bgGroup)
        bg.check(
            when (app.prefs.bgHours) {
                6 -> R.id.bg6
                12 -> R.id.bg12
                24 -> R.id.bg24
                else -> R.id.bgOff
            }
        )
        bg.setOnCheckedChangeListener { _, id ->
            app.prefs.bgHours = when (id) {
                R.id.bg6 -> 6
                R.id.bg12 -> 12
                R.id.bg24 -> 24
                else -> 0
            }
            BgIndex.apply(this)
        }
        val charging = findViewById<MaterialSwitch>(R.id.bgCharging)
        charging.isChecked = app.prefs.bgChargingOnly
        charging.setOnCheckedChangeListener { _, on ->
            app.prefs.bgChargingOnly = on
            BgIndex.apply(this)
        }

        findViewById<Button>(R.id.reindex).setOnClickListener {
            dirty = false
            Indexer.start(this)
        }
        findViewById<Button>(R.id.clear).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.clear_title)
                .setMessage(R.string.clear_msg)
                .setPositiveButton(R.string.clear_ok) { _, _ -> Indexer.clearIndex(app) }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Indexer.state.collect { s ->
                    progress.visibility = if (s.running) android.view.View.VISIBLE else android.view.View.GONE
                    if (s.running) {
                        if (s.total > 0) {
                            progress.isIndeterminate = false
                            progress.max = s.total
                            progress.progress = s.done
                        } else {
                            progress.isIndeterminate = true
                        }
                    }
                    indexStatus.text = s.message
                    if (s.version != lastVersion) {
                        lastVersion = s.version
                        refreshStats()
                    }
                }
            }
        }

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        findViewById<TextView>(R.id.about).text = getString(R.string.about_text, version)

        renderFolders()
        renderExcluded()
        // z hlavní obrazovky („+ Přidat složku“) rovnou otevřít výběr složky
        if (savedInstanceState == null && intent.getBooleanExtra(EXTRA_ADD_FOLDER, false)) chooseAddMethod()
    }

    override fun onResume() {
        super.onResume()
        if (waitingForAllFiles) {
            waitingForAllFiles = false
            if (Paths.hasAllFilesAccess()) browseStorage()
        }
        renderFolders()
        renderApps()
    }

    private fun renderApps() {
        appsBox.removeAllViews()
        val entries = app.prefs.openWith.sorted()
        if (entries.isEmpty()) emptyNote(appsBox, R.string.no_open_apps)
        for (e in entries) {
            val parts = e.split('|')
            if (parts.size != 3) continue
            val label = parts[0].uppercase() + " → " + AppPicker.label(this, parts[1], parts[2])
            row(appsBox, label) {
                app.prefs.setOpenWith(parts[0], null)
                renderApps()
            }
        }
    }

    // ---------- přidání složky ----------

    private fun chooseAddMethod() {
        // s přístupem ke všem souborům stačí vlastní prohlížeč – umí všechno, co systémový výběr
        val full = if (Build.VERSION.SDK_INT >= 30) Paths.hasAllFilesAccess()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        if (full) {
            browseStorage()
            return
        }
        val items = arrayOf(getString(R.string.add_folder_saf), getString(R.string.add_folder_all))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_folder_title)
            .setItems(items) { _, which -> if (which == 0) pickFolder.launch(null) else ensureAllFiles() }
            .show()
    }

    /** Celé úložiště a Download Android zpřístupní jen s oprávněním „Přístup ke všem souborům“. */
    private fun ensureAllFiles() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Paths.hasAllFilesAccess()) {
                browseStorage()
                return
            }
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.all_files_title)
                .setMessage(R.string.all_files_msg)
                .setPositiveButton(R.string.open_settings) { _, _ ->
                    waitingForAllFiles = true
                    try {
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                        )
                    } catch (e: Exception) {
                        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        } else {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) browseStorage()
            else askReadPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun browseStorage() {
        val roots = Paths.storageRoots(this).map {
            val l = Paths.labelOfFile(this, it.absolutePath)
            FolderBrowser.FileNode(it, l, l)
        }
        FolderBrowser(this, roots, true, R.string.browse_storage_title) { node ->
            if (node is FolderBrowser.FileNode) {
                val f = Uri.fromFile(node.file).toString()
                val folders = app.prefs.folders
                if (f !in folders) app.prefs.folders = folders + f
                renderFolders()
                Indexer.start(this)
            }
        }.show()
    }

    /** Vyloučit lze jen podsložku některé z vybraných složek. */
    private fun browseExcluded() {
        val folders = app.prefs.folders
        if (folders.isEmpty()) {
            Toast.makeText(this, R.string.excl_need_folder, Toast.LENGTH_SHORT).show()
            return
        }
        val roots = ArrayList<FolderBrowser.Node>()
        for (f in folders) {
            val label = Paths.folderLabel(this, f)
            if (Paths.isFile(f)) {
                roots.add(FolderBrowser.FileNode(File(Paths.filePath(f)), label, label))
            } else {
                try {
                    val tree = Uri.parse(f)
                    roots.add(FolderBrowser.SafNode(tree, DocumentsContract.getTreeDocumentId(tree), label, label))
                } catch (e: Exception) {
                }
            }
        }
        FolderBrowser(this, roots, false, R.string.excl_browse_title) { node ->
            when (node) {
                is FolderBrowser.SafNode -> addExcluded("id:" + node.docId)
                is FolderBrowser.FileNode -> addExcluded("path:" + node.file.absolutePath)
            }
        }.show()
    }

    override fun onStop() {
        super.onStop()
        if (dirty) {
            dirty = false
            Indexer.start(this)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun refreshStats() {
        lifecycleScope.launch {
            val (n, chars) = withContext(Dispatchers.IO) { Repo.stats(app) }
            stats.text = getString(R.string.status_index, qty(R.plurals.files, n), formatChars(this@SettingsActivity, chars))
        }
    }

    private fun onFolderPicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // některé správce souborů trvalé oprávnění nenabízí
        }
        val folders = app.prefs.folders
        if (uri.toString() !in folders) app.prefs.folders = folders + uri.toString()
        renderFolders()
        Indexer.start(this)
    }

    private fun removeFolder(f: String) {
        if (!Paths.isFile(f)) {
            try {
                contentResolver.releasePersistableUriPermission(Uri.parse(f), Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
        }
        app.prefs.folders = app.prefs.folders - f
        renderFolders()
        Indexer.start(this)
    }

    private fun askExcludedName() {
        val input = EditText(this)
        input.setSingleLine()
        input.setHint(R.string.excl_name_hint)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.excl_name_title)
            .setMessage(R.string.excl_name_msg)
            .setView(box)
            .setPositiveButton(R.string.add) { _, _ ->
                val n = input.text.toString().trim().trim('/').lowercase()
                if (n.isNotEmpty()) addExcluded("name:$n")
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun addExcluded(e: String) {
        app.prefs.excluded = app.prefs.excluded + e
        renderExcluded()
        dirty = true
    }

    private fun removeExcluded(e: String) {
        app.prefs.excluded = app.prefs.excluded - e
        renderExcluded()
        dirty = true
    }

    private fun row(box: LinearLayout, label: String, onRemove: () -> Unit) {
        val dp = resources.displayMetrics.density
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(this).apply {
            text = label
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        // obrysové tlačítko s červeným textem
        val rm = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            setText(R.string.remove)
            setTextColor(getColor(R.color.danger))
            setOnClickListener { onRemove() }
        }
        r.addView(tv)
        r.addView(rm)
        box.addView(r)
    }

    private fun emptyNote(box: LinearLayout, res: Int) {
        box.addView(TextView(this).apply {
            setText(res)
            alpha = 0.7f
            setPadding(0, 8, 0, 8)
        })
    }

    private fun renderFolders() {
        foldersBox.removeAllViews()
        val folders = app.prefs.folders
        val granted = contentResolver.persistedUriPermissions.map { it.uri.toString() }.toSet()
        if (folders.isEmpty()) emptyNote(foldersBox, R.string.no_folders)
        for (f in folders) {
            val ok = if (Paths.isFile(f)) Paths.hasAllFilesAccess() else f in granted
            val label = Paths.folderLabel(this, f) + (if (!ok) "  " + getString(R.string.folder_no_access) else "")
            row(foldersBox, label) {
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.remove_folder_title)
                    .setMessage(getString(R.string.remove_folder_msg, Paths.folderLabel(this, f)))
                    .setPositiveButton(R.string.remove) { _, _ -> removeFolder(f) }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
        }
    }

    private fun renderExcluded() {
        excludedBox.removeAllViews()
        val ex = app.prefs.excluded.sorted()
        if (ex.isEmpty()) emptyNote(excludedBox, R.string.no_excluded)
        for (e in ex) {
            val label = when {
                e.startsWith("id:") -> Paths.labelOfDocId(this, e.removePrefix("id:"))
                e.startsWith("path:") -> Paths.labelOfFile(this, e.removePrefix("path:"))
                else -> getString(R.string.excl_name_item, e.removePrefix("name:"))
            }
            row(excludedBox, label) { removeExcluded(e) }
        }
    }
}
