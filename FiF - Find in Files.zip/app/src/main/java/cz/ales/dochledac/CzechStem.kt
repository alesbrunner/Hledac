package cz.ales.dochledac

/**
 * Jednoduché hledání tvarů českých slov bez slovníku: odřízne pádovou koncovku
 * a ošetří pohyblivé „e“ (kotel → kotl, takže se najde kotle, kotlem, kotlu…).
 * Pracuje s normalizovaným textem (malá písmena bez diakritiky).
 */
object CzechStem {
    private val ENDINGS = listOf(
        "atech", "etem", "atum", "atum",
        "ovi", "ich", "imi", "iho", "emu", "ymi", "ych", "ymu", "eho", "ami", "ach", "ech", "ata", "aty",
        "ove", "ovy", "ama", "emi", "ama",
        "em", "es", "ho", "im", "mi", "om", "os", "ou", "um", "us", "ym", "mu", "at", "ej", "ou",
        "a", "e", "i", "o", "u", "y",
    ).distinct().sortedByDescending { it.length }

    private val MOBILE_E = Regex("^(.*[aeiouy][^aeiouy])e([lknrcz])$")

    /** Varianty pro hledání (vždy obsahuje původní slovo). */
    fun variants(tok: String): List<String> {
        val out = LinkedHashSet<String>()
        out.add(tok)
        if (tok.length < 4 || tok.any { it.isDigit() }) return out.toList()
        var stem = tok
        for (e in ENDINGS) {
            if (tok.length - e.length >= 3 && tok.endsWith(e)) {
                stem = tok.substring(0, tok.length - e.length)
                break
            }
        }
        if (stem != tok) out.add(stem)
        val m = MOBILE_E.find(stem)
        if (m != null) {
            val s = m.groupValues[1] + m.groupValues[2]
            if (s.length >= 3) out.add(s)
        }
        return out.toList()
    }
}
