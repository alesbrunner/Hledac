package cz.ales.dochledac

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.View

/**
 * Nápověda klepání v náhledu souboru: fialová záře u horního a dolního okraje s bílou šipkou.
 * Nahoře = klepnutím přeskočíš na předchozí výskyt, dole = na další. Dotyky nezachytává.
 */
class TapHint(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {
    private val dp = resources.displayMetrics.density
    private val glowH = 90 * dp
    private var top = false
    private var bottom = false

    private val glowPaint = Paint()
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 7 * dp
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        setShadowLayer(6 * dp, 0f, 0f, PURPLE)
    }
    private val path = Path()

    init {
        isClickable = false
        isFocusable = false
        // stín u čar kreslí hardwarová akcelerace až od Androidu 9
        if (Build.VERSION.SDK_INT < 28) setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    /** Ukáže nápovědu; [up] = horní část (předchozí), [down] = dolní (další). */
    fun show(up: Boolean, down: Boolean) {
        top = up
        bottom = down
        if (!up && !down) return
        animate().cancel()
        alpha = 0f
        visibility = VISIBLE
        animate().alpha(1f).setDuration(250).start()
    }

    fun dismiss() {
        if (visibility != VISIBLE) return
        animate().cancel()
        animate().alpha(0f).setDuration(200).withEndAction { visibility = GONE }.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val aw = minOf(200 * dp, w * 0.55f)
        val ah = 22 * dp
        if (top) {
            glowPaint.shader = LinearGradient(0f, 0f, 0f, glowH, GLOW, 0, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, glowH, glowPaint)
            val y = 14 * dp
            path.reset()
            path.moveTo(w / 2 - aw / 2, y + ah)
            path.lineTo(w / 2, y)
            path.lineTo(w / 2 + aw / 2, y + ah)
            canvas.drawPath(path, arrowPaint)
        }
        if (bottom) {
            glowPaint.shader = LinearGradient(0f, h, 0f, h - glowH, GLOW, 0, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, h - glowH, w, h, glowPaint)
            val y = h - 14 * dp
            path.reset()
            path.moveTo(w / 2 - aw / 2, y - ah)
            path.lineTo(w / 2, y)
            path.lineTo(w / 2 + aw / 2, y - ah)
            canvas.drawPath(path, arrowPaint)
        }
    }

    private companion object {
        val PURPLE = 0xFF6A1B9A.toInt()
        const val GLOW = 0x596A1B9A // asi 35 % fialové
    }
}
