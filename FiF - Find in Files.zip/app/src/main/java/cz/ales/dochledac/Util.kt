package cz.ales.dochledac

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import android.graphics.Color
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar
import java.io.File

fun Context.qty(res: Int, n: Int): String = resources.getQuantityString(res, n, n)

fun formatChars(ctx: Context, n: Long): String = when {
    n >= 1_000_000 -> ctx.getString(R.string.chars_millions, n / 1_000_000.0)
    n >= 1_000 -> ctx.getString(R.string.chars_thousands, (n / 1000).toInt())
    else -> n.toString()
}

/** Soubory z „přístupu ke všem souborům“ (file://) se jiným aplikacím předávají přes FileProvider. */
fun shareableUri(ctx: Context, doc: Doc): Uri {
    val u = Zips.materialize(ctx, doc.uri) // soubor z archivu se nejdřív rozbalí
    val path = u.path
    return if (u.scheme == "file" && path != null) FileProvider.getUriForFile(ctx, ctx.packageName + ".files", File(path)) else u
}

/** chooser = false → výchozí aplikace, true → vždy nabídnout výběr aplikace. */
fun openExternal(ctx: Context, doc: Doc, chooser: Boolean = false) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(shareableUri(ctx, doc), Formats.mime(doc.ext))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(if (chooser) Intent.createChooser(i, ctx.getString(R.string.open_with)) else i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, R.string.no_app, Toast.LENGTH_SHORT).show()
    } catch (e: IllegalArgumentException) {
        Toast.makeText(ctx, R.string.no_app, Toast.LENGTH_SHORT).show()
    }
}

fun Activity.hideKeyboard() {
    val v = currentFocus ?: return
    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
}

/**
 * Společné nastavení obrazovky: kreslení až k okrajům (vyžadováno od Androidu 15),
 * odsazení od systémových lišt a klávesnice, horní lišta.
 */
fun AppCompatActivity.setupScreen(layout: Int, up: Boolean) {
    // fialové záhlaví sahá až pod stavový řádek → světlé ikony stavového řádku
    enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT))
    setContentView(layout)
    val root = findViewById<View>(R.id.root)
    val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
    ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
        val b = insets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
        )
        v.setPadding(b.left, 0, b.right, b.bottom)
        toolbar.setPadding(toolbar.paddingLeft, b.top, toolbar.paddingRight, toolbar.paddingBottom)
        WindowInsetsCompat.CONSUMED
    }
    setSupportActionBar(toolbar)
    supportActionBar?.setDisplayHomeAsUpEnabled(up)
}

object Paths {
    /** "primary:Documents/Knihy" -> "Interní/Documents/Knihy" */
    fun labelOfDocId(ctx: Context, id: String): String {
        val vol = id.substringBefore(':')
        val rest = id.substringAfter(':', "")
        val v = if (vol == "primary") ctx.getString(R.string.storage_internal) else ctx.getString(R.string.storage_sd, vol)
        return if (rest.isEmpty()) v else "$v/$rest"
    }

    fun label(ctx: Context, tree: Uri): String = try {
        labelOfDocId(ctx, DocumentsContract.getTreeDocumentId(tree))
    } catch (e: Exception) {
        tree.toString()
    }

    /** Složka přidaná přes „přístup ke všem souborům“ se ukládá jako file:///… */
    fun isFile(folder: String): Boolean = folder.startsWith("file:")

    fun filePath(folder: String): String = Uri.parse(folder).path ?: folder

    /** "/storage/emulated/0/Download" -> "Interní/Download" */
    fun labelOfFile(ctx: Context, path: String): String {
        val internal = Environment.getExternalStorageDirectory().absolutePath
        return when {
            path.startsWith(internal) -> ctx.getString(R.string.storage_internal) + path.removePrefix(internal)
            path.startsWith("/storage/") -> {
                val rest = path.removePrefix("/storage/")
                val tail = rest.substringAfter('/', "")
                ctx.getString(R.string.storage_sd, rest.substringBefore('/')) + (if (tail.isEmpty()) "" else "/$tail")
            }
            else -> path
        }
    }

    /** Leží složka [inner] uvnitř složky [outer]? (podle popisků typu „Interní/Documents“) */
    fun contains(outer: String, inner: String): Boolean =
        inner.length > outer.length && inner.startsWith(outer) && inner[outer.length] == '/'

    fun folderLabel(ctx: Context, folder: String): String =
        if (isFile(folder)) labelOfFile(ctx, filePath(folder)) else label(ctx, Uri.parse(folder))

    /** Kořeny úložišť: interní paměť a SD karty. */
    fun storageRoots(ctx: Context): List<File> {
        val list = ArrayList<File>()
        list.add(Environment.getExternalStorageDirectory())
        for (d in ctx.getExternalFilesDirs(null)) {
            if (d == null) continue
            val p = d.absolutePath
            val i = p.indexOf("/Android/data/")
            if (i > 0) {
                val r = File(p.substring(0, i))
                if (list.none { it.absolutePath == r.absolutePath }) list.add(r)
            }
        }
        return list
    }

    /** Má aplikace „přístup ke všem souborům“? (Android 11+; starší verze řeší běžné oprávnění) */
    fun hasAllFilesAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
}
