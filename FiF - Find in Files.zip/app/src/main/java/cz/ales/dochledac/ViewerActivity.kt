package cz.ales.dochledac

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Spannable
import androidx.core.view.doOnPreDraw
import android.text.util.Linkify
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import android.text.style.ClickableSpan
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewTreeObserver
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.format.DateFormat
import android.text.format.Formatter
import com.google.android.material.slider.Slider
import java.util.Date
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Náhled celého textu souboru. Text se zobrazuje po blocích (CHUNK řádků v jednom poli),
 * takže jde souvisle označit a kopírovat přes mnoho řádků; odkazy jsou klikací.
 */
class ViewerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_DOC = "doc"
        const val EXTRA_QUERY = "q"
        const val EXTRA_MODE = "mode"
        const val EXTRA_LINE = "line"
        const val CHUNK = 40
        /** Do této velikosti je celý text v jednom poli – označování přes celý soubor, okamžité přeskoky. */
        const val SINGLE_MAX_LINES = 6000
        const val SINGLE_MAX_CHARS = 600_000
        const val CURRENT_HIT = 0xFFFF9800.toInt()
        /** Do kolika bloků (po 40 řádcích) se připraví celý text dopředu. */
        const val MAX_PRELOAD_CHUNKS = 150
    }

    private val app get() = application as App
    private var doc: Doc? = null
    private var dt: DocText? = null
    private var adapter: ChunkAdapter? = null
    private var hits: List<IntArray> = emptyList()   // všechny výskyty [pozice, délka], seřazené
    private var idx = -1
    private var mode = Query.MODE_WORDS
    private var findJob: Job? = null
    private lateinit var list: RecyclerView
    private lateinit var tapHint: TapHint
    /** Kolik řádků je v jednom poli: celý soubor (do SINGLE_MAX_*), jinak bloky po CHUNK řádcích. */
    private var chunk = CHUNK
    /** Šipky posunu se ukážou jen po otevření souboru a zmizí po prvním dotyku. */
    private var hintPending = false
    private var pendingPreDraw: ViewTreeObserver.OnPreDrawListener? = null
    private lateinit var counter: TextView
    private lateinit var find: EditText
    private lateinit var clearFind: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, R.anim.main_in, R.anim.viewer_out)
        }
        setupScreen(R.layout.activity_viewer, true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        findViewById<View>(R.id.titleBox).setOnClickListener { toggleInfo() }
        val slider = findViewById<Slider>(R.id.sizeSlider)
        slider.value = app.prefs.viewerTextSize.coerceIn(10f, 30f).roundToInt().toFloat()
        // velikost písma se použije až po puštění jezdce – přestavět celý text při každém posunu by se sekalo
        var sliding = false
        slider.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
            override fun onStartTrackingTouch(s: Slider) {
                sliding = true
            }

            override fun onStopTrackingTouch(s: Slider) {
                sliding = false
                setTextSize(s.value)
            }
        })
        slider.addOnChangeListener { _, value, fromUser -> if (fromUser && !sliding) setTextSize(value) }
        list = findViewById(R.id.lines)
        counter = findViewById(R.id.counter)
        find = findViewById(R.id.find)
        clearFind = findViewById(R.id.clearFind)
        list.layoutManager = NoJumpLayoutManager(this)
        list.itemAnimator = null
        list.setItemViewCacheSize(6) // nedávno odjeté bloky se při návratu nesestavují znovu
        tapHint = findViewById(R.id.tapHint)
        hintPending = savedInstanceState == null && app.prefs.tapHint
        setupTapZones() // bez prolínací animace – přepínání výsledků neposkakuje

        val id = intent.getLongExtra(EXTRA_DOC, -1)
        val q = savedInstanceState?.getString("q") ?: intent.getStringExtra(EXTRA_QUERY).orEmpty()
        val m = intent.getIntExtra(EXTRA_MODE, Query.MODE_WORDS)
        mode = if (m == Query.MODE_NAMES) Query.MODE_ANYWHERE else m
        val startLine = savedInstanceState?.getInt("line") ?: intent.getIntExtra(EXTRA_LINE, 0)
        find.setText(q)
        clearFind.setOnClickListener { find.setText("") }


        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.Default) {
                val d = Repo.doc(app, id) ?: return@withContext null
                d to DocText(Repo.loadText(app, id))
            }
            if (loaded == null) {
                finish()
                return@launch
            }
            show(loaded.first, loaded.second, startLine)
        }
    }

    private fun show(d: Doc, t: DocText, startLine: Int) {
        doc = d
        dt = t
        findViewById<TextView>(R.id.titleText).text = d.name
        findViewById<TextView>(R.id.infoName).text = d.name
        findViewById<TextView>(R.id.infoPath).text = d.path
        val date = DateFormat.getDateFormat(this).format(Date(d.mtime))
        findViewById<TextView>(R.id.infoMeta).text = getString(
            R.string.info_meta, d.ext.uppercase(), Formatter.formatShortFileSize(this, d.size), date,
            resources.getQuantityString(R.plurals.lines, t.lineCount, t.lineCount),
        )
        invalidateOptionsMenu()
        if (t.text.isEmpty()) {
            val msg = findViewById<TextView>(R.id.message)
            msg.visibility = View.VISIBLE
            msg.text = if (d.error != null) getString(R.string.viewer_read_error, d.error) else getString(R.string.viewer_no_text)
            findViewById<View>(R.id.findLayout).visibility = View.GONE
            return
        }
        chunk = if (t.lineCount <= SINGLE_MAX_LINES && t.text.length <= SINGLE_MAX_CHARS) t.lineCount.coerceAtLeast(1) else CHUNK
        val single = chunk >= t.lineCount
        // Text se připraví na pozadí a pak plynule naskočí. U delšího souboru se mezitím ukáže „Otevírám…“
        // (hned, ne až po čase – samotné rozložení textu běží v hlavním vlákně a obrazovka by se mezitím nepřekreslila).
        list.alpha = 0f
        val opening = findViewById<View>(R.id.opening)
        val big = t.text.length > 30_000
        if (big) {
            opening.alpha = 0f
            opening.visibility = View.VISIBLE
            opening.animate().alpha(0.7f).setDuration(150).start()
        }
        lifecycleScope.launch {
            val base = if (single) withContext(Dispatchers.Default) { ChunkAdapter.buildText(t, 0, t.lineCount - 1) } else null
            if (big) delay(180) // ať se „Otevírám…“ stihne ukázat, než se začne skládat text
            val a = ChunkAdapter(t, app.prefs.viewerTextSize, chunk, base)
            adapter = a
            list.adapter = a
            invalidateOptionsMenu()
            preloadAll(a)
            val scroller = findViewById<ThumbScroller>(R.id.scroller)
            val sec = if (t.hasPages) Formats.sectionLabel(Formats.key(d.ext)) else null
            scroller.labelFor = { f ->
                val line = (f * (t.lineCount - 1)).roundToInt().coerceIn(0, t.lineCount - 1)
                if (sec != null) getString(sec, t.pageOf(line)) else getString(R.string.loc_line, line + 1)
            }
            scroller.attach(list)
            list.post { scroller.update() }
            find.doAfterTextChanged {
                scheduleFind(250, -1)
            }
            scheduleFind(0, startLine)
            // plynulé objevení textu, až bude rozložený a posunutý na první výskyt
            list.doOnPreDraw {
                opening.animate().alpha(0f).setDuration(120).withEndAction { opening.visibility = View.GONE }.start()
                list.animate().alpha(1f).setDuration(220).start()
            }
        }
    }

    private fun scheduleFind(delayMs: Long, anchorLine: Int) {
        val t = dt ?: return
        val a = adapter ?: return
        findJob?.cancel()
        val raw = find.text?.toString().orEmpty()
        val m = mode
        val stem = app.prefs.stem
        findJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            val found = withContext(Dispatchers.Default) {
                val q = Query(raw, m, stem)
                if (q.isEmpty) emptyList() else q.findAll(t.norm, t.text)
            }
            val byLine = HashMap<Int, MutableList<IntArray>>()
            for (h in found) byLine.getOrPut(t.lineOf(h[0])) { ArrayList() }.add(h)
            hits = found
            a.hits = byLine
            a.current = -1
            // celý text v jednom poli: jen přebarvit, nesestavovat znovu (rychlé i u dlouhých souborů)
            val vh = if (a.itemCount == 1) list.findViewHolderForAdapterPosition(0) as? ChunkAdapter.VH else null
            if (vh == null || !a.applyHits(vh, 0)) a.notifyDataSetChanged()
            val ref = if (anchorLine >= 0) anchorLine else firstVisibleLine()
            if (found.isEmpty()) {
                idx = -1
                tapHint.hide()
                counter.text = if (raw.isBlank()) "" else getString(R.string.viewer_no_hits)
                if (anchorLine >= 0) scrollToLine(anchorLine)
            } else {
                val i = found.indexOfFirst { t.lineOf(it[0]) >= ref }
                idx = if (i < 0) found.size - 1 else i
                goTo()
                if (hintPending) {
                    hintPending = false
                    // nahoře jen když je kam jít zpět, dole jen když je kam dál
                    tapHint.set(idx > 0, idx < found.size - 1)
                }
            }
        }
    }

    /** Klepnutí do textu: horní polovina = předchozí výskyt, dolní = další (odkazy a označování fungují dál). */
    /**
     * Klepnutí do textu: horní polovina = předchozí výskyt, dolní = další (odkazy a označování podržením fungují dál).
     * Reaguje hned (bez čekání na dvojklik) a dvojklik neoznačuje slovo – jde tak rychle ťukat po výsledcích.
     */
    private fun setupTapZones() {
        var hadSelection = false
        var lastUp = 0L
        var stealing = false
        val doubleTap = ViewConfiguration.getDoubleTapTimeout().toLong()

        fun tap(e: MotionEvent): Boolean {
            if (hits.isEmpty() || hadSelection) return false
            val child = list.findChildViewUnder(e.x, e.y)
            val tv = child?.findViewById<TextView>(R.id.text)
            if (child != null && tv != null) {
                val off = tv.getOffsetForPosition(e.x - child.left - tv.left, e.y - child.top - tv.top)
                val sp = tv.text as? Spanned
                if (sp != null && off >= 0 && sp.getSpans(off, off, ClickableSpan::class.java).isNotEmpty()) return false
            }
            step(if (e.y < list.height / 2f) -1 else 1)
            return true
        }

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean = tap(e)
        })
        list.addOnItemTouchListener(object : RecyclerView.OnItemTouchListener {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        hadSelection = (currentFocus as? TextView)?.hasSelection() == true
                        tapHint.hide()
                        // druhé rychlé klepnutí si vezmeme sami, aby text neoznačil slovo
                        if (hits.isNotEmpty() && !hadSelection && e.eventTime - lastUp < doubleTap) {
                            stealing = true
                            return true
                        }
                    }
                    MotionEvent.ACTION_UP -> lastUp = e.eventTime
                }
                detector.onTouchEvent(e)
                return false
            }

            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                if (!stealing) return
                when (e.actionMasked) {
                    MotionEvent.ACTION_UP -> {
                        stealing = false
                        lastUp = e.eventTime
                        tap(e)
                    }
                    MotionEvent.ACTION_CANCEL -> stealing = false
                }
            }

            override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean) {}
        })
    }

    private fun step(d: Int) {
        if (hits.isEmpty()) return
        idx = (idx + d + hits.size) % hits.size
        goTo()
    }

    private fun goTo() {
        val a = adapter ?: return
        val t = dt ?: return
        if (idx < 0 || idx >= hits.size) return
        val pos = hits[idx][0]
        val old = a.current
        a.current = pos
        // jen přebarvit zvýraznění v už vykresleném textu – bez nového sestavení bloku (to brzdilo rychlé klepání)
        recolor(old, Highlight.HIT_COLOR)
        recolor(pos, CURRENT_HIT)
        counter.text = "${idx + 1} / ${hits.size}"
        scrollToPos(pos)
    }

    private fun recolor(pos: Int, color: Int) {
        val a = adapter ?: return
        val t = dt ?: return
        if (pos < 0) return
        val c = t.lineOf(pos) / chunk
        val vh = list.findViewHolderForAdapterPosition(c) as? ChunkAdapter.VH
        if (vh == null || !a.recolor(vh, c, pos, color)) a.notifyItemChanged(c)
    }

    /**
     * U souborů do zhruba 6000 řádků se postupně (po kouscích, aby nic nezamrzlo) připraví celý text.
     * Pak je každý výskyt hned po ruce a přeskakování je plynulé i při rychlém klepání – i z konce na začátek.
     */
    private fun preloadAll(a: ChunkAdapter) {
        if (a.itemCount > MAX_PRELOAD_CHUNKS) return
        val lm = list.layoutManager as NoJumpLayoutManager
        var rounds = 0
        val grow = object : Runnable {
            override fun run() {
                if (list.adapter !== a || list.childCount >= a.itemCount || rounds++ > 300) return
                lm.extraPx = maxOf(lm.extraPx, list.height) + list.height * 2
                list.requestLayout()
                list.postDelayed(this, 32)
            }
        }
        list.postDelayed(grow, 300)
    }

    /** Posune seznam tak, aby daná pozice v textu byla ve třetině výšky obrazovky. */
    private fun scrollToPos(pos: Int, at: Float = 1f / 3) {
        val t = dt ?: return
        val c = t.lineOf(pos) / chunk
        val shown = list.findViewHolderForAdapterPosition(c) as? ChunkAdapter.VH
        val y = if (shown != null) targetY(shown, c, pos) else null
        if (shown != null && y != null) {
            // místo je už načtené: plynulé posunutí (blízko), jinak přesný skok (třeba z konce na začátek)
            val dy = y - (list.height * at).toInt()
            if (abs(dy) < list.height * 2) {
                list.smoothScrollBy(0, dy)
            } else {
                list.stopScroll()
                (list.layoutManager as LinearLayoutManager)
                    .scrollToPositionWithOffset(c, (list.height * at).toInt() - (y - shown.itemView.top))
            }
            return
        }
        list.stopScroll()
        (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(c, 0)
        // doladit po rozložení, ale ještě před vykreslením – bez mezisnímku, který „cukal“.
        // Vždy jen jeden čekající posluchač, jinak by se při rychlém klepání snímky zahazovaly.
        pendingPreDraw?.let { list.viewTreeObserver.removeOnPreDrawListener(it) }
        val l = object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                list.viewTreeObserver.removeOnPreDrawListener(this)
                if (pendingPreDraw === this) pendingPreDraw = null
                val vh = list.findViewHolderForAdapterPosition(c) as? ChunkAdapter.VH ?: return true
                val yy = targetY(vh, c, pos) ?: return true
                list.scrollBy(0, yy - (list.height * at).toInt())
                return false
            }
        }
        pendingPreDraw = l
        list.viewTreeObserver.addOnPreDrawListener(l)
    }

    private fun targetY(vh: ChunkAdapter.VH, c: Int, pos: Int): Int? {
        val t = dt ?: return null
        val layout = vh.text.layout ?: return null
        val off = (pos - t.lineStart(c * chunk)).coerceIn(0, vh.text.text.length)
        return vh.itemView.top + vh.text.top + layout.getLineTop(layout.getLineForOffset(off))
    }

    private fun scrollToLine(line: Int) {
        val t = dt ?: return
        scrollToPos(t.lineStart(line.coerceIn(0, t.lineCount - 1)))
    }

    /** První řádek textu viditelný nahoře na obrazovce. */
    private fun firstVisibleLine(): Int {
        val t = dt ?: return 0
        val lm = list.layoutManager as LinearLayoutManager
        val c = lm.findFirstVisibleItemPosition().coerceAtLeast(0)
        val vh = list.findViewHolderForAdapterPosition(c) as? ChunkAdapter.VH
        val layout = vh?.text?.layout ?: return c * chunk
        val y = (-(vh.itemView.top + vh.text.top)).coerceAtLeast(0)
        val off = layout.getOffsetForHorizontal(layout.getLineForVertical(y), 0f)
        return t.lineOf(t.lineStart(c * chunk) + off)
    }

    private fun currentLine(): Int {
        val t = dt ?: return 0
        return if (idx >= 0 && idx < hits.size) t.lineOf(hits[idx][0]) else firstVisibleLine()
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        if (Build.VERSION.SDK_INT < 33) Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
    }

    /** Výběr delšího úseku (přes hranice bloků): text kolem aktuálního místa v jednom poli. */
    private fun selectBlock() {
        val t = dt ?: return
        if (t.text.isEmpty()) return
        val c = currentLine().coerceIn(0, t.lineCount - 1)
        val from = (c - 30).coerceAtLeast(0)
        val to = (c + 300).coerceAtMost(t.lineCount - 1)
        val text = t.text.substring(t.lineStart(from), t.lineEnd(to)).replace('\u000C', '\n')
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setText(text)
            setTextIsSelectable(true)
            textSize = app.prefs.viewerTextSize
            val p = (20 * dp).toInt()
            setPadding(p, (8 * dp).toInt(), p, p)
        }
        val sv = ScrollView(this)
        sv.addView(tv)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.select_title)
            .setView(sv)
            .setPositiveButton(R.string.copy_all) { _, _ -> copy(text) }
            .setNegativeButton(R.string.close, null)
            .show()
        val offset = t.lineStart(c) - t.lineStart(from)
        tv.post {
            val layout = tv.layout ?: return@post
            sv.scrollTo(0, layout.getLineTop(layout.getLineForOffset(offset.coerceIn(0, text.length))))
        }
    }

    private fun setTextSize(size: Float) {
        val s = size.coerceIn(10f, 30f)
        if (s == app.prefs.viewerTextSize) return
        app.prefs.viewerTextSize = s
        val a = adapter ?: return
        // zachovat místo čtení: řádek nahoře zůstane nahoře; text mezitím krátce zprůhlední a zase naskočí
        val line = firstVisibleLine()
        a.textSize = s
        list.animate().cancel()
        list.alpha = 0.25f
        a.notifyDataSetChanged()
        list.doOnPreDraw {
            dt?.let { scrollToPos(it.lineStart(line), 0f) }
            list.doOnPreDraw { list.animate().alpha(1f).setDuration(180).start() }
        }
    }

    /** Klepnutí na název nebo šipku rozbalí/sbalí panel s informacemi o souboru. */
    private fun toggleInfo() {
        val panel = findViewById<View>(R.id.infoPanel)
        val open = panel.visibility != View.VISIBLE
        panel.visibility = if (open) View.VISIBLE else View.GONE
        findViewById<View>(R.id.titleArrow).animate().rotation(if (open) 180f else 0f).setDuration(150).start()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("q", find.text?.toString().orEmpty())
        if (adapter != null) outState.putInt("line", currentLine())
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_viewer, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val d = doc
        menu.findItem(R.id.action_page)?.isVisible = d != null && Formats.hasVisualPreview(d.ext)
        // celý text v jednom poli jde označit přímo – „Označit blok“ je potřeba jen u velkých souborů
        menu.findItem(R.id.action_select)?.isVisible = (adapter?.itemCount ?: 0) > 1
        return super.onPrepareOptionsMenu(menu)
    }

    /** Hledaný výraz upravený (i smazaný) v náhledu se vrátí na hlavní obrazovku. */
    override fun finish() {
        // vrátit i prázdné pole – když hledání v náhledu smažeš, smaže se i na hlavní obrazovce
        if (::find.isInitialized) setResult(RESULT_OK, Intent().putExtra(EXTRA_QUERY, find.text?.toString().orEmpty().trim()))
        super.finish()
        // zpět: náhled odjede doprava, seznam se vrátí
        if (Build.VERSION.SDK_INT < 34) {
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.main_in, R.anim.viewer_out)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_open -> {
            doc?.let { AppPicker.openDefault(this, it) }
            true
        }
        R.id.action_open_with -> {
            doc?.let { AppPicker.pick(this, it, false) }
            true
        }
        R.id.action_select -> {
            selectBlock()
            true
        }
        R.id.action_page -> {
            val d = doc
            val t = dt
            if (d != null) {
                val page = if (t != null && t.hasPages && adapter != null) t.pageOf(currentLine()) else 1
                startActivity(
                    Intent(this, PageActivity::class.java)
                        .putExtra(PageActivity.EXTRA_DOC, d.id)
                        .putExtra(PageActivity.EXTRA_PAGE, page.coerceAtLeast(1))
                )
            }
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    /** Jeden prvek seznamu = blok CHUNK řádků; vlevo čísla řádků zarovnaná i u zalomených řádků. */
    /** Značky zvýraznění výskytů – ať jdou při novém hledání odebrat, aniž by se sahalo na odkazy apod. */
    class HitBg(color: Int) : BackgroundColorSpan(color)
    class HitFg : ForegroundColorSpan(Highlight.HIT_TEXT)
    class HitBold : StyleSpan(Typeface.BOLD)

    class ChunkAdapter(
        private val dt: DocText,
        var textSize: Float,
        private val lines: Int,
        /** Celý text připravený předem na pozadí (jen když je celý soubor v jednom poli). */
        private val prebuilt: Spannable? = null,
    ) : RecyclerView.Adapter<ChunkAdapter.VH>() {
        companion object {
            const val LINKS = Linkify.WEB_URLS or Linkify.EMAIL_ADDRESSES

            /**
             * Text řádků [first]..[last] připravený k zobrazení, i s odkazy. Stejná délka jako originál,
             * aby seděly pozice výskytů: konec stránky = nový řádek, \r = neviditelný znak.
             */
            fun buildText(dt: DocText, first: Int, last: Int): SpannableStringBuilder {
                val s = dt.lineStart(first)
                val e = dt.lineEnd(last).coerceAtLeast(s)
                val chars = CharArray(e - s)
                for (i in chars.indices) {
                    chars[i] = when (val ch = dt.text[s + i]) {
                        '\u000C' -> '\n'
                        '\r' -> '\u200B'
                        else -> ch
                    }
                }
                val sb = SpannableStringBuilder(String(chars))
                Linkify.addLinks(sb, LINKS)
                return sb
            }
        }

        var hits: Map<Int, List<IntArray>> = emptyMap()
        var current = -1 // pozice aktuálního výskytu v textu

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val num: TextView = v.findViewById(R.id.num)
            val text: TextView = v.findViewById(R.id.text)
        }

        override fun getItemCount(): Int = (dt.lineCount + lines - 1) / lines

        /** Změní barvu zvýraznění výskytu na pozici [pos] přímo v zobrazeném textu. false = nejde, je třeba překreslit blok. */
        fun recolor(holder: VH, chunk: Int, pos: Int, color: Int): Boolean {
            val sp = holder.text.text as? Spannable ?: return false
            val a = pos - dt.lineStart(chunk * lines)
            if (a < 0 || a >= sp.length) return false
            val spans = sp.getSpans(a, a + 1, BackgroundColorSpan::class.java).filter { sp.getSpanStart(it) == a }
            if (spans.isEmpty()) return false
            for (old in spans) {
                val e = sp.getSpanEnd(old)
                sp.removeSpan(old)
                sp.setSpan(HitBg(color), a, e, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            return true
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_viewer_line, parent, false))

        override fun onViewAttachedToWindow(holder: VH) {
            super.onViewAttachedToWindow(holder)
            // známá oprava: po recyklaci by jinak přestalo jít označovat
            holder.text.isEnabled = false
            holder.text.isEnabled = true
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val first = position * lines
            val last = minOf(first + lines, dt.lineCount) - 1
            val s = dt.lineStart(first)
            val sb = if (prebuilt != null && first == 0) SpannableStringBuilder(prebuilt) else buildText(dt, first, last)
            addHits(sb, first, last, s)
            holder.text.textSize = textSize
            holder.num.textSize = textSize
            // odkazy už v textu jsou (Linkify); maska se zapne až po vložení textu, aby se nepočítaly znovu,
            // a je potřeba, aby na odkaz šlo klepnout i v textu, který jde označovat
            holder.text.autoLinkMask = 0
            holder.text.text = sb
            holder.text.autoLinkMask = LINKS
            holder.num.text = ""
            holder.text.post { buildGutter(holder, position, first, last, s) }
        }

        private fun addHits(sp: Spannable, first: Int, last: Int, s: Int) {
            for (line in first..last) {
                val hl = hits[line] ?: continue
                for (h in hl) {
                    val a = h[0] - s
                    val b = minOf(h[0] + h[1] - s, sp.length)
                    if (a < 0 || a >= b) continue
                    val color = if (h[0] == current) CURRENT_HIT else Highlight.HIT_COLOR
                    sp.setSpan(HitBg(color), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sp.setSpan(HitFg(), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sp.setSpan(HitBold(), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
        }

        /** Nové hledání v už zobrazeném textu: odebrat staré zvýraznění a přidat nové (bez nového sestavení). */
        fun applyHits(holder: VH, position: Int): Boolean {
            val sp = holder.text.text as? Spannable ?: return false
            for (k in listOf(HitBg::class.java, HitFg::class.java, HitBold::class.java)) {
                for (o in sp.getSpans(0, sp.length, k)) sp.removeSpan(o)
            }
            val first = position * lines
            val last = minOf(first + lines, dt.lineCount) - 1
            addHits(sp, first, last, dt.lineStart(first))
            return true
        }

        /** Čísla řádků: každé číslo + tolik prázdných řádků, na kolik se řádek zalomil. */
        private fun buildGutter(holder: VH, position: Int, first: Int, last: Int, s: Int) {
            if (holder.bindingAdapterPosition != position) return
            val layout = holder.text.layout ?: return
            val sb = StringBuilder()
            for (line in first..last) {
                val v0 = layout.getLineForOffset((dt.lineStart(line) - s).coerceIn(0, holder.text.text.length))
                val v1 = if (line < last) layout.getLineForOffset((dt.lineStart(line + 1) - s).coerceIn(0, holder.text.text.length))
                else layout.lineCount
                sb.append(line + 1)
                repeat((v1 - v0).coerceAtLeast(1)) { sb.append('\n') }
            }
            holder.num.text = sb
        }
    }
}
