package cz.ales.dochledac

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.nio.charset.Charset
import java.util.zip.ZipInputStream

/** Soubory uvnitř ZIP mají v indexu adresu "<uri archivu>!/<cesta v archivu>". */
object Zips {
    const val SEP = "!/"

    fun isEntry(uri: String): Boolean = uri.contains(SEP)

    /**
     * Pro soubor z archivu ho rozbalí do mezipaměti a vrátí file:// adresu
     * (pro otevření v jiné aplikaci nebo náhled stránky). Jinak vrátí původní adresu.
     */
    fun materialize(ctx: Context, uri: String): Uri {
        if (!isEntry(uri)) return Uri.parse(uri)
        val zipUri = Uri.parse(uri.substringBefore(SEP))
        val entry = uri.substringAfter(SEP)
        val dir = File(ctx.cacheDir, "zip")
        dir.deleteRecursively()
        dir.mkdirs()
        val out = File(dir, entry.substringAfterLast('/'))

        fun extract(cs: Charset): Boolean {
            val input = ctx.contentResolver.openInputStream(zipUri) ?: throw IOException()
            ZipInputStream(BufferedInputStream(input), cs).use { z ->
                while (true) {
                    val e = z.nextEntry ?: return false
                    if (e.name == entry) {
                        out.outputStream().use { z.copyTo(it) }
                        return true
                    }
                }
            }
            return false
        }

        val ok = try {
            extract(Charsets.UTF_8)
        } catch (e: IllegalArgumentException) {
            extract(Charsets.ISO_8859_1)
        }
        if (!ok) throw IOException(entry)
        return Uri.fromFile(out)
    }
}
