package cz.ales.dochledac

/**
 * Slovo nebo fráze (více slov za sebou), normalizované.
 * [exact] = text v uvozovkách: celá slova přesně, včetně diakritiky (malá/velká písmena se nerozlišují).
 */
class Term(
    val tokens: List<String>,
    val variants: List<String> = tokens,
    val exact: List<String>? = null,
    /** Uvozovky ještě nejsou zavřené (píše se): poslední slovo stačí jako začátek, ať výsledky naskakují. */
    val open: Boolean = false,
) {
    val isPhrase: Boolean get() = tokens.size > 1
}

/**
 * Dotaz:  slovo slovo   = obě slova (A ZÁROVEŇ)
 *         "přesná fráze" = přesně: celá slova, s diakritikou, bez tvarů slov
 *         -slovo         = soubor nesmí obsahovat
 *         a | b, a OR b  = aspoň jedno
 */
class Query(raw: String, val mode: Int, stem: Boolean = false) {
    companion object {
        const val MODE_WORDS = 0
        const val MODE_ANYWHERE = 1
        const val MODE_NAMES = 2
        private val NON_WORD = Regex("[^\\p{L}\\p{N}]+")
    }

    /** Všechny skupiny musí platit; ve skupině stačí jedna z možností. */
    val groups: List<List<Term>>
    val excluded: List<Term>
    private val anywhere = mode != MODE_WORDS
    private val regexCache = HashMap<Term, Regex>()

    init {
        val g = ArrayList<MutableList<Term>>()
        val ex = ArrayList<Term>()
        var orNext = false
        // české „…“ a anglické “…” uvozovky se berou stejně jako rovné "…"
        val text0 = raw.replace('„', '"').replace('“', '"').replace('”', '"')
        for (m in Regex("(-?)\"([^\"]*)\"?|(\\S+)").findAll(text0)) {
            val neg: Boolean
            val text: String
            val quoted = m.groups[2] != null
            val body = m.value.removePrefix("-")
            val open = quoted && (body.length < 2 || !body.endsWith("\""))
            if (quoted) {
                neg = m.groupValues[1] == "-"
                text = m.groupValues[2]
            } else {
                val w = m.groupValues[3]
                if (w == "|" || w == "OR") {
                    orNext = true
                    continue
                }
                neg = w.length > 1 && w.startsWith("-")
                text = if (neg) w.substring(1) else w
            }
            val toks = TextFold.norm(text).split(' ').filter { it.isNotEmpty() }
            if (toks.isEmpty()) continue
            val t = when {
                quoted -> Term(toks, exact = text.lowercase().split(NON_WORD).filter { it.isNotEmpty() }, open = open)
                stem && mode != MODE_ANYWHERE && toks.size == 1 && !neg -> Term(toks, CzechStem.variants(toks[0]))
                else -> Term(toks)
            }
            if (neg) ex.add(t)
            else if (orNext && g.isNotEmpty()) g[g.size - 1].add(t)
            else g.add(mutableListOf(t))
            orNext = false
        }
        groups = g
        excluded = ex
    }

    val isEmpty: Boolean get() = groups.isEmpty()

    /** Celý dotaz je v uvozovkách – režim Začátek/Kdekoli ani tvary slov na něj nemají vliv. */
    val allExact: Boolean
        get() = !isEmpty && groups.all { g -> g.all { it.exact != null } } && excluded.all { it.exact != null }

    private fun find(t: Term, norm: String, orig: String, out: MutableList<IntArray>, limit: Int) {
        if (!t.isPhrase) {
            for (tok in t.variants) {
                var idx = norm.indexOf(tok)
                while (idx >= 0 && out.size < limit) {
                    if ((anywhere || idx == 0 || norm[idx - 1] == ' ') && exactOk(t, norm, orig, idx, tok.length)) {
                        out.add(intArrayOf(idx, tok.length))
                    }
                    idx = norm.indexOf(tok, idx + tok.length)
                }
            }
        } else {
            val r = regexCache.getOrPut(t) {
                val body = t.tokens.joinToString(" +") { Regex.escape(it) }
                Regex(if (anywhere) body else "(?<![^ ])$body")
            }
            for (m in r.findAll(norm)) {
                if (out.size >= limit) break
                val len = m.range.last - m.range.first + 1
                if (exactOk(t, norm, orig, m.range.first, len)) out.add(intArrayOf(m.range.first, len))
            }
        }
    }

    /**
     * Text v uvozovkách = přesně: vždy celá slova (v každém režimu), stejná diakritika,
     * bez tvarů slov. Nerozlišují se jen velká a malá písmena (a mezery či interpunkce mezi slovy).
     */
    private fun exactOk(t: Term, norm: String, orig: String, pos: Int, len: Int): Boolean {
        val ex = t.exact ?: return true
        if (pos > 0 && norm[pos - 1] != ' ') return false
        val end = pos + len
        if (!t.open && end < norm.length && norm[end] != ' ') return false
        if (orig.length != norm.length) return true // bez původního textu nejde ověřit
        val words = orig.substring(pos, end).lowercase().split(NON_WORD).filter { it.isNotEmpty() }
        return words == ex
    }

    private fun contains(t: Term, norm: String, orig: String): Boolean {
        val tmp = ArrayList<IntArray>(1)
        find(t, norm, orig, tmp, 1)
        return tmp.isNotEmpty()
    }

    /** Odpovídá soubor dotazu? (název a obsah – původní i normalizovaný) */
    fun matches(name: String, normName: String, body: String, normBody: String): Boolean =
        groups.all { g -> g.any { contains(it, normBody, body) || contains(it, normName, name) } } &&
            excluded.none { contains(it, normBody, body) || contains(it, normName, name) }

    /** Všechny výskyty hledaných slov, seřazené: [pozice, délka]. */
    fun findAll(norm: String, orig: String, limit: Int = 50_000): List<IntArray> {
        val res = ArrayList<IntArray>()
        for (g in groups) for (t in g) find(t, norm, orig, res, limit)
        // seřadit; na stejné pozici nechat jen nejdelší shodu (varianty slova se překrývají)
        res.sortWith(compareBy<IntArray> { it[0] }.thenByDescending { it[1] })
        val out = ArrayList<IntArray>(res.size)
        for (h in res) if (out.isEmpty() || out[out.size - 1][0] != h[0]) out.add(h)
        return out
    }

    /** Dotaz pro fulltextový index SQLite (FTS4). OR má přednost před A ZÁROVEŇ. */
    fun ftsQuery(): String = groups.joinToString(" ") { g ->
        g.joinToString(" OR ") { t ->
            if (t.isPhrase) "\"" + t.tokens.joinToString(" ") + "*\"" else t.variants.joinToString(" OR ") { "$it*" }
        }
    }

    /** Podmínka pro režim „kdekoli v textu“ (hrubý výběr, přesně se ověří v matches). */
    fun sqlAnywhere(): Pair<String, Array<String>> {
        val args = ArrayList<String>()
        val cond = groups.joinToString(" AND ") { g ->
            "(" + g.joinToString(" OR ") { t ->
                val parts = if (t.isPhrase) t.tokens else t.variants
                val op = if (t.isPhrase) " AND " else " OR "
                "(" + parts.joinToString(op) { tok ->
                    args.add(tok)
                    args.add(tok)
                    "(instr(body, ?) > 0 OR instr(name, ?) > 0)"
                } + ")"
            } + ")"
        }
        return cond to args.toTypedArray()
    }
}
