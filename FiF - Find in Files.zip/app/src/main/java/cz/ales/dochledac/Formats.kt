package cz.ales.dochledac

import androidx.annotation.StringRes

object Formats {
    class Format(val key: String, @StringRes val label: Int)

    class Group(@StringRes val title: Int, val formats: List<Format>)

    /** Seřazeno podle toho, co běžní lidé nejčastěji hledají a kde mají věci uložené. */
    val GROUPS = listOf(
        Group(R.string.grp_docs, listOf(
            Format("pdf", R.string.fmt_pdf),
            Format("docx", R.string.fmt_docx),
            Format("txt", R.string.fmt_txt),
            Format("rtf", R.string.fmt_rtf),
            Format("odt", R.string.fmt_odt),
        )),
        Group(R.string.grp_sheets, listOf(
            Format("xlsx", R.string.fmt_xlsx),
            Format("pptx", R.string.fmt_pptx),
            Format("csv", R.string.fmt_csv),
            Format("ods", R.string.fmt_ods),
            Format("odp", R.string.fmt_odp),
        )),
        Group(R.string.grp_books, listOf(
            Format("epub", R.string.fmt_epub),
            Format("fb2", R.string.fmt_fb2),
        )),
        Group(R.string.grp_web, listOf(
            Format("zip", R.string.fmt_zip),
            Format("html", R.string.fmt_html),
        )),
        Group(R.string.grp_subs, listOf(
            Format("srt", R.string.fmt_srt),
            Format("vtt", R.string.fmt_vtt),
            Format("ass", R.string.fmt_ass),
            Format("sub", R.string.fmt_sub),
        )),
        Group(R.string.grp_tech, listOf(
            Format("md", R.string.fmt_md),
            Format("log", R.string.fmt_log),
            Format("json", R.string.fmt_json),
            Format("xml", R.string.fmt_xml),
            Format("ini", R.string.fmt_ini),
        )),
    )

    val SUBTITLES = setOf("srt", "vtt", "ass", "sub")

    /** Sjednocení přípon se stejným zpracováním. */
    fun key(ext: String): String = when (ext) {
        "htm", "xhtml" -> "html"
        "ssa" -> "ass"
        "markdown" -> "md"
        "cfg", "conf" -> "ini"
        "jpg", "jpeg", "png", "webp" -> "img"
        else -> ext
    }

    fun mime(ext: String): String = when (key(ext)) {
        "pdf" -> "application/pdf"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "odt" -> "application/vnd.oasis.opendocument.text"
        "ods" -> "application/vnd.oasis.opendocument.spreadsheet"
        "odp" -> "application/vnd.oasis.opendocument.presentation"
        "rtf" -> "application/rtf"
        "epub" -> "application/epub+zip"
        "fb2" -> "application/x-fictionbook+xml"
        "html" -> "text/html"
        "img" -> if (ext == "jpg") "image/jpeg" else "image/$ext"
        "zip" -> "application/zip"
        else -> "text/plain"
    }

    /** Jak se jmenují části oddělené znakem \u000C (stránka, snímek, list, kapitola). */
    @StringRes
    fun sectionLabel(key: String): Int? = when (key) {
        "pdf" -> R.string.loc_page
        "pptx", "odp" -> R.string.loc_slide
        "xlsx", "ods" -> R.string.loc_sheet
        "epub" -> R.string.loc_chapter
        else -> null
    }

    fun hasVisualPreview(ext: String): Boolean = key(ext) == "pdf" || key(ext) == "img"
}
