package cz.ales.dochledac

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.roundToInt

/**
 * Posuvník pro palec u pravého okraje. Je skrytý; při posouvání textu vyjede z boku jen fialový
 * obdélník a po chvíli bez pohybu zase zajede – text tak může jít až ke kraji.
 * Při tažení ukáže bublinu s číslem řádku / stránky.
 */
class ThumbScroller(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {
    private val dp = resources.displayMetrics.density
    private val thumbW = 10 * dp
    private val thumbH = 56 * dp
    private val margin = 3 * dp
    private val touchW = 48 * dp
    private var recycler: RecyclerView? = null
    private var fraction = 0f
    private var dragging = false
    private var longEnough = false
    /** 0 = schovaný za okrajem, 1 = vysunutý. */
    private var slide = 0f
    private var anim: ValueAnimator? = null
    private val hideRunnable = Runnable { animateTo(0f) }

    /** Popisek do bubliny podle pozice v seznamu. */
    var labelFor: ((Int) -> String)? = null

    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6A1B9A.toInt() }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6A1B9A.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15 * dp
        isFakeBoldText = true
    }
    private val rect = RectF()
    private val bounds = Rect()

    fun attach(rv: RecyclerView) {
        recycler = rv
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                update()
                if (dy != 0 && longEnough) reveal()
            }
        })
    }

    fun update() {
        val rv = recycler ?: return
        val range = rv.computeVerticalScrollRange()
        val extent = rv.computeVerticalScrollExtent()
        val offset = rv.computeVerticalScrollOffset()
        longEnough = range > extent * 2
        if (!dragging) fraction = if (range - extent > 0) offset.toFloat() / (range - extent) else 0f
        invalidate()
    }

    private fun reveal() {
        removeCallbacks(hideRunnable)
        if (slide < 1f && anim?.isRunning != true) animateTo(1f)
        if (!dragging) postDelayed(hideRunnable, 1500)
    }

    private fun animateTo(target: Float) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(slide, target).apply {
            duration = 180
            addUpdateListener {
                slide = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (slide <= 0f) return
        val right = width - margin + (1f - slide) * (thumbW + margin)
        val top = fraction.coerceIn(0f, 1f) * (height - thumbH)
        rect.set(right - thumbW, top, right, top + thumbH)
        canvas.drawRoundRect(rect, 3 * dp, 3 * dp, thumbPaint)
        if (dragging) {
            val rv = recycler ?: return
            val n = rv.adapter?.itemCount ?: 0
            val label = labelFor?.invoke((fraction * (n - 1).coerceAtLeast(0)).roundToInt()) ?: return
            textPaint.getTextBounds(label, 0, label.length, bounds)
            val pad = 10 * dp
            val bw = bounds.width() + 2 * pad
            val bh = bounds.height() + 2 * pad
            val bx = right - thumbW - 12 * dp - bw
            val by = (top + thumbH / 2 - bh / 2).coerceIn(0f, height - bh)
            rect.set(bx, by, bx + bw, by + bh)
            canvas.drawRoundRect(rect, bh / 2, bh / 2, bubblePaint)
            canvas.drawText(label, bx + pad, by + pad + bounds.height(), textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val rv = recycler ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // chytit jde jen vysunutý posuvník; jinak dotyk jde do textu
                if (slide < 0.5f || event.x < width - touchW) return false
                val top = fraction.coerceIn(0f, 1f) * (height - thumbH)
                if (event.y < top - 24 * dp || event.y > top + thumbH + 24 * dp) return false
                dragging = true
                removeCallbacks(hideRunnable)
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                moveTo(rv, event.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) return false
                dragging = false
                update()
                reveal()
                return true
            }
        }
        return false
    }

    private fun moveTo(rv: RecyclerView, y: Float) {
        fraction = ((y - thumbH / 2) / (height - thumbH)).coerceIn(0f, 1f)
        val n = rv.adapter?.itemCount ?: return
        if (n == 0) return
        val pos = (fraction * (n - 1)).roundToInt()
        (rv.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(pos, 0)
        invalidate()
    }
}

/** LayoutManager, který neposouvá seznam, když se klepne do textu (to dělalo „odskakování“). */
class NoJumpLayoutManager(ctx: Context) : LinearLayoutManager(ctx) {
    /**
     * Připravit (vykreslit mimo obrazovku) i jednu obrazovku textu nad a pod viditelnou částí.
     * Další výskyt pak bývá už nachystaný a přeskok na něj je plynulý i při rychlém klepání.
     */
    override fun calculateExtraLayoutSpace(state: RecyclerView.State, extraLayoutSpace: IntArray) {
        val e = maxOf(height, extraPx)
        extraLayoutSpace[0] = e
        extraLayoutSpace[1] = e
    }

    /** Kolik pixelů textu mít nachystaných nad a pod obrazovkou (u kratších souborů postupně celý text). */
    var extraPx = 0

    override fun requestChildRectangleOnScreen(
        parent: RecyclerView, child: View, rect: Rect, immediate: Boolean, focusedChildVisible: Boolean,
    ): Boolean = false
}
