package cz.ales.dochledac

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.roundToInt

/**
 * Velký posuvník pro palec u pravého okraje. Ukazuje se jen u delších souborů.
 * Při tažení ukáže bublinu s číslem řádku / stránky.
 */
class ThumbScroller(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {
    private val dp = resources.displayMetrics.density
    private val thumbW = 10 * dp
    private val thumbH = 64 * dp
    private val touchW = 48 * dp
    private var recycler: RecyclerView? = null
    private var fraction = 0f
    private var dragging = false
    private var shown = false

    /** Popisek do bubliny podle pozice v seznamu. */
    var labelFor: ((Int) -> String)? = null

    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6A1B9A.toInt() }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x226A1B9A }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF6A1B9A.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15 * dp
        isFakeBoldText = true
    }
    private val rect = RectF()
    private val bounds = Rect()

    fun attach(rv: RecyclerView) {
        recycler = rv
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) = update()
        })
    }

    fun update() {
        val rv = recycler ?: return
        val range = rv.computeVerticalScrollRange()
        val extent = rv.computeVerticalScrollExtent()
        val offset = rv.computeVerticalScrollOffset()
        shown = range > extent * 2
        if (!dragging) fraction = if (range - extent > 0) offset.toFloat() / (range - extent) else 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!shown) return
        val cx = width - touchW / 2
        rect.set(cx - 2 * dp, 0f, cx + 2 * dp, height.toFloat())
        canvas.drawRoundRect(rect, 2 * dp, 2 * dp, trackPaint)
        val top = fraction.coerceIn(0f, 1f) * (height - thumbH)
        rect.set(cx - thumbW / 2, top, cx + thumbW / 2, top + thumbH)
        canvas.drawRoundRect(rect, thumbW / 2, thumbW / 2, thumbPaint)
        if (dragging) {
            val rv = recycler ?: return
            val n = rv.adapter?.itemCount ?: 0
            val label = labelFor?.invoke((fraction * (n - 1).coerceAtLeast(0)).roundToInt()) ?: return
            textPaint.getTextBounds(label, 0, label.length, bounds)
            val pad = 10 * dp
            val bw = bounds.width() + 2 * pad
            val bh = bounds.height() + 2 * pad
            val bx = cx - touchW / 2 - bw - 4 * dp
            val by = (top + thumbH / 2 - bh / 2).coerceIn(0f, height - bh)
            rect.set(bx, by, bx + bw, by + bh)
            canvas.drawRoundRect(rect, bh / 2, bh / 2, bubblePaint)
            canvas.drawText(label, bx + pad, by + pad + bounds.height(), textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val rv = recycler ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!shown || event.x < width - touchW) return false // jinak dotyk jde do textu
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                moveTo(rv, event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                moveTo(rv, event.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) return false
                dragging = false
                update()
                return true
            }
        }
        return false
    }

    private fun moveTo(rv: RecyclerView, y: Float) {
        fraction = ((y - thumbH / 2) / (height - thumbH)).coerceIn(0f, 1f)
        val n = rv.adapter?.itemCount ?: return
        if (n == 0) return
        val pos = (fraction * (n - 1)).roundToInt()
        (rv.layoutManager as? LinearLayoutManager)?.scrollToPositionWithOffset(pos, 0)
        invalidate()
    }
}

/** LayoutManager, který neposouvá seznam, když se klepne do textu (to dělalo „odskakování“). */
class NoJumpLayoutManager(ctx: Context) : LinearLayoutManager(ctx) {
    override fun requestChildRectangleOnScreen(
        parent: RecyclerView, child: View, rect: Rect, immediate: Boolean, focusedChildVisible: Boolean,
    ): Boolean = false
}
