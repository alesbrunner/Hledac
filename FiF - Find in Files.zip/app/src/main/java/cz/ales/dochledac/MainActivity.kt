package cz.ales.dochledac

import android.content.Intent
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import android.os.SystemClock
import android.text.format.DateUtils
import android.view.Menu
import android.view.MenuItem
import android.view.View
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.button.MaterialButton
import android.graphics.Typeface
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.widget.Button
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.text.HtmlCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Toast
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    companion object {
        const val ACTION_SEARCH = "cz.ales.dochledac.SEARCH"
        const val ACTION_REINDEX = "cz.ales.dochledac.REINDEX"
    }

    private val app get() = application as App
    private lateinit var search: TextInputEditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var emptyBox: View
    private lateinit var stemChip: MaterialButton
    private var syncingStem = false
    private lateinit var adapter: ResultsAdapter
    private var mode = Query.MODE_WORDS
    private var namesOnly = false

    /** Náhled souboru; když v něm upravíš hledaný výraz, převezme ho i hlavní obrazovka. */
    private val viewerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val q = r.data?.getStringExtra(ViewerActivity.EXTRA_QUERY)?.trim().orEmpty()
        if (q.isNotEmpty() && q != search.text?.toString().orEmpty().trim()) {
            search.setText(q)
            search.setSelection(q.length)
        }
    }
    private var searchJob: Job? = null
    private var lastVersion = -1
    private var lastResults: List<FileResult> = emptyList()
    private var filterExt: String? = null // null = všechny typy
    private lateinit var historyScroll: View
    private lateinit var historyGroup: ChipGroup
    /** Poslední dotaz, který našel aspoň jeden soubor. */
    private var foundQuery: String? = null
    private var pendingRemember: String? = null
    private lateinit var filterScroll: View
    private lateinit var filterGroup: ChipGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupScreen(R.layout.activity_main, false)
        search = findViewById(R.id.search)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        emptyBox = findViewById(R.id.emptyBox)
        historyScroll = findViewById(R.id.historyScroll)
        historyGroup = findViewById(R.id.historyGroup)
        filterScroll = findViewById(R.id.filterScroll)
        filterGroup = findViewById(R.id.filterGroup)

        val list = findViewById<RecyclerView>(R.id.list)
        adapter = ResultsAdapter(
            onOpen = { doc, line -> openViewer(doc, line) },
            onExternal = { doc, chooser ->
                rememberQuery()
                if (chooser) AppPicker.pick(this, doc, false) else AppPicker.openDefault(this, doc)
            },
        )
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.addItemDecoration(ResultDivider())
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) hideKeyboard()
            }
        })

        mode = app.prefs.mode
        namesOnly = app.prefs.namesOnly
        setupModeButtons()

        search.doAfterTextChanged {
            updateStemEnabled()
            runSearch(180)
        }
        search.setOnEditorActionListener { _, _, _ ->
            rememberQuery()
            hideKeyboard()
            runSearch(0)
            true
        }
        setupFieldKeys()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Indexer.state.collect { renderIndex(it) }
            }
        }

        if (savedInstanceState == null) {
            if (app.prefs.autoUpdate && app.prefs.folders.isNotEmpty()) Indexer.start(this)
            handleIntent(intent)
            // aplikace se otevře rovnou s kurzorem v hledání a klávesnicí
            if ((intent?.action == null || intent?.action == Intent.ACTION_MAIN) && app.prefs.folders.isNotEmpty()) focusSearch()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Zkratky ikony, widget, „Hledat v DocHledači“ z označeného textu a sdílení textu. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val text: String? = when (i.action) {
            Intent.ACTION_PROCESS_TEXT -> i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        }
        when {
            text != null && text.isNotBlank() -> {
                search.setText(text.trim().take(200))
                search.setSelection(search.text?.length ?: 0)
                runSearch(0)
            }
            i.action == ACTION_SEARCH -> focusSearch()
            i.action == ACTION_REINDEX -> if (app.prefs.folders.isNotEmpty()) Indexer.start(this)
        }
    }

    private fun focusSearch() {
        search.requestFocus()
        search.post { WindowCompat.getInsetsController(window, search).show(WindowInsetsCompat.Type.ime()) }
    }

    override fun onResume() {
        super.onResume()
        ThemeMode.apply(app) // u režimu „podle západu slunce“ se téma přepne samo
        updateEmptyState()
        // přepínač Tvary slov je svázaný s Nastavením
        syncingStem = true
        stemChip.isChecked = app.prefs.stem
        syncingStem = false
        if (search.text.isNullOrBlank()) {
            showIdle()
            showHistory()
        }
    }

    private fun renderIndex(s: IndexState) {
        if (s.running) {
            progress.visibility = View.VISIBLE
            if (s.total > 0) {
                progress.isIndeterminate = false
                progress.max = s.total
                progress.progress = s.done
            } else {
                progress.isIndeterminate = true
            }
            if (search.text.isNullOrBlank()) status.text = s.message
        } else {
            progress.visibility = View.GONE
            if (s.version != lastVersion) {
                lastVersion = s.version
                updateEmptyState()
                runSearch(0) // nový obsah indexu -> obnovit výsledky
            }
        }
    }

    private fun showIdle() {
        val st = Indexer.state.value
        if (st.running) {
            status.text = st.message
            return
        }
        lifecycleScope.launch {
            val (n, chars) = withContext(Dispatchers.IO) { Repo.stats(app) }
            if (!search.text.isNullOrBlank()) return@launch
            status.text = if (app.prefs.folders.isEmpty()) {
                getString(R.string.status_no_folder)
            } else {
                getString(R.string.status_main, qty(R.plurals.files, n), lastIndexedText()) +
                    (if (st.note.isNotEmpty()) " · " + st.note else "")
            }
        }
    }

    /** „před 5 minutami“, „včera 17:05“… podle jazyka telefonu */
    private fun lastIndexedText(): String {
        val t = app.prefs.lastIndexed
        if (t <= 0L) return getString(R.string.never_indexed)
        val now = System.currentTimeMillis()
        return if (now - t < DateUtils.MINUTE_IN_MILLIS) getString(R.string.just_now)
        else DateUtils.getRelativeTimeSpanString(t, now, DateUtils.MINUTE_IN_MILLIS).toString().lowercase()
    }

    private fun runSearch(delayMs: Long) {
        searchJob?.cancel()
        val q = search.text?.toString().orEmpty().trim()
        val m = mode
        val names = namesOnly
        val sort = app.prefs.sort
        searchJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            if (q.isEmpty()) {
                lastResults = emptyList()
                filterScroll.visibility = View.GONE
                adapter.submit(emptyList())
                showHistory()
                showIdle()
                return@launch
            }
            historyScroll.visibility = View.GONE
            val t0 = SystemClock.elapsedRealtime()
            val res = try {
                withContext(Dispatchers.Default) { Searcher.search(app, q, m, names, sort) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status.text = getString(R.string.search_error, e.message ?: "")
                return@launch
            }
            val ms = SystemClock.elapsedRealtime() - t0
            lastResults = res.files
            foundQuery = if (res.files.isNotEmpty()) q else null
            if (pendingRemember == q) {
                pendingRemember = null
                if (foundQuery != null) app.prefs.recordSearch(q)
            }
            buildFilters()
            status.text = if (res.files.isEmpty()) {
                getString(R.string.status_nothing, ms)
            } else {
                getString(
                    R.string.status_found,
                    qty(R.plurals.files, res.files.size) + (if (res.truncated) "+" else ""),
                    qty(R.plurals.hits, res.totalHits),
                    ms,
                )
            }
        }
    }

    /** Nápověda s nadpisy a příklady (HTML z textů aplikace). */
    private fun showHelp() {
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            val version = try {
                packageManager.getPackageInfo(packageName, 0).versionName ?: ""
            } catch (e: Exception) {
                ""
            }
            val footer = "<br><br><small>Find In Files $version<br>11.2026 – Aleš Brunner</small>"
            text = HtmlCompat.fromHtml(getString(R.string.help_text) + footer, HtmlCompat.FROM_HTML_MODE_LEGACY)
            textSize = 15f
            setLineSpacing(0f, 1.15f)
            val p = (24 * dp).toInt()
            setPadding(p, (8 * dp).toInt(), p, (8 * dp).toInt())
        }
        val sv = ScrollView(this)
        sv.addView(tv)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.help_title)
            .setView(sv)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    /** První spuštění (žádná složka) nebo prázdný index: výzva s tlačítkem pod hledáním. */
    private fun updateEmptyState() {
        lifecycleScope.launch {
            val n = withContext(Dispatchers.IO) { Repo.stats(app).first }
            val text = findViewById<TextView>(R.id.emptyText)
            val button = findViewById<Button>(R.id.emptyButton)
            when {
                app.prefs.folders.isEmpty() -> {
                    emptyBox.visibility = View.VISIBLE
                    text.setText(R.string.empty_no_folder)
                    button.setText(R.string.add_folder)
                    button.setOnClickListener {
                        startActivity(Intent(this@MainActivity, SettingsActivity::class.java).putExtra(SettingsActivity.EXTRA_ADD_FOLDER, true))
                    }
                }
                n == 0 && !Indexer.state.value.running -> {
                    emptyBox.visibility = View.VISIBLE
                    text.setText(R.string.empty_no_index)
                    button.setText(R.string.create_index)
                    button.setOnClickListener { Indexer.start(this@MainActivity) }
                }
                else -> emptyBox.visibility = View.GONE
            }
        }
    }

    // ---------- režimy hledání a tlačítka v poli ----------

    /** Tlačítko se dvěma řádky: velká značka (ab…) a pod ní malý popisek. */
    private fun twoLine(mark: String, label: String): CharSequence {
        val sb = SpannableStringBuilder(mark)
        sb.setSpan(TypefaceSpan("monospace"), 0, mark.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(StyleSpan(Typeface.BOLD), 0, mark.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(RelativeSizeSpan(1.3f), 0, mark.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append('\n').append(label)
        return sb
    }

    private fun setupModeButtons() {
        val group = findViewById<MaterialButtonToggleGroup>(R.id.modeGroup)
        val words = findViewById<MaterialButton>(R.id.modeWords)
        val anywhere = findViewById<MaterialButton>(R.id.modeAnywhere)
        val names = findViewById<MaterialButton>(R.id.modeNames)
        stemChip = findViewById(R.id.keyStem)
        for (b in listOf(words, anywhere, names, stemChip)) {
            b.setSingleLine(false)
            b.maxLines = 2
            b.ellipsize = null
        }
        words.text = twoLine("ab…", getString(R.string.mode_words))
        anywhere.text = twoLine("…ab…", getString(R.string.mode_anywhere))
        stemChip.text = twoLine("ab~", getString(R.string.key_stem))

        group.check(if (mode == Query.MODE_ANYWHERE) R.id.modeAnywhere else R.id.modeWords)
        group.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            mode = if (id == R.id.modeAnywhere) Query.MODE_ANYWHERE else Query.MODE_WORDS
            app.prefs.mode = mode
            updateStemEnabled()
            runSearch(0)
        }

        // Soubory = jen názvy souborů; samostatný přepínač, kombinuje se se Začátek/Kdekoli
        names.isChecked = namesOnly
        names.addOnCheckedChangeListener { _, on ->
            namesOnly = on
            app.prefs.namesOnly = on
            runSearch(0)
        }

        stemChip.isChecked = app.prefs.stem
        stemChip.addOnCheckedChangeListener { _, on ->
            if (syncingStem) return@addOnCheckedChangeListener
            app.prefs.stem = on
            runSearch(0)
        }
        updateStemEnabled()
    }

    /**
     * Zašedne tlačítka, která na dotaz nemají vliv:
     *  - tvary slov v režimu Kdekoli (uříznuté slovo by se našlo uprostřed jiných slov),
     *  - Začátek, Kdekoli i tvary slov, když je celý dotaz v uvozovkách (hledá se přesně).
     * Soubory zůstávají – určují, kde se hledá (názvy, nebo obsah), ne jak.
     */
    private fun updateStemEnabled() {
        val raw = search.text?.toString().orEmpty()
        val exact = raw.isNotBlank() && Query(raw, mode).allExact
        fun set(v: View, on: Boolean) {
            v.isEnabled = on
            v.alpha = if (on) 1f else 0.38f
        }
        set(findViewById(R.id.modeWords), !exact)
        set(findViewById(R.id.modeAnywhere), !exact)
        set(stemChip, !exact && mode != Query.MODE_ANYWHERE)
    }

    private fun setupFieldKeys() {
        findViewById<View>(R.id.keyQuote).setOnClickListener { wrapQuotes() }
        findViewById<View>(R.id.keyOr).setOnClickListener { insertAtCursor(" | ") }
    }

    /**
     * Uvozovky: celý napsaný text dá do uvozovek (přesné hledání celého výrazu).
     * Když je část textu označená, obalí jen ji. Když už v uvozovkách je, uvozovky zase odebere.
     * Prázdné pole: vloží "" s kurzorem uprostřed.
     */
    private fun wrapQuotes() {
        val t = search.text ?: return
        val quotes = charArrayOf('"', '„', '“', '”')
        var s = search.selectionStart.coerceIn(0, t.length)
        var e = search.selectionEnd.coerceIn(0, t.length)
        if (s > e) s = e.also { e = s }
        if (s == e) {
            // bez označení: celý text
            s = 0
            e = t.length
            while (s < e && t[s].isWhitespace()) s++
            while (e > s && t[e - 1].isWhitespace()) e--
        }
        if (s == e) {
            t.insert(s, "\"\"")
            search.setSelection(s + 1)
            return
        }
        val part = t.substring(s, e)
        val inner = part.trim(*quotes)
        val already = part.length >= 2 && part.first() in quotes && part.last() in quotes
        val repl = if (already) inner else "\"$inner\""
        t.replace(s, e, repl)
        search.setSelection((s + repl.length).coerceAtMost(t.length))
        search.requestFocus()
    }

    private fun insertAtCursor(s: String) {
        val t = search.text ?: return
        val c = search.selectionStart.coerceIn(0, t.length)
        var ins = s
        if (c > 0 && t[c - 1] == ' ') ins = ins.trimStart()
        t.insert(c, ins)
        search.setSelection((c + ins.length).coerceAtMost(t.length))
    }

    // ---------- nejčastější hledání ----------

    /** Do nejčastějších hledání jde jen dotaz, který něco našel (případně až doběhne hledání). */
    private fun rememberQuery() {
        val q = search.text?.toString().orEmpty().trim()
        if (q.isEmpty()) return
        if (q == foundQuery) app.prefs.recordSearch(q) else pendingRemember = q
    }

    private fun showHistory() {
        historyGroup.removeAllViews()
        val top = app.prefs.topSearches(20)
        historyScroll.visibility = if (top.isEmpty()) View.GONE else View.VISIBLE
        for (q in top) {
            val chip = layoutInflater.inflate(R.layout.chip_history, historyGroup, false) as Chip
            chip.text = q
            chip.setOnClickListener {
                search.setText(q)
                search.setSelection(q.length)
            }
            chip.setOnLongClickListener {
                app.prefs.removeSearch(q)
                Toast.makeText(this, R.string.history_removed, Toast.LENGTH_SHORT).show()
                showHistory()
                true
            }
            historyGroup.addView(chip)
        }
    }

    // ---------- filtr podle přípony ----------

    private fun buildFilters() {
        val counts = lastResults.groupingBy { it.doc.ext.uppercase() }.eachCount()
        if (counts.size < 2) {
            filterExt = null
            filterScroll.visibility = View.GONE
            adapter.submit(lastResults)
            return
        }
        if (filterExt != null && filterExt !in counts) filterExt = null
        filterGroup.removeAllViews()
        fun addChip(label: String, ext: String?) {
            val chip = layoutInflater.inflate(R.layout.chip_filter, filterGroup, false) as Chip
            chip.text = label
            filterGroup.addView(chip)
            chip.isChecked = ext == filterExt
            chip.setOnClickListener {
                filterExt = ext
                chip.isChecked = true
                applyFilter()
            }
        }
        addChip(getString(R.string.filter_all, lastResults.size), null)
        for ((ext, n) in counts.entries.sortedByDescending { it.value }) addChip("$ext ($n)", ext)
        filterScroll.visibility = View.VISIBLE
        applyFilter()
    }

    private fun applyFilter() {
        val f = filterExt
        adapter.submit(if (f == null) lastResults else lastResults.filter { it.doc.ext.uppercase() == f })
    }

    private fun openViewer(doc: Doc, line: Int) {
        rememberQuery()
        hideKeyboard()
        viewerLauncher.launch(
            Intent(this, ViewerActivity::class.java)
                .putExtra(ViewerActivity.EXTRA_DOC, doc.id)
                .putExtra(ViewerActivity.EXTRA_QUERY, search.text?.toString().orEmpty())
                .putExtra(ViewerActivity.EXTRA_MODE, mode)
                .putExtra(ViewerActivity.EXTRA_LINE, line)
        )
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val id = when (app.prefs.sort) {
            Prefs.SORT_NAME -> R.id.sort_name
            Prefs.SORT_DATE -> R.id.sort_date
            else -> R.id.sort_hits
        }
        menu.findItem(id)?.isChecked = true
        return super.onPrepareOptionsMenu(menu)
    }

    private fun setSort(s: Int, item: MenuItem): Boolean {
        app.prefs.sort = s
        item.isChecked = true
        runSearch(0)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_refresh -> {
            if (app.prefs.folders.isEmpty()) startActivity(Intent(this, SettingsActivity::class.java))
            else Indexer.start(this)
            true
        }
        R.id.action_settings -> {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }
        R.id.sort_hits -> setSort(Prefs.SORT_HITS, item)
        R.id.sort_name -> setSort(Prefs.SORT_NAME, item)
        R.id.sort_date -> setSort(Prefs.SORT_DATE, item)
        R.id.action_help -> {
            showHelp()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}
