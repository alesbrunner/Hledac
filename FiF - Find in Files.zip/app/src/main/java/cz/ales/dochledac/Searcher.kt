package cz.ales.dochledac

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

class LineHit(val line: Int, val label: String, val display: CharSequence)

class FileResult(
    val doc: Doc,
    val total: Int,          // počet výskytů
    val lineCount: Int,      // počet řádků s výskytem
    val previews: List<LineHit>,
)

class SearchResult(val files: List<FileResult>, val totalHits: Int, val truncated: Boolean)

object Searcher {
    private const val MAX_FILES = 300
    private const val MAX_CANDIDATES = 1500
    private const val PREVIEW_LINES = 1

    suspend fun search(app: App, raw: String, mode: Int, namesOnly: Boolean, sort: Int): SearchResult {
        val q = Query(raw, mode, app.prefs.stem)
        if (q.isEmpty) return SearchResult(emptyList(), 0, false)
        val db = app.db.readableDatabase
        val out = ArrayList<FileResult>()
        var truncated = false

        if (namesOnly) {
            // jen názvy souborů – jako Everything
            db.rawQuery("SELECT ${Repo.COLS} FROM docs", null).use { c ->
                while (out.size <= MAX_FILES && c.moveToNext()) {
                    val d = Repo.fromCursor(c)
                    if (q.matches(d.name, TextFold.norm(d.name), "", "")) out.add(FileResult(d, 0, 0, emptyList()))
                }
            }
        } else {
            val sql: String
            val args: Array<String>
            if (mode == Query.MODE_WORDS) {
                sql = "SELECT ${Repo.COLS} FROM docs WHERE id IN (SELECT docid FROM fts WHERE fts MATCH ?) LIMIT $MAX_CANDIDATES"
                args = arrayOf(q.ftsQuery())
            } else {
                val (cond, a) = q.sqlAnywhere()
                sql = "SELECT ${Repo.COLS} FROM docs WHERE id IN (SELECT docid FROM fts WHERE $cond) LIMIT $MAX_CANDIDATES"
                args = a
            }
            val docs = ArrayList<Doc>()
            db.rawQuery(sql, args).use { c ->
                while (c.moveToNext()) docs.add(Repo.fromCursor(c))
            }
            // víc kandidátů, než se prochází – výsledků může být víc, než se ukáže
            if (docs.size >= MAX_CANDIDATES) truncated = true
            for (d in docs) {
                currentCoroutineContext().ensureActive()
                if (out.size > MAX_FILES) break
                analyze(app, d, q)?.let { out.add(it) }
            }
        }
        if (out.size > MAX_FILES) {
            truncated = true
            out.removeAt(out.size - 1)
        }
        when (sort) {
            Prefs.SORT_NAME -> out.sortBy { it.doc.name.lowercase() }
            Prefs.SORT_DATE -> out.sortByDescending { it.doc.mtime }
            else -> out.sortWith(compareByDescending<FileResult> { it.total }.thenBy { it.doc.name.lowercase() })
        }
        return SearchResult(out, out.sumOf { it.total }, truncated)
    }

    /** Ověří soubor (fráze, vyloučená slova…) a připraví řádky s výskyty. null = neodpovídá. */
    private fun analyze(app: App, d: Doc, q: Query): FileResult? {
        val text = if (d.chars > 0) Repo.loadText(app, d.id) else ""
        val dt = DocText(text)
        if (!q.matches(d.name, TextFold.norm(d.name), text, dt.norm)) return null
        if (text.isEmpty()) return FileResult(d, 0, 0, emptyList())
        val hits = q.findAll(dt.norm, text)
        val loc = Locator(app, dt, d.ext)
        val previews = ArrayList<LineHit>()
        var lineCount = 0
        var i = 0
        while (i < hits.size) {
            val ln = dt.lineOf(hits[i][0])
            val next = dt.nextLineStart(ln)
            var j = i
            while (j < hits.size && hits[j][0] < next) j++
            lineCount++
            if (previews.size < PREVIEW_LINES) {
                previews.add(
                    LineHit(ln, loc.short(ln), Highlight.build(text, dt.lineStart(ln), dt.lineEnd(ln), hits.subList(i, j), 160))
                )
            }
            i = j
        }
        return FileResult(d, hits.size, lineCount, previews)
    }
}
