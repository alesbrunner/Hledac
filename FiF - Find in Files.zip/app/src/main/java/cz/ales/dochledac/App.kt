package cz.ales.dochledac

import android.app.Application
import com.google.android.material.color.DynamicColors
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class App : Application() {
    val db: IndexDb by lazy { IndexDb(this) }
    val prefs: Prefs by lazy { Prefs(this) }

    override fun onCreate() {
        super.onCreate()
        ThemeMode.apply(this)
        DynamicColors.applyToActivitiesIfAvailable(this)
        PDFBoxResourceLoader.init(applicationContext)
        // dřív se fotky indexovaly samy, když bylo zapnuté OCR – teď se vybírají ve formátech
        val sp = getSharedPreferences("prefs_migrate", MODE_PRIVATE)
        if (!sp.getBoolean("imgExts", false)) {
            if (prefs.ocr) prefs.exts = prefs.exts + Formats.OCR_IMAGES
            sp.edit().putBoolean("imgExts", true).apply()
        }
    }
}
