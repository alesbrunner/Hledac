package cz.fif.findinfiles

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

/**
 * Náhled posunu: fialová záře u horního a dolního okraje s bílou šipkou, jemně „dýchá“.
 * Nahoře = klepnutím přeskočíš na předchozí výskyt, dole = na další.
 * Je vidět pořád (dokud je víc výskytů); dotyky nezachytává.
 */
class TapHint(ctx: Context, attrs: AttributeSet?) : View(ctx, attrs) {
    private val dp = resources.displayMetrics.density
    private val glowH = 110 * dp
    private var top = false
    private var bottom = false
    /** 0..1 – síla záře při „dýchání“. */
    private var pulse = 1f
    private var breathing: ValueAnimator? = null

    private val glowPaint = Paint()
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 7 * dp
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    init {
        isClickable = false
        isFocusable = false
        // stín u čar kreslí hardwarová akcelerace až od Androidu 9
        if (Build.VERSION.SDK_INT < 28) setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    /** Nastaví, které šipky jsou vidět; [up] = horní (předchozí), [down] = dolní (další). */
    fun set(up: Boolean, down: Boolean) {
        top = up
        bottom = down
        if (!up && !down) {
            hide()
            return
        }
        if (visibility != VISIBLE) {
            animate().cancel()
            alpha = 0f
            visibility = VISIBLE
            animate().alpha(1f).setDuration(250).start()
            startBreathing()
        }
        invalidate()
    }

    fun hide() {
        if (visibility != VISIBLE) return
        animate().cancel()
        animate().alpha(0f).setDuration(200).withEndAction {
            visibility = GONE
            breathing?.cancel()
        }.start()
    }

    private fun startBreathing() {
        if (breathing?.isRunning == true) return
        breathing = ValueAnimator.ofFloat(0.55f, 1f).apply {
            duration = 1600
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        breathing?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val aw = minOf(220 * dp, w * 0.6f)
        val ah = 24 * dp
        val glow = ((0x80 * pulse).toInt() shl 24) or 0x6A1B9A // až 50 % fialové
        arrowPaint.setShadowLayer((6 + 8 * pulse) * dp, 0f, 0f, 0xFF8E24AA.toInt())
        if (top) {
            glowPaint.shader = LinearGradient(0f, 0f, 0f, glowH, glow, 0, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, glowH, glowPaint)
            val y = 14 * dp
            path.reset()
            path.moveTo(w / 2 - aw / 2, y + ah)
            path.lineTo(w / 2, y)
            path.lineTo(w / 2 + aw / 2, y + ah)
            canvas.drawPath(path, arrowPaint)
        }
        if (bottom) {
            glowPaint.shader = LinearGradient(0f, h, 0f, h - glowH, glow, 0, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, h - glowH, w, h, glowPaint)
            val y = h - 14 * dp
            path.reset()
            path.moveTo(w / 2 - aw / 2, y - ah)
            path.lineTo(w / 2, y)
            path.lineTo(w / 2 + aw / 2, y - ah)
            canvas.drawPath(path, arrowPaint)
        }
    }
}
