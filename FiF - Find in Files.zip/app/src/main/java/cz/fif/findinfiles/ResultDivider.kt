package cz.fif.findinfiles

import android.graphics.Canvas
import android.graphics.Paint
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.color.MaterialColors

/** Jemná čára nad každým souborem (kromě prvního) v seznamu výsledků. */
class ResultDivider : RecyclerView.ItemDecoration() {
    private val paint = Paint()

    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        val adapter = parent.adapter ?: return
        paint.color = MaterialColors.getColor(parent, com.google.android.material.R.attr.colorOutlineVariant)
        paint.strokeWidth = parent.resources.displayMetrics.density
        val left = parent.paddingLeft + 12 * parent.resources.displayMetrics.density
        val right = parent.width - parent.paddingRight - 12 * parent.resources.displayMetrics.density
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            val pos = parent.getChildAdapterPosition(child)
            if (pos <= 0 || pos >= adapter.itemCount || adapter.getItemViewType(pos) != 0) continue
            val y = child.top - 3 * parent.resources.displayMetrics.density + child.translationY
            c.drawLine(left, y, right, y, paint)
        }
    }
}
