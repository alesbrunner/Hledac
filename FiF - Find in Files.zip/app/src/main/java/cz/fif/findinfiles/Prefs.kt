package cz.fif.findinfiles

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var folders: List<String>
        get() = (sp.getStringSet("folders", null) ?: emptySet()).sorted()
        set(v) = sp.edit().putStringSet("folders", HashSet(v)).apply()

    var exts: Set<String>
        get() = sp.getStringSet("exts", null)?.toSet() ?: DEFAULT_EXTS
        set(v) = sp.edit().putStringSet("exts", HashSet(v)).apply()

    /** Vyloučené složky: "id:<documentId>" nebo "name:<název složky malými písmeny>". */
    var excluded: Set<String>
        get() = sp.getStringSet("excluded", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("excluded", HashSet(v)).apply()

    var autoUpdate: Boolean
        get() = sp.getBoolean("auto", true)
        set(v) = sp.edit().putBoolean("auto", v).apply()

    /** Indexace na pozadí: 0 = vypnuto, jinak interval v hodinách. */
    var bgHours: Int
        get() = sp.getInt("bgHours", 0)
        set(v) = sp.edit().putInt("bgHours", v).apply()

    var bgChargingOnly: Boolean
        get() = sp.getBoolean("bgCharging", true)
        set(v) = sp.edit().putBoolean("bgCharging", v).apply()

    var ocr: Boolean
        get() = sp.getBoolean("ocr", false)
        set(v) = sp.edit().putBoolean("ocr", v).apply()

    /** Jak se hledá: Začátek / Kdekoli. (Starší verze měly „jen názvy“ jako třetí režim.) */
    var mode: Int
        get() = sp.getInt("mode", Query.MODE_WORDS).let { if (it == Query.MODE_NAMES) Query.MODE_WORDS else it }
        set(v) = sp.edit().putInt("mode", v).apply()

    /** Jen soubory: hledat i v cestě ke složce. */
    var searchPath: Boolean
        get() = sp.getBoolean("searchPath", true)
        set(v) = sp.edit().putBoolean("searchPath", v).apply()

    /** Kde se hledá: jen v názvech souborů (samostatný přepínač Soubory). */
    var namesOnly: Boolean
        get() = sp.getBoolean("namesOnly", sp.getInt("mode", Query.MODE_WORDS) == Query.MODE_NAMES)
        set(v) = sp.edit().putBoolean("namesOnly", v).apply()

    var sort: Int
        get() = sp.getInt("sort", SORT_HITS)
        set(v) = sp.edit().putInt("sort", v).apply()

    var theme: Int
        get() = sp.getInt("theme", ThemeMode.SYSTEM)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** Čas poslední dokončené indexace (ms), 0 = ještě nikdy. */
    var lastIndexed: Long
        get() = sp.getLong("lastIndexed", 0L)
        set(v) = sp.edit().putLong("lastIndexed", v).apply()

    var viewerTextSize: Float
        get() = sp.getFloat("viewerTextSize", 14f)
        set(v) = sp.edit().putFloat("viewerTextSize", v).apply()

    /** Zapamatované aplikace pro otevírání: položky "typ|balíček|aktivita". */
    var openWith: Set<String>
        get() = sp.getStringSet("openWith", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("openWith", HashSet(v)).apply()

    fun getOpenWith(key: String): Pair<String, String>? {
        val e = openWith.firstOrNull { it.startsWith("$key|") } ?: return null
        val parts = e.split('|')
        return if (parts.size == 3) parts[1] to parts[2] else null
    }

    fun setOpenWith(key: String, comp: Pair<String, String>?) {
        val rest = openWith.filterNot { it.startsWith("$key|") }.toMutableSet()
        if (comp != null) rest.add("$key|${comp.first}|${comp.second}")
        openWith = rest
    }

    /** Hledat i tvary slov (čeština). */
    /** Nápověda klepání (záře se šipkami) při otevření souboru. */
    var tapHint: Boolean
        get() = sp.getBoolean("tapHint", true)
        set(v) = sp.edit().putBoolean("tapHint", v).apply()

    var stem: Boolean
        get() = sp.getBoolean("stem", false)
        set(v) = sp.edit().putBoolean("stem", v).apply()

    // ---------- nejčastější hledání: {"dotaz": [počet, naposledy]} ----------

    private fun history(): JSONObject = try {
        JSONObject(sp.getString("history", null) ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    fun recordSearch(q: String) {
        val k = q.trim()
        if (k.length < 2) return
        val o = history()
        val count = (o.optJSONArray(k)?.optInt(0) ?: 0) + 1
        o.put(k, JSONArray().put(count).put(System.currentTimeMillis()))
        if (o.length() > 100) {
            val worst = entries(o).minWithOrNull(compareBy<Triple<String, Int, Long>> { it.second }.thenBy { it.third })
            if (worst != null) o.remove(worst.first)
        }
        sp.edit().putString("history", o.toString()).apply()
    }

    fun removeSearch(q: String) {
        val o = history()
        o.remove(q)
        sp.edit().putString("history", o.toString()).apply()
    }

    fun topSearches(n: Int): List<String> =
        entries(history())
            .sortedWith(compareByDescending<Triple<String, Int, Long>> { it.second }.thenByDescending { it.third })
            .take(n)
            .map { it.first }

    private fun entries(o: JSONObject): List<Triple<String, Int, Long>> {
        val list = ArrayList<Triple<String, Int, Long>>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val a = o.optJSONArray(k) ?: continue
            list.add(Triple(k, a.optInt(0), a.optLong(1)))
        }
        return list
    }

    companion object {
        val DEFAULT_EXTS = setOf("txt", "srt", "md", "pdf", "docx", "epub")
        const val SORT_HITS = 0
        const val SORT_NAME = 1
        const val SORT_DATE = 2
    }
}
