package cz.fif.findinfiles

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

/** Skutečný vzhled stránky PDF nebo obrázku, s přiblížením. */
class PageActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_DOC = "doc"
        const val EXTRA_PAGE = "page"
        private const val MAX_WIDTH = 2800
    }

    private val app get() = application as App
    private var renderer: PdfRenderer? = null
    private val lock = Mutex()
    private var page = 0
    private var pageCount = 1
    private var zoom = 1f
    private var isPdf = false
    private var picture: Bitmap? = null
    private var renderJob: Job? = null
    private lateinit var image: ImageView
    private lateinit var label: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupScreen(R.layout.activity_page, true)
        supportActionBar?.title = ""
        image = findViewById(R.id.image)
        label = findViewById(R.id.pageLabel)
        page = (savedInstanceState?.getInt("page") ?: (intent.getIntExtra(EXTRA_PAGE, 1) - 1)).coerceAtLeast(0)
        zoom = savedInstanceState?.getFloat("zoom") ?: 1f

        findViewById<Button>(R.id.prevPage).setOnClickListener { if (page > 0) { page--; render() } }
        findViewById<Button>(R.id.nextPage).setOnClickListener { if (page < pageCount - 1) { page++; render() } }
        findViewById<Button>(R.id.zoomIn).setOnClickListener { zoom = (zoom * 1.5f).coerceAtMost(4f); render() }
        findViewById<Button>(R.id.zoomOut).setOnClickListener { zoom = (zoom / 1.5f).coerceAtLeast(1f); render() }

        val id = intent.getLongExtra(EXTRA_DOC, -1)
        lifecycleScope.launch {
            val d = withContext(Dispatchers.IO) { Repo.doc(app, id) }
            if (d == null) {
                finish()
                return@launch
            }
            supportActionBar?.title = d.name
            isPdf = Formats.key(d.ext) == "pdf"
            try {
                val uri = withContext(Dispatchers.IO) { Zips.materialize(this@PageActivity, d.uri) }
                if (isPdf) {
                    val r = withContext(Dispatchers.IO) {
                        val pfd = contentResolver.openFileDescriptor(uri, "r") ?: throw IOException()
                        PdfRenderer(pfd)
                    }
                    renderer = r
                    pageCount = r.pageCount
                    page = page.coerceIn(0, (pageCount - 1).coerceAtLeast(0))
                } else {
                    picture = withContext(Dispatchers.IO) { loadImage(uri) }
                    findViewById<View>(R.id.pageNav).visibility = View.INVISIBLE
                }
                render()
            } catch (e: Exception) {
                Toast.makeText(this@PageActivity, R.string.page_error, Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun render() {
        renderJob?.cancel()
        val targetW = (resources.displayMetrics.widthPixels * zoom).toInt().coerceAtMost(MAX_WIDTH)
        renderJob = lifecycleScope.launch {
            if (isPdf) {
                val r = renderer ?: return@launch
                val p = page
                val bmp = withContext(Dispatchers.IO) {
                    lock.withLock {
                        val pg = r.openPage(p)
                        try {
                            PdfPages.render(pg, targetW)
                        } finally {
                            pg.close()
                        }
                    }
                }
                showBitmap(bmp, bmp.width, bmp.height)
                label.text = getString(R.string.page_of, p + 1, pageCount)
            } else {
                val b = picture ?: return@launch
                val w = (resources.displayMetrics.widthPixels * zoom).toInt()
                showBitmap(b, w, (b.height.toLong() * w / b.width.coerceAtLeast(1)).toInt())
            }
        }
    }

    private fun showBitmap(b: Bitmap, w: Int, h: Int) {
        image.setImageBitmap(b)
        val lp = image.layoutParams
        lp.width = w
        lp.height = h
        image.layoutParams = lp
    }

    private fun loadImage(uri: Uri): Bitmap {
        if (Build.VERSION.SDK_INT >= 28) {
            val src = ImageDecoder.createSource(contentResolver, uri)
            return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                val s = info.size
                val maxSide = maxOf(s.width, s.height)
                if (maxSide > 2048) {
                    val f = 2048f / maxSide
                    decoder.setTargetSize((s.width * f).toInt().coerceAtLeast(1), (s.height * f).toInt().coerceAtLeast(1))
                }
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: throw IOException()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", page)
        outState.putFloat("zoom", zoom)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        val r = renderer ?: return
        renderer = null
        // zavřít až po dokončení případného vykreslování
        CoroutineScope(Dispatchers.IO).launch { lock.withLock { r.close() } }
    }
}
