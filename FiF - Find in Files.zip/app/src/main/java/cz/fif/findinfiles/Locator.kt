package cz.fif.findinfiles

import android.content.Context
import java.util.Locale

/** Popisek místa v souboru: čas titulku, stránka/snímek/list/kapitola, nebo číslo řádku. */
class Locator(private val ctx: Context, private val dt: DocText, ext: String) {
    private val key = Formats.key(ext)
    private val sectionRes: Int? = if (dt.hasPages) Formats.sectionLabel(key) else null
    private val times: IntArray? = if (key in Formats.SUBTITLES) cueTimes() else null

    /** Krátký popisek do seznamu výsledků. */
    fun short(line: Int): String {
        val t = times?.get(line) ?: -1
        return when {
            t >= 0 -> fmtTime(t)
            sectionRes != null -> ctx.getString(sectionRes, dt.pageOf(line))
            else -> (line + 1).toString()
        }
    }

    /** Delší popisek do náhledu. */
    fun long(line: Int): String {
        val t = times?.get(line) ?: -1
        return when {
            t >= 0 -> fmtTime(t)
            sectionRes != null -> ctx.getString(sectionRes, dt.pageOf(line))
            else -> ctx.getString(R.string.loc_line, line + 1)
        }
    }

    private fun fmtTime(sec: Int): String =
        String.format(Locale.ROOT, "%d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60)

    private fun cueTimes(): IntArray {
        val srt = Regex("(?:(\\d{1,2}):)?(\\d{1,2}):(\\d{2})[.,]\\d{1,3}\\s*-->")
        val ass = Regex("^Dialogue:\\s*[^,]*,(\\d+):(\\d{2}):(\\d{2})")
        val res = IntArray(dt.lineCount) { -1 }
        var cur = -1
        for (l in 0 until dt.lineCount) {
            val len = dt.lineEnd(l) - dt.lineStart(l)
            if (len in 10..400) {
                val line = dt.lineText(l)
                if (line.contains("-->")) {
                    val m = srt.find(line)
                    if (m != null) {
                        val h = m.groupValues[1].toIntOrNull() ?: 0
                        cur = h * 3600 + m.groupValues[2].toInt() * 60 + m.groupValues[3].toInt()
                    }
                } else if (line.startsWith("Dialogue:")) {
                    val m = ass.find(line)
                    if (m != null) {
                        res[l] = m.groupValues[1].toInt() * 3600 + m.groupValues[2].toInt() * 60 + m.groupValues[3].toInt()
                        continue
                    }
                }
            }
            res[l] = cur
        }
        return res
    }
}
