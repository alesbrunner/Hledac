package cz.fif.findinfiles

import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.InputStream

/**
 * Popisné údaje souborů, které se jinak hledají jen podle názvu:
 *  - hudba a video: název, interpret, album, žánr, rok… (ID3 a podobné značky),
 *  - fotky JPG: název, předmět, značky, komentář, autor – jak je zapíšou Windows (Vlastnosti → Podrobnosti)
 *    nebo jiné programy (EXIF a XMP). Technické údaje (fotoaparát, GPS…) se vynechávají.
 * Vrací text „Popisek: hodnota“ po řádcích, nebo "" když nic není.
 */
object Meta {
    private val AUDIO_VIDEO = setOf(
        "mp3", "flac", "m4a", "ogg", "opus", "wav", "aac", "wma",
        "mp4", "mkv", "avi", "mov", "webm", "m4v", "3gp", "wmv",
    )

    fun read(app: App, uri: Uri, ext: String): String = try {
        when {
            ext in AUDIO_VIDEO -> media(app, uri)
            ext == "jpg" || ext == "jpeg" -> app.contentResolver.openInputStream(uri)?.use { photo(app, it) } ?: ""
            else -> ""
        }
    } catch (e: Throwable) {
        "" // poškozený nebo neznámý soubor – hledá se aspoň podle názvu
    }

    private fun lines(app: App, pairs: List<Pair<Int, String?>>): String {
        val sb = StringBuilder()
        val seen = HashSet<String>()
        for ((label, v) in pairs) {
            val t = v?.trim()?.trimEnd('\u0000')?.trim() ?: continue
            if (t.isEmpty() || !seen.add(label.toString() + t)) continue
            sb.append(app.getString(label)).append(": ").append(t).append('\n')
        }
        return sb.toString().trimEnd()
    }

    // ---------- hudba a video ----------

    private fun media(app: App, uri: Uri): String {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(app, uri)
            fun g(k: Int): String? = try {
                r.extractMetadata(k)
            } catch (e: Exception) {
                null
            }
            return lines(
                app,
                listOf(
                    R.string.meta_title to g(MediaMetadataRetriever.METADATA_KEY_TITLE),
                    R.string.meta_artist to g(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                    R.string.meta_artist to g(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST),
                    R.string.meta_album to g(MediaMetadataRetriever.METADATA_KEY_ALBUM),
                    R.string.meta_genre to g(MediaMetadataRetriever.METADATA_KEY_GENRE),
                    R.string.meta_composer to g(MediaMetadataRetriever.METADATA_KEY_COMPOSER),
                    R.string.meta_author to g(MediaMetadataRetriever.METADATA_KEY_AUTHOR),
                    R.string.meta_author to g(MediaMetadataRetriever.METADATA_KEY_WRITER),
                    R.string.meta_year to g(MediaMetadataRetriever.METADATA_KEY_YEAR),
                ),
            )
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    // ---------- fotky JPG ----------

    private const val MAX_HEAD = 512 * 1024 // údaje jsou na začátku souboru

    private fun photo(app: App, input: InputStream): String {
        val b = readHead(input)
        if (b.size < 4 || (b[0].toInt() and 0xFF) != 0xFF || (b[1].toInt() and 0xFF) != 0xD8) return ""
        val out = ArrayList<Pair<Int, String?>>()
        var p = 2
        while (p + 4 <= b.size) {
            if ((b[p].toInt() and 0xFF) != 0xFF) break
            val marker = b[p + 1].toInt() and 0xFF
            if (marker == 0xDA || marker == 0xD9) break // začátek obrazových dat
            val len = ((b[p + 2].toInt() and 0xFF) shl 8) or (b[p + 3].toInt() and 0xFF)
            val start = p + 4
            val end = (p + 2 + len).coerceAtMost(b.size)
            if (marker == 0xE1 && end > start) {
                if (startsWith(b, start, "Exif\u0000\u0000")) exif(b, start + 6, end, out)
                else if (startsWith(b, start, "http://ns.adobe.com/xap/1.0/\u0000")) {
                    val s0 = start + 29
                    xmp(String(b, s0, (end - s0).coerceAtLeast(0), Charsets.UTF_8), out)
                }
            }
            p = p + 2 + len
        }
        return lines(app, out)
    }

    private fun readHead(input: InputStream): ByteArray {
        val buf = ByteArray(MAX_HEAD)
        var n = 0
        while (n < buf.size) {
            val r = input.read(buf, n, buf.size - n)
            if (r <= 0) break
            n += r
        }
        return buf.copyOf(n)
    }

    private fun startsWith(b: ByteArray, at: Int, s: String): Boolean {
        if (at + s.length > b.size) return false
        for (i in s.indices) if ((b[at + i].toInt() and 0xFF) != s[i].code) return false
        return true
    }

    /** EXIF IFD0: popis, autor a pole z Windows (XPTitle, XPComment, XPAuthor, XPKeywords, XPSubject). */
    private fun exif(b: ByteArray, tiff: Int, end: Int, out: MutableList<Pair<Int, String?>>) {
        if (tiff + 8 > end) return
        val le = b[tiff].toInt() == 'I'.code
        fun u16(o: Int): Int = if (o + 2 > end) 0 else if (le)
            (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
        else ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
        fun u32(o: Int): Int = if (le) u16(o) or (u16(o + 2) shl 16) else (u16(o) shl 16) or u16(o + 2)
        val ifd = tiff + u32(tiff + 4)
        if (ifd < tiff || ifd + 2 > end) return
        val n = u16(ifd).coerceAtMost(500)
        for (i in 0 until n) {
            val e = ifd + 2 + i * 12
            if (e + 12 > end) break
            val tag = u16(e)
            val count = u32(e + 4)
            if (count <= 0 || count > 65536) continue
            val dataAt = if (count <= 4) e + 8 else tiff + u32(e + 8)
            if (dataAt < tiff || dataAt + count > end) continue
            when (tag) {
                0x010E -> out.add(R.string.meta_description to String(b, dataAt, count, Charsets.ISO_8859_1))
                0x013B -> out.add(R.string.meta_author to String(b, dataAt, count, Charsets.ISO_8859_1))
                0x9C9B -> out.add(R.string.meta_title to String(b, dataAt, count, Charsets.UTF_16LE))
                0x9C9F -> out.add(R.string.meta_subject to String(b, dataAt, count, Charsets.UTF_16LE))
                0x9C9E -> out.add(R.string.meta_tags to String(b, dataAt, count, Charsets.UTF_16LE))
                0x9C9C -> out.add(R.string.meta_comment to String(b, dataAt, count, Charsets.UTF_16LE))
                0x9C9D -> out.add(R.string.meta_author to String(b, dataAt, count, Charsets.UTF_16LE))
            }
        }
    }

    /** XMP: dc:title, dc:description, dc:subject (značky), dc:creator. */
    private fun xmp(x: String, out: MutableList<Pair<Int, String?>>) {
        fun items(tag: String): List<String> {
            val block = Regex("<$tag[^>]*>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).find(x)?.groupValues?.get(1)
            if (block != null) {
                val li = Regex("<rdf:li[^>]*>(.*?)</rdf:li>", RegexOption.DOT_MATCHES_ALL).findAll(block).map { unescape(it.groupValues[1]) }.toList()
                return li.ifEmpty { listOf(unescape(block)) }
            }
            val attr = Regex("$tag=\"([^\"]*)\"").find(x)?.groupValues?.get(1)
            return if (attr != null) listOf(unescape(attr)) else emptyList()
        }
        items("dc:title").forEach { out.add(R.string.meta_title to it) }
        items("dc:description").forEach { out.add(R.string.meta_description to it) }
        val tags = items("dc:subject")
        if (tags.isNotEmpty()) out.add(R.string.meta_tags to tags.joinToString("; "))
        items("dc:creator").forEach { out.add(R.string.meta_author to it) }
    }

    private fun unescape(s: String): String = s.replace(Regex("<[^>]+>"), " ")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
        .trim()
}
