package cz.fif.findinfiles

import java.io.IOException
import java.nio.charset.Charset

/**
 * Staré formáty Office (DOC, XLS, PPT – Office 97–2003). Jsou uložené v „compound file“ (OLE2),
 * z něj se vytáhnou textové proudy. Bez velkých knihoven – jen čtení textu pro hledání.
 */
object OldOffice {
    private const val FF = '\u000C'
    private val CP1252: Charset = Charset.forName("windows-1252")
    private val LATIN1: Charset = Charsets.ISO_8859_1
    private val UTF16: Charset = Charsets.UTF_16LE

    private fun u16(b: ByteArray, o: Int): Int =
        if (o < 0 || o + 2 > b.size) 0 else (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun u32(b: ByteArray, o: Int): Long =
        if (o < 0 || o + 4 > b.size) 0xFFFFFFFFL
        else (u16(b, o).toLong()) or (u16(b, o + 2).toLong() shl 16)

    private fun str(b: ByteArray, from: Int, len: Int, cs: Charset): String {
        val s = from.coerceIn(0, b.size)
        val e = (from + len).coerceIn(s, b.size)
        return String(b, s, e - s, cs)
    }

    /** Čtení OLE2 compound file: tabulka FAT, adresář a proudy (i malé v „mini“ proudu). */
    private class Cfb(private val b: ByteArray) {
        private val ss: Int
        private val mss: Int
        private val cutoff: Long
        private val fat = ArrayList<Long>()
        private val miniFat = ArrayList<Long>()
        private val mini: ByteArray
        private val entries = ArrayList<Entry>()

        class Entry(val name: String, val type: Int, val start: Long, val size: Long)

        init {
            val sig = byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte(), 0xA1.toByte(), 0xB1.toByte(), 0x1A, 0xE1.toByte())
            if (b.size < 512 || !b.copyOfRange(0, 8).contentEquals(sig)) throw IOException("not OLE2")
            ss = 1 shl u16(b, 0x1E)
            mss = 1 shl u16(b, 0x20)
            if (ss < 128 || ss > 65536 || mss < 16) throw IOException("bad OLE2")
            val nFat = u32(b, 0x2C)
            val firstDir = u32(b, 0x30)
            cutoff = u32(b, 0x38)
            val firstMini = u32(b, 0x3C)
            var difat = u32(b, 0x44)
            val fatSecs = ArrayList<Long>()
            for (i in 0 until 109) {
                val x = u32(b, 0x4C + 4 * i)
                if (x < 0xFFFFFFFAL && fatSecs.size < nFat) fatSecs.add(x)
            }
            var guard = 0
            while (difat < 0xFFFFFFFAL && fatSecs.size < nFat && guard++ < 10000) {
                val off = off(difat)
                val n = ss / 4 - 1
                for (i in 0 until n) {
                    val x = u32(b, off + 4 * i)
                    if (x < 0xFFFFFFFAL) fatSecs.add(x)
                }
                difat = u32(b, off + 4 * n)
            }
            for (sec in fatSecs) {
                val o = off(sec)
                for (i in 0 until ss / 4) fat.add(u32(b, o + 4 * i))
            }
            val dir = chain(firstDir, -1)
            for (i in 0 until dir.size / 128) {
                val o = i * 128
                val nl = u16(dir, o + 0x40)
                val name = str(dir, o, (nl - 2).coerceIn(0, 64), UTF16)
                entries.add(Entry(name, dir[o + 0x42].toInt() and 0xFF, u32(dir, o + 0x74), u32(dir, o + 0x78)))
            }
            val root = entries.firstOrNull() ?: throw IOException("bad OLE2")
            mini = chain(root.start, root.size)
            if (firstMini < 0xFFFFFFFAL) {
                val mf = chain(firstMini, -1)
                for (i in 0 until mf.size / 4) miniFat.add(u32(mf, 4 * i))
            }
        }

        private fun off(sec: Long): Int = ((sec + 1) * ss).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

        private fun chain(start: Long, size: Long): ByteArray {
            val out = java.io.ByteArrayOutputStream()
            var sec = start
            var guard = 0
            while (sec < 0xFFFFFFFAL && guard++ <= fat.size) {
                val o = off(sec)
                if (o >= b.size) break
                out.write(b, o, minOf(ss, b.size - o))
                if (size >= 0 && out.size() >= size) break
                sec = if (sec < fat.size) fat[sec.toInt()] else 0xFFFFFFFEL
            }
            val r = out.toByteArray()
            return if (size >= 0 && r.size > size) r.copyOf(size.toInt()) else r
        }

        fun stream(name: String): ByteArray? {
            val e = entries.firstOrNull { it.type == 2 && it.name.equals(name, true) } ?: return null
            if (e.size >= cutoff) return chain(e.start, e.size)
            val out = java.io.ByteArrayOutputStream()
            var sec = e.start
            var guard = 0
            while (sec < 0xFFFFFFFAL && out.size() < e.size && guard++ <= miniFat.size) {
                val o = (sec * mss).toInt()
                if (o >= mini.size) break
                out.write(mini, o, minOf(mss, mini.size - o))
                sec = if (sec < miniFat.size) miniFat[sec.toInt()] else 0xFFFFFFFEL
            }
            val r = out.toByteArray()
            return if (r.size > e.size) r.copyOf(e.size.toInt()) else r
        }
    }

    // ---------- DOC (Word 97–2003) ----------

    fun doc(b: ByteArray): String {
        val c = Cfb(b)
        val w = c.stream("WordDocument") ?: throw IOException("no WordDocument")
        val flags = u16(w, 0x0A)
        if ((flags and 0x0100) != 0) throw IOException("encrypted")
        val table = c.stream(if ((flags and 0x0200) != 0) "1Table" else "0Table") ?: throw IOException("no table")
        // FIB: FibBase (32 B), csw + fibRgW, cslw + fibRgLw, cbRgFcLcb + fibRgFcLcbBlob; fcClx je 34. dvojice
        var pos = 32
        pos += 2 + u16(w, pos) * 2
        pos += 2 + u16(w, pos) * 4
        pos += 2
        val fcClx = u32(w, pos + 33 * 8).toInt()
        val lcbClx = u32(w, pos + 33 * 8 + 4).toInt()
        if (fcClx < 0 || lcbClx <= 0 || fcClx + lcbClx > table.size) throw IOException("bad CLX")
        var i = fcClx
        val end = fcClx + lcbClx
        while (i < end && table[i].toInt() == 1) i += 3 + u16(table, i + 1) // Prc – formátování, přeskočit
        if (i >= end || table[i].toInt() != 2) throw IOException("bad CLX")
        val lcb = u32(table, i + 1).toInt()
        val plc = i + 5
        val n = (lcb - 4) / 12
        val sb = StringBuilder()
        for (k in 0 until n) {
            val cp0 = u32(table, plc + 4 * k)
            val cp1 = u32(table, plc + 4 * (k + 1))
            val count = (cp1 - cp0).toInt().coerceAtLeast(0)
            val fc = u32(table, plc + 4 * (n + 1) + 8 * k + 2)
            if ((fc and 0x40000000L) != 0L) {
                sb.append(str(w, ((fc and 0x3FFFFFFFL) / 2).toInt(), count, CP1252))
            } else {
                sb.append(str(w, fc.toInt(), count * 2, UTF16))
            }
        }
        return cleanWord(sb)
    }

    /** Řídicí znaky Wordu: odstavec → nový řádek, buňka tabulky → tabulátor, kódy polí se vynechají. */
    private fun cleanWord(t: CharSequence): String {
        val out = StringBuilder(t.length)
        val fields = ArrayList<Boolean>() // true = jsme v kódu pole (vynechat)
        for (ch in t) {
            when (ch.code) {
                0x13 -> fields.add(true)
                0x14 -> if (fields.isNotEmpty()) fields[fields.size - 1] = false
                0x15 -> if (fields.isNotEmpty()) fields.removeAt(fields.size - 1)
                else -> {
                    if (fields.isNotEmpty() && fields[fields.size - 1]) continue
                    when {
                        ch == '\r' || ch.code == 0x0B || ch.code == 0x0C -> out.append('\n')
                        ch.code == 0x07 -> out.append('\t')
                        ch == '\t' || ch.code >= 0x20 -> out.append(ch)
                    }
                }
            }
        }
        return out.toString()
    }

    // ---------- PPT (PowerPoint 97–2003) ----------

    fun ppt(b: ByteArray): String {
        val s = Cfb(b).stream("PowerPoint Document") ?: throw IOException("no PowerPoint Document")
        val out = StringBuilder()
        pptWalk(s, 0, s.size, false, out, 0)
        return out.toString().trim()
    }

    private fun pptWalk(s: ByteArray, from: Int, to: Int, skip: Boolean, out: StringBuilder, depth: Int) {
        if (depth > 40) return
        var p = from
        while (p + 8 <= to) {
            val vi = u16(s, p)
            val type = u16(s, p + 2)
            val len = u32(s, p + 4).coerceAtMost((to - p - 8).toLong()).toInt().coerceAtLeast(0)
            if ((vi and 0xF) == 0xF) {
                // kontejner: snímek = nová stránka; předlohy (MainMaster) se vynechají
                if (type == 0x03EE && !skip && out.isNotEmpty()) out.append(FF)
                pptWalk(s, p + 8, p + 8 + len, skip || type == 0x03F8 || type == 0x0FC9, out, depth + 1)
            } else if (!skip && (type == 0x0FA0 || type == 0x0FA8)) {
                val text = str(s, p + 8, len, if (type == 0x0FA0) UTF16 else LATIN1)
                    .replace('\r', '\n').replace('\u000B', '\n')
                if (text.isNotBlank() && text != "*") out.append(text).append('\n')
            }
            p += 8 + len
        }
    }

    // ---------- XLS (Excel 97–2003) ----------

    fun xls(b: ByteArray): String {
        val c = Cfb(b)
        val s = c.stream("Workbook") ?: c.stream("Book") ?: throw IOException("no Workbook")
        val recs = ArrayList<Pair<Int, ByteArray>>()
        var p = 0
        while (p + 4 <= s.size) {
            val t = u16(s, p)
            val l = u16(s, p + 2)
            val e = (p + 4 + l).coerceAtMost(s.size)
            recs.add(t to s.copyOfRange(p + 4, e))
            p += 4 + l
        }
        val out = ArrayList<String>()
        var i = 0
        while (i < recs.size) {
            val (t, d) = recs[i]
            when (t) {
                0x0085 -> { // BOUNDSHEET – název listu
                    val cch = d.getOrElse(6) { 0.toByte() }.toInt() and 0xFF
                    val wide = (d.getOrElse(7) { 0.toByte() }.toInt() and 1) != 0
                    out.add(str(d, 8, if (wide) cch * 2 else cch, if (wide) UTF16 else LATIN1))
                }
                0x00FC -> { // SST – sdílené texty buněk (pokračují v CONTINUE)
                    val parts = arrayListOf(d)
                    var j = i + 1
                    while (j < recs.size && recs[j].first == 0x003C) {
                        parts.add(recs[j].second)
                        j++
                    }
                    out.addAll(sst(parts))
                    i = j
                    continue
                }
                0x0204 -> { // LABEL – text buňky (starší soubory)
                    val cch = u16(d, 6)
                    val wide = (d.getOrElse(8) { 0.toByte() }.toInt() and 1) != 0
                    out.add(str(d, 9, if (wide) cch * 2 else cch, if (wide) UTF16 else LATIN1))
                }
            }
            i++
        }
        return out.filter { it.isNotBlank() }.joinToString("\n")
    }

    private fun sst(parts: List<ByteArray>): List<String> {
        val res = ArrayList<String>()
        var pi = 0
        var buf = parts[0]
        var p = 8
        val unique = u32(buf, 4).coerceAtMost(1_000_000L).toInt()
        fun next(): Boolean {
            pi++
            if (pi >= parts.size) return false
            buf = parts[pi]
            p = 0
            return true
        }
        for (k in 0 until unique) {
            if (p >= buf.size && !next()) break
            if (p + 3 > buf.size) break
            val cch = u16(buf, p)
            val f = buf[p + 2].toInt() and 0xFF
            p += 3
            val rich = if ((f and 8) != 0) u16(buf, p).also { p += 2 } else 0
            val ext = if ((f and 4) != 0) u32(buf, p).toInt().also { p += 4 } else 0
            var wide = (f and 1) != 0
            val sb = StringBuilder()
            var left = cch
            while (left > 0) {
                if (p >= buf.size) {
                    if (!next()) break
                    // v pokračování začíná znovu bajt s příznakem šířky znaků
                    wide = buf.isNotEmpty() && (buf[0].toInt() and 1) != 0
                    p = 1
                }
                val w = if (wide) 2 else 1
                val n = minOf(left, (buf.size - p) / w)
                if (n <= 0) {
                    p = buf.size
                    continue
                }
                sb.append(str(buf, p, n * w, if (wide) UTF16 else LATIN1))
                p += n * w
                left -= n
            }
            res.add(sb.toString())
            var skip = rich * 4 + ext
            while (skip > 0) {
                if (p >= buf.size && !next()) break
                val n = minOf(skip, buf.size - p)
                p += n
                skip -= n
            }
        }
        return res
    }
}
