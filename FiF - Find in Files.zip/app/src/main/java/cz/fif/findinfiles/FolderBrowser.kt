package cz.fif.findinfiles

import android.content.DialogInterface
import android.net.Uri
import android.provider.DocumentsContract
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Jednoduchý výběr složky uvnitř aplikace.
 * roots = výchozí seznam (úložiště, nebo už vybrané složky); allowRootPick = jestli jde vybrat přímo kořen.
 */
class FolderBrowser(
    private val activity: AppCompatActivity,
    private val roots: List<Node>,
    private val allowRootPick: Boolean,
    private val title: Int,
    private val onPick: (Node) -> Unit,
) {
    sealed class Node {
        abstract val name: String
        abstract val label: String
    }

    class SafNode(val tree: Uri, val docId: String, override val name: String, override val label: String) : Node()
    class FileNode(val file: File, override val name: String, override val label: String) : Node()

    private val stack = ArrayList<Node>()
    private var items: List<Node> = emptyList()
    private var hasUp = false
    private lateinit var pathView: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var dialog: AlertDialog

    fun show() {
        val ctx = activity
        val dp = ctx.resources.displayMetrics.density
        pathView = TextView(ctx).apply {
            textSize = 13f
            alpha = 0.75f
            setPadding((24 * dp).toInt(), (4 * dp).toInt(), (24 * dp).toInt(), (8 * dp).toInt())
        }
        adapter = ArrayAdapter(ctx, android.R.layout.simple_list_item_1, ArrayList<String>())
        val list = ListView(ctx)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> onItem(pos) }
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        box.addView(pathView)
        box.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (380 * dp).toInt()))

        dialog = MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(R.string.browse_select, null)
            .setNegativeButton(R.string.cancel, null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val cur = stack.lastOrNull()
                if (cur != null && canPick()) {
                    onPick(cur)
                    dialog.dismiss()
                }
            }
            load()
        }
        dialog.show()
    }

    private fun canPick(): Boolean = stack.isNotEmpty() && (allowRootPick || stack.size > 1)

    private fun onItem(pos: Int) {
        if (hasUp && pos == 0) {
            stack.removeAt(stack.size - 1)
        } else {
            val i = if (hasUp) pos - 1 else pos
            if (i < 0 || i >= items.size) return
            stack.add(items[i])
        }
        load()
    }

    private fun load() {
        val cur = stack.lastOrNull()
        pathView.text = cur?.label ?: activity.getString(R.string.browse_root)
        dialog.getButton(DialogInterface.BUTTON_POSITIVE)?.isEnabled = canPick()
        activity.lifecycleScope.launch {
            val children = if (cur == null) roots else withContext(Dispatchers.IO) { list(cur) }
            if (stack.lastOrNull() !== cur) return@launch // mezitím se přešlo jinam
            items = children
            hasUp = cur != null
            adapter.clear()
            if (hasUp) adapter.add(activity.getString(R.string.browse_up))
            adapter.addAll(children.map { "📁  " + it.name })
            if (children.isEmpty() && cur != null) adapter.add(activity.getString(R.string.browse_empty))
        }
    }

    private fun list(n: Node): List<Node> = when (n) {
        is FileNode -> (n.file.listFiles() ?: emptyArray())
            .filter { it.isDirectory && !it.name.startsWith(".") }
            .sortedBy { it.name.lowercase() }
            .map { FileNode(it, it.name, n.label + "/" + it.name) }
        is SafNode -> {
            val res = ArrayList<Node>()
            try {
                val uri = DocumentsContract.buildChildDocumentsUriUsingTree(n.tree, n.docId)
                val proj = arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                )
                activity.contentResolver.query(uri, proj, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0)
                        val name = c.getString(1)
                        if (id != null && name != null && !name.startsWith(".") &&
                            c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR
                        ) res.add(SafNode(n.tree, id, name, n.label + "/" + name))
                    }
                }
            } catch (e: Exception) {
            }
            res.sortedBy { it.name.lowercase() }
        }
    }
}
