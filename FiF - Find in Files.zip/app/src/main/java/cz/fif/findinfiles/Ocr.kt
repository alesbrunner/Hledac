package cz.fif.findinfiles

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Rozpoznávání textu (OCR) v obrázcích a naskenovaných PDF – běží offline v telefonu. */
object Ocr {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private fun run(img: InputImage): String = Tasks.await(recognizer.process(img)).text

    fun image(ctx: Context, uri: Uri): String = run(InputImage.fromFilePath(ctx, uri))

    /** OCR vybraných stránek PDF (indexy od 0). */
    fun pdfPages(ctx: Context, uri: Uri, pages: List<Int>): Map<Int, String> {
        val out = HashMap<Int, String>()
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return out
        val r = try {
            PdfRenderer(pfd)
        } catch (e: Exception) {
            pfd.close()
            return out
        }
        try {
            for (i in pages) {
                if (i >= r.pageCount) continue
                val page = r.openPage(i)
                try {
                    val bmp = PdfPages.render(page, 2000)
                    out[i] = run(InputImage.fromBitmap(bmp, 0))
                    bmp.recycle()
                } finally {
                    page.close()
                }
            }
        } finally {
            r.close()
        }
        return out
    }
}

object PdfPages {
    /** Vykreslí stránku PDF na bílé pozadí v dané šířce (px). */
    fun render(page: PdfRenderer.Page, targetWidth: Int): Bitmap {
        val scale = targetWidth.toFloat() / page.width
        val h = (page.height * scale).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(targetWidth, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        val m = Matrix()
        m.setScale(scale, scale)
        page.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        return bmp
    }
}
