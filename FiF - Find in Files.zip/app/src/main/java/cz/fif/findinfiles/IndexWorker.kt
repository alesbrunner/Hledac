package cz.fif.findinfiles

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Pravidelná aktualizace indexu na pozadí (plánuje ji Android, šetrně k baterii). */
class IndexWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as App
        if (app.prefs.folders.isNotEmpty()) Indexer.runInBackground(app)
        return Result.success()
    }
}

object BgIndex {
    private const val NAME = "background-index"

    fun apply(ctx: Context) {
        val app = ctx.applicationContext as App
        val wm = WorkManager.getInstance(app)
        val hours = app.prefs.bgHours
        if (hours <= 0) {
            wm.cancelUniqueWork(NAME)
            return
        }
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .setRequiresCharging(app.prefs.bgChargingOnly)
            .build()
        val req = PeriodicWorkRequestBuilder<IndexWorker>(hours.toLong(), TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}
