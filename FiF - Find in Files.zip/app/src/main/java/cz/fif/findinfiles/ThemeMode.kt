package cz.fif.findinfiles

import androidx.appcompat.app.AppCompatDelegate
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/** Světlé / tmavé téma – podle systému, napevno, nebo podle východu a západu slunce. */
object ThemeMode {
    const val SYSTEM = 0
    const val LIGHT = 1
    const val DARK = 2
    const val SUN = 3

    fun apply(app: App) {
        val mode = when (app.prefs.theme) {
            LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            DARK -> AppCompatDelegate.MODE_NIGHT_YES
            SUN -> if (Sun.isNight()) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        if (AppCompatDelegate.getDefaultNightMode() != mode) AppCompatDelegate.setDefaultNightMode(mode)
    }
}

/**
 * Výpočet východu a západu slunce (algoritmus NOAA) pro střed Česka a Slovenska –
 * na celém území se liší jen o pár minut, takže aplikace nepotřebuje polohu.
 */
object Sun {
    private const val LAT = 49.4
    private const val LON = 16.6

    /** (východ, západ) v minutách od půlnoci místního času */
    fun times(c: Calendar = Calendar.getInstance()): Pair<Int, Int> {
        val n = c.get(Calendar.DAY_OF_YEAR)
        val g = 2 * PI / 365 * (n - 1)
        val eqTime = 229.18 * (0.000075 + 0.001868 * cos(g) - 0.032077 * sin(g) - 0.014615 * cos(2 * g) - 0.040849 * sin(2 * g))
        val decl = 0.006918 - 0.399912 * cos(g) + 0.070257 * sin(g) - 0.006758 * cos(2 * g) +
            0.000907 * sin(2 * g) - 0.002697 * cos(3 * g) + 0.00148 * sin(3 * g)
        val lat = Math.toRadians(LAT)
        val cosHa = cos(Math.toRadians(90.833)) / (cos(lat) * cos(decl)) - tan(lat) * tan(decl)
        val ha = Math.toDegrees(acos(cosHa.coerceIn(-1.0, 1.0)))
        val tz = (c.get(Calendar.ZONE_OFFSET) + c.get(Calendar.DST_OFFSET)) / 60000
        val rise = 720 - 4 * (LON + ha) - eqTime + tz
        val sunset = 720 - 4 * (LON - ha) - eqTime + tz
        return rise.roundToInt() to sunset.roundToInt()
    }

    fun isNight(c: Calendar = Calendar.getInstance()): Boolean {
        val (rise, sunset) = times(c)
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return m < rise || m >= sunset
    }

    fun fmt(min: Int): String = String.format(Locale.ROOT, "%d:%02d", min / 60, min % 60)
}
