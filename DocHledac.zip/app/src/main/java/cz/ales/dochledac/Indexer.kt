package cz.ales.dochledac

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Environment
import android.os.SystemClock
import android.provider.DocumentsContract
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

data class IndexState(
    val running: Boolean = false,
    val message: String = "",
    val done: Int = 0,
    val total: Int = 0,
    val version: Int = 0,
    /** Krátká poznámka pro hlavní obrazovku: co se při poslední indexaci změnilo, nebo chyba. */
    val note: String = "",
)

/** Inkrementální indexace: znovu se zpracují jen nové a změněné soubory (podle velikosti a data změny). */
object Indexer {
    private class FileEntry(val uri: String, val name: String, val path: String, val ext: String, val size: Long, val mtime: Long)
    private class Existing(val id: Long, val size: Long, val mtime: Long)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(IndexState())
    val state: StateFlow<IndexState> = _state.asStateFlow()

    private val mutex = Mutex()
    private var job: Job? = null
    @Volatile private var again = false
    @Volatile private var lastNote = ""

    private val PROJ = arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE,
        DocumentsContract.Document.COLUMN_LAST_MODIFIED,
    )

    /** Spuštění z aplikace (s průběhem v UI). */
    @Synchronized
    fun start(ctx: Context) {
        if (job?.isActive == true) {
            again = true // po doběhnutí proběhne ještě jednou (změnilo se nastavení)
            return
        }
        val app = ctx.applicationContext as App
        job = scope.launch {
            mutex.withLock {
                var msg: String
                do {
                    again = false
                    msg = runSafe(app)
                } while (again && isActive)
                finish(msg)
            }
        }
    }

    /** Spuštění z WorkManageru na pozadí. Když indexace už běží, nedělá nic. */
    suspend fun runInBackground(app: App) {
        if (!mutex.tryLock()) return
        try {
            finish(runSafe(app))
        } finally {
            mutex.unlock()
        }
    }

    fun clearIndex(app: App) {
        scope.launch {
            job?.cancelAndJoin()
            mutex.withLock { Repo.clear(app) }
            finish(app.getString(R.string.idx_cleared))
        }
    }

    private fun finish(msg: String) {
        _state.value = IndexState(false, msg, version = _state.value.version + 1, note = lastNote)
        lastNote = ""
    }

    private fun progress(msg: String, done: Int, total: Int) {
        _state.value = IndexState(true, msg, done, total, _state.value.version)
    }

    private suspend fun runSafe(app: App): String = try {
        runOnce(app)
    } catch (e: CancellationException) {
        app.getString(R.string.idx_cancelled).also { lastNote = it }
    } catch (e: Throwable) {
        app.getString(R.string.idx_error, e.message ?: e.javaClass.simpleName).also { lastNote = it }
    }

    private suspend fun runOnce(app: App): String {
        val prefs = app.prefs
        val exts = prefs.exts
        val db = app.db.writableDatabase

        progress(app.getString(R.string.idx_scanning), 0, 0)
        val found = ArrayList<FileEntry>()
        val failedRoots = ArrayList<String>()
        for (f in prefs.folders) {
            val ok = if (Paths.isFile(f)) scanFiles(app, f, prefs.exts, prefs.excluded, prefs.ocr, found)
            else scan(app, app.contentResolver, Uri.parse(f), prefs.exts, prefs.excluded, prefs.ocr, found)
            if (!ok) failedRoots.add(f) // složka teď není dostupná – její záznamy v indexu nemazat
        }

        val existing = HashMap<String, Existing>()
        db.rawQuery("SELECT id, uri, size, mtime FROM docs", null).use { c ->
            while (c.moveToNext()) existing[c.getString(1)] = Existing(c.getLong(0), c.getLong(2), c.getLong(3))
        }

        // soubory uvnitř archivu: "<uri archivu>!/…"
        fun childrenOf(zipUri: String): List<Long> {
            val prefix = zipUri + Zips.SEP
            return existing.entries.filter { it.key.startsWith(prefix) }.map { it.value.id }
        }

        val keep = HashSet<Long>()
        val todo = ArrayList<Pair<FileEntry, Long?>>()
        val seenUris = HashSet<String>()
        for (f in found) {
            if (!seenUris.add(f.uri)) continue
            val e = existing[f.uri]
            val changed = e == null || e.size != f.size || e.mtime != f.mtime
            if (e != null) keep.add(e.id)
            if (!changed && Formats.key(f.ext) == "zip") keep.addAll(childrenOf(f.uri))
            if (changed) todo.add(f to e?.id)
        }

        // smazané soubory / odebrané nebo vyloučené složky / vypnuté formáty
        val removed = existing.entries
            .filter { en -> en.value.id !in keep && failedRoots.none { r -> en.key.startsWith(r) } }
            .map { it.value }
        if (removed.isNotEmpty()) {
            db.beginTransaction()
            try {
                for (e in removed) deleteDoc(app, db, e.id)
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }

        var done = 0
        db.beginTransaction()
        try {
            var batchStart = SystemClock.elapsedRealtime()
            for ((f, oldId) in todo) {
                currentCoroutineContext().ensureActive()
                progress(app.getString(R.string.idx_indexing, done + 1, todo.size, f.name), done, todo.size)
                var text = ""
                var err: String? = null
                val isZip = Formats.key(f.ext) == "zip"
                val items = ArrayList<Extractors.ZipItem>()
                try {
                    text = if (isZip) Extractors.zip(app, Uri.parse(f.uri), exts, items)
                    else Extractors.extract(app, Uri.parse(f.uri), f.ext, f.size)
                } catch (e: Throwable) {
                    err = e.message ?: e.javaClass.simpleName
                }
                if (oldId != null) deleteDoc(app, db, oldId)
                if (isZip) for (cid in childrenOf(f.uri)) deleteDoc(app, db, cid)
                insertDoc(app, db, f, text, err) // u ZIP: text = seznam souborů v archivu
                for (item in items) {
                    val name = item.path.substringAfterLast('/')
                    val dir = item.path.substringBeforeLast('/', "")
                    val child = FileEntry(
                        f.uri + Zips.SEP + item.path, name,
                        f.path + "/" + f.name + (if (dir.isEmpty()) "" else "/$dir"),
                        name.substringAfterLast('.', "").lowercase(), f.size, f.mtime,
                    )
                    insertDoc(app, db, child, item.text, item.error)
                }
                done++
                val now = SystemClock.elapsedRealtime()
                if (done % 30 == 0 || now - batchStart > 1500) {
                    // průběžné uložení – přerušená indexace nepřijde nazmar
                    db.setTransactionSuccessful()
                    db.endTransaction()
                    db.beginTransaction()
                    batchStart = now
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        val total = DatabaseUtils.queryNumEntries(db, "docs").toInt()
        app.prefs.lastIndexed = System.currentTimeMillis()
        val sb = StringBuilder(app.getString(R.string.idx_done, app.resources.getQuantityString(R.plurals.files, total, total)))
        val note = ArrayList<String>()
        if (done > 0) note.add(app.getString(R.string.idx_done_new, done).removePrefix(" · "))
        if (removed.isNotEmpty()) note.add(app.getString(R.string.idx_done_removed, removed.size).removePrefix(" · "))
        for (n in note) sb.append(" · ").append(n)
        lastNote = note.joinToString(" · ")
        return sb.toString()
    }

    private suspend fun scan(
        app: App, cr: ContentResolver, tree: Uri, exts: Set<String>, excluded: Set<String>, ocr: Boolean,
        out: ArrayList<FileEntry>,
    ): Boolean {
        val rootId = try {
            DocumentsContract.getTreeDocumentId(tree)
        } catch (e: Exception) {
            return false
        }
        val rootLabel = Paths.label(app, tree)
        val stack = ArrayDeque<Pair<String, String>>()
        stack.addLast(rootId to "")
        while (stack.isNotEmpty()) {
            currentCoroutineContext().ensureActive()
            val (docId, rel) = stack.removeLast()
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val c = (try {
                cr.query(childrenUri, PROJ, null, null, null)
            } catch (e: Exception) {
                null
            })
            if (c == null) {
                if (docId == rootId) return false
                continue
            }
            try {
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    if (name.startsWith(".")) continue
                    val mime = c.getString(2)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if ("id:$id" in excluded || "name:${name.lowercase()}" in excluded) continue
                        stack.addLast(id to (if (rel.isEmpty()) name else "$rel/$name"))
                        continue
                    }
                    val ext = name.substringAfterLast('.', "").lowercase()
                    val key = Formats.key(ext)
                    // obrázky se prohledávají, právě když je zapnuté OCR
                    if (if (key == "img") !ocr else key !in exts) continue
                    val size = if (c.isNull(3)) 0L else c.getLong(3)
                    val mtime = if (c.isNull(4)) 0L else c.getLong(4)
                    val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id).toString()
                    val path = if (rel.isEmpty()) rootLabel else "$rootLabel/$rel"
                    out.add(FileEntry(uri, name, path, ext, size, mtime))
                    if (out.size % 250 == 0) progress(app.getString(R.string.idx_scanning_n, out.size), 0, 0)
                }
            } finally {
                c.close()
            }
        }
        return true
    }

    /** Procházení přes „přístup ke všem souborům“ (umí i celé úložiště a Download). */
    private suspend fun scanFiles(
        app: App, folder: String, exts: Set<String>, excluded: Set<String>, ocr: Boolean,
        out: ArrayList<FileEntry>,
    ): Boolean {
        val root = File(Paths.filePath(folder))
        if (root.listFiles() == null) return false
        val rootLabel = Paths.labelOfFile(app, root.absolutePath)
        val storageRoot = Environment.getExternalStorageDirectory().absolutePath
        val stack = ArrayDeque<Pair<File, String>>()
        stack.addLast(root to "")
        while (stack.isNotEmpty()) {
            currentCoroutineContext().ensureActive()
            val (dir, rel) = stack.removeLast()
            val children = dir.listFiles() ?: continue
            for (f in children) {
                val name = f.name
                if (name.startsWith(".")) continue
                if (f.isDirectory) {
                    if (name == "Android" && dir.absolutePath == storageRoot) continue // data aplikací
                    if ("path:${f.absolutePath}" in excluded || "name:${name.lowercase()}" in excluded) continue
                    stack.addLast(f to (if (rel.isEmpty()) name else "$rel/$name"))
                    continue
                }
                val ext = name.substringAfterLast('.', "").lowercase()
                val key = Formats.key(ext)
                // obrázky se prohledávají, právě když je zapnuté OCR
                if (if (key == "img") !ocr else key !in exts) continue
                val path = if (rel.isEmpty()) rootLabel else "$rootLabel/$rel"
                out.add(FileEntry(Uri.fromFile(f).toString(), name, path, ext, f.length(), f.lastModified()))
                if (out.size % 250 == 0) progress(app.getString(R.string.idx_scanning_n, out.size), 0, 0)
            }
        }
        return true
    }

    private fun deleteDoc(app: App, db: SQLiteDatabase, id: Long) {
        val args = arrayOf(id.toString())
        db.delete("docs", "id = ?", args)
        db.delete("fts", "docid = ?", args)
        Repo.textFile(app, id).delete()
    }

    private fun insertDoc(app: App, db: SQLiteDatabase, f: FileEntry, text: String, err: String?) {
        val cv = ContentValues().apply {
            put("uri", f.uri)
            put("name", f.name)
            put("path", f.path)
            put("ext", f.ext)
            put("size", f.size)
            put("mtime", f.mtime)
            put("chars", text.length.toLong())
            if (err != null) put("error", err) else putNull("error")
        }
        val id = db.insertOrThrow("docs", null, cv)
        val fv = ContentValues().apply {
            put("docid", id)
            put("name", TextFold.norm(f.name))
            put("body", TextFold.norm(text))
        }
        db.insertOrThrow("fts", null, fv)
        if (text.isNotEmpty()) {
            val file = Repo.textFile(app, id)
            file.parentFile?.mkdirs()
            file.writeText(text)
        }
    }
}
