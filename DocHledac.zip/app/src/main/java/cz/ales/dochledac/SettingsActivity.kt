package cz.ales.dochledac

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {
    private val app get() = application as App
    private lateinit var foldersBox: LinearLayout
    private lateinit var excludedBox: LinearLayout
    private lateinit var stats: TextView
    private lateinit var indexStatus: TextView
    private lateinit var progress: ProgressBar
    private var dirty = false
    private var lastVersion = -1

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) onFolderPicked(uri)
    }
    private val pickExcluded = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                addExcluded("id:" + DocumentsContract.getTreeDocumentId(uri))
            } catch (e: Exception) {
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupScreen(R.layout.activity_settings, true)
        supportActionBar?.setTitle(R.string.settings)

        foldersBox = findViewById(R.id.folders)
        excludedBox = findViewById(R.id.excluded)
        stats = findViewById(R.id.stats)
        indexStatus = findViewById(R.id.indexStatus)
        progress = findViewById(R.id.progress)

        findViewById<Button>(R.id.addFolder).setOnClickListener { pickFolder.launch(null) }
        findViewById<Button>(R.id.addExcludedFolder).setOnClickListener { pickExcluded.launch(null) }
        findViewById<Button>(R.id.addExcludedName).setOnClickListener { askExcludedName() }

        // formáty
        val formatsBox = findViewById<LinearLayout>(R.id.formats)
        val selected = app.prefs.exts.toMutableSet()
        for (f in Formats.ALL) {
            val cb = MaterialCheckBox(this)
            cb.setText(f.label)
            cb.isChecked = f.key in selected
            cb.setOnCheckedChangeListener { _, on ->
                if (on) selected.add(f.key) else selected.remove(f.key)
                app.prefs.exts = selected
                dirty = true
            }
            formatsBox.addView(cb)
        }

        val ocr = findViewById<MaterialSwitch>(R.id.ocr)
        ocr.isChecked = app.prefs.ocr
        ocr.setOnCheckedChangeListener { _, on ->
            app.prefs.ocr = on
            dirty = true
            if (on) lifecycleScope.launch(Dispatchers.IO) { Repo.markScannedPdfsDirty(app) }
        }

        // indexace
        val auto = findViewById<MaterialSwitch>(R.id.auto)
        auto.isChecked = app.prefs.autoUpdate
        auto.setOnCheckedChangeListener { _, on -> app.prefs.autoUpdate = on }

        val bg = findViewById<RadioGroup>(R.id.bgGroup)
        bg.check(
            when (app.prefs.bgHours) {
                6 -> R.id.bg6
                12 -> R.id.bg12
                24 -> R.id.bg24
                else -> R.id.bgOff
            }
        )
        bg.setOnCheckedChangeListener { _, id ->
            app.prefs.bgHours = when (id) {
                R.id.bg6 -> 6
                R.id.bg12 -> 12
                R.id.bg24 -> 24
                else -> 0
            }
            BgIndex.apply(this)
        }
        val charging = findViewById<MaterialSwitch>(R.id.bgCharging)
        charging.isChecked = app.prefs.bgChargingOnly
        charging.setOnCheckedChangeListener { _, on ->
            app.prefs.bgChargingOnly = on
            BgIndex.apply(this)
        }

        findViewById<Button>(R.id.reindex).setOnClickListener {
            dirty = false
            Indexer.start(this)
        }
        findViewById<Button>(R.id.clear).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.clear_title)
                .setMessage(R.string.clear_msg)
                .setPositiveButton(R.string.clear_ok) { _, _ -> Indexer.clearIndex(app) }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Indexer.state.collect { s ->
                    progress.visibility = if (s.running) android.view.View.VISIBLE else android.view.View.GONE
                    if (s.running) {
                        if (s.total > 0) {
                            progress.isIndeterminate = false
                            progress.max = s.total
                            progress.progress = s.done
                        } else {
                            progress.isIndeterminate = true
                        }
                    }
                    indexStatus.text = s.message
                    if (s.version != lastVersion) {
                        lastVersion = s.version
                        refreshStats()
                    }
                }
            }
        }

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        findViewById<TextView>(R.id.about).text = getString(R.string.about_text, version)

        renderFolders()
        renderExcluded()
    }

    override fun onStop() {
        super.onStop()
        if (dirty) {
            dirty = false
            Indexer.start(this)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun refreshStats() {
        lifecycleScope.launch {
            val (n, chars) = withContext(Dispatchers.IO) { Repo.stats(app) }
            stats.text = getString(R.string.status_index, qty(R.plurals.files, n), formatChars(this@SettingsActivity, chars))
        }
    }

    private fun onFolderPicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // některé správce souborů trvalé oprávnění nenabízí
        }
        val folders = app.prefs.folders
        if (uri.toString() !in folders) app.prefs.folders = folders + uri.toString()
        renderFolders()
        Indexer.start(this)
    }

    private fun removeFolder(f: String) {
        try {
            contentResolver.releasePersistableUriPermission(Uri.parse(f), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
        app.prefs.folders = app.prefs.folders - f
        renderFolders()
        Indexer.start(this)
    }

    private fun askExcludedName() {
        val input = EditText(this)
        input.setSingleLine()
        input.setHint(R.string.excl_name_hint)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.excl_name_title)
            .setMessage(R.string.excl_name_msg)
            .setView(box)
            .setPositiveButton(R.string.add) { _, _ ->
                val n = input.text.toString().trim().trim('/').lowercase()
                if (n.isNotEmpty()) addExcluded("name:$n")
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun addExcluded(e: String) {
        app.prefs.excluded = app.prefs.excluded + e
        renderExcluded()
        dirty = true
    }

    private fun removeExcluded(e: String) {
        app.prefs.excluded = app.prefs.excluded - e
        renderExcluded()
        dirty = true
    }

    private fun row(box: LinearLayout, label: String, onRemove: () -> Unit) {
        val dp = resources.displayMetrics.density
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(this).apply {
            text = label
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val rm = TextView(this).apply {
            setText(R.string.remove)
            textSize = 14f
            setTextColor(0xFFD32F2F.toInt())
            val p = (12 * dp).toInt()
            setPadding(p, p, p, p)
            setOnClickListener { onRemove() }
        }
        r.addView(tv)
        r.addView(rm)
        box.addView(r)
    }

    private fun emptyNote(box: LinearLayout, res: Int) {
        box.addView(TextView(this).apply {
            setText(res)
            alpha = 0.7f
            setPadding(0, 8, 0, 8)
        })
    }

    private fun renderFolders() {
        foldersBox.removeAllViews()
        val folders = app.prefs.folders
        val granted = contentResolver.persistedUriPermissions.map { it.uri.toString() }.toSet()
        if (folders.isEmpty()) emptyNote(foldersBox, R.string.no_folders)
        for (f in folders) {
            val label = Paths.label(this, Uri.parse(f)) + (if (f !in granted) "  " + getString(R.string.folder_no_access) else "")
            row(foldersBox, label) { removeFolder(f) }
        }
    }

    private fun renderExcluded() {
        excludedBox.removeAllViews()
        val ex = app.prefs.excluded.sorted()
        if (ex.isEmpty()) emptyNote(excludedBox, R.string.no_excluded)
        for (e in ex) {
            val label = when {
                e.startsWith("id:") -> Paths.labelOfDocId(this, e.removePrefix("id:"))
                else -> getString(R.string.excl_name_item, e.removePrefix("name:"))
            }
            row(excludedBox, label) { removeExcluded(e) }
        }
    }
}
