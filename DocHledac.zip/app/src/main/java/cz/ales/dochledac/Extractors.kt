package cz.ales.dochledac

import android.net.Uri
import android.text.Html
import android.util.Xml
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

/** Vytažení čistého textu ze souborů. Části (stránky, snímky, listy, kapitoly) odděluje znak \u000C. */
object Extractors {
    private const val MAX_BYTES = 80L * 1024 * 1024
    private const val FF = '\u000C'

    fun extract(app: App, uri: Uri, ext: String, size: Long): String {
        if (size > MAX_BYTES) throw IOException(app.getString(R.string.err_too_big, (size / 1048576).toInt()))
        val cr = app.contentResolver
        fun open(): InputStream = cr.openInputStream(uri) ?: throw IOException(app.getString(R.string.err_open))
        fun bytes(): ByteArray = open().use { it.readBytes() }
        return when (Formats.key(ext)) {
            "pdf" -> pdf(app, uri, open())
            "docx" -> docx(bytes())
            "xlsx" -> xlsx(bytes())
            "pptx" -> pptx(bytes())
            "odt", "ods", "odp" -> odf(bytes(), Formats.key(ext))
            "epub" -> epub(bytes())
            "fb2" -> fb2(bytes())
            "rtf" -> rtf(bytes())
            "html" -> html(decode(bytes()))
            "img" -> Ocr.image(app, uri)
            else -> decode(bytes())
        }
    }

    // ---------- prostý text ----------

    /** Automatické rozpoznání kódování: BOM, UTF-16, UTF-8, jinak windows-1250 (čeština). */
    fun decode(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        val probe = minOf(b.size, 4000)
        if (probe >= 4) {
            var zeroEven = 0
            var zeroOdd = 0
            for (i in 0 until probe) if (b[i] == 0.toByte()) { if (i % 2 == 0) zeroEven++ else zeroOdd++ }
            if (zeroOdd > probe / 4 && zeroEven < probe / 50) return String(b, Charsets.UTF_16LE)
            if (zeroEven > probe / 4 && zeroOdd < probe / 50) return String(b, Charsets.UTF_16BE)
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b))
                .toString()
        } catch (e: CharacterCodingException) {
            String(b, Charset.forName("windows-1250"))
        }
    }

    private fun html(s: String): String {
        val cleaned = s.replace(Regex("(?is)<head[^>]*>.*?</head>"), " ")
            .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
        return Html.fromHtml(cleaned, Html.FROM_HTML_MODE_LEGACY).toString()
    }

    // ---------- PDF (+ OCR naskenovaných stránek) ----------

    private fun pdf(app: App, uri: Uri, input: InputStream): String {
        val pages = ArrayList<String>()
        input.use {
            PDDocument.load(it).use { doc ->
                val st = PDFTextStripper()
                for (p in 1..doc.numberOfPages) {
                    st.startPage = p
                    st.endPage = p
                    pages.add(st.getText(doc))
                }
            }
        }
        if (app.prefs.ocr) {
            val scanned = pages.indices.filter { pages[it].trim().length < 15 }
            if (scanned.isNotEmpty()) {
                for ((i, t) in Ocr.pdfPages(app, uri, scanned)) pages[i] = t + "\n"
            }
        }
        return pages.joinToString("") { it + FF }
    }

    // ---------- ZIP + XML formáty ----------

    private fun unzip(data: ByteArray, want: (String) -> Boolean): Map<String, ByteArray> {
        val out = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(data)).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (!e.isDirectory && want(e.name)) out[e.name] = z.readBytes()
            }
        }
        return out
    }

    private fun parser(b: ByteArray): XmlPullParser {
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        try {
            p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
        } catch (e: Exception) {
        }
        p.setInput(ByteArrayInputStream(b), null)
        return p
    }

    private fun docx(data: ByteArray): String {
        val z = unzip(data) { it == "word/document.xml" }
        val b = z["word/document.xml"] ?: throw IOException("word/document.xml")
        val p = parser(b)
        val sb = StringBuilder()
        var inText = false
        var inTabs = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "w:t" -> inText = true
                    "w:tabs" -> inTabs = true
                    "w:tab" -> if (!inTabs) sb.append('\t')
                    "w:br", "w:cr" -> sb.append('\n')
                }
                XmlPullParser.END_TAG -> when (p.name) {
                    "w:t" -> inText = false
                    "w:tabs" -> inTabs = false
                    "w:p" -> sb.append('\n')
                }
                XmlPullParser.TEXT -> if (inText) sb.append(p.text)
            }
            ev = p.next()
        }
        return sb.toString()
    }

    private fun numberIn(name: String): Int = Regex("(\\d+)\\.xml$").find(name)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    private fun xlsx(data: ByteArray): String {
        val z = unzip(data) { it == "xl/sharedStrings.xml" || (it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml")) }
        val shared = ArrayList<String>()
        z["xl/sharedStrings.xml"]?.let { b ->
            val p = parser(b)
            var cur: StringBuilder? = null
            var inT = false
            var inRph = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "si" -> cur = StringBuilder()
                        "rPh" -> inRph = true
                        "t" -> inT = true
                    }
                    XmlPullParser.END_TAG -> when (p.name) {
                        "si" -> shared.add(cur?.toString() ?: "")
                        "rPh" -> inRph = false
                        "t" -> inT = false
                    }
                    XmlPullParser.TEXT -> if (inT && !inRph) cur?.append(p.text)
                }
                ev = p.next()
            }
        }
        val sb = StringBuilder()
        for (name in z.keys.filter { it.startsWith("xl/worksheets/") }.sortedBy { numberIn(it) }) {
            val p = parser(z[name] ?: continue)
            val row = ArrayList<String>()
            var type: String? = null
            var cell = StringBuilder()
            var inV = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "row" -> row.clear()
                        "c" -> {
                            type = p.getAttributeValue(null, "t")
                            cell = StringBuilder()
                        }
                        "v", "t" -> inV = true
                    }
                    XmlPullParser.END_TAG -> when (p.name) {
                        "v", "t" -> inV = false
                        "c" -> {
                            val raw = cell.toString()
                            row.add(if (type == "s") shared.getOrNull(raw.trim().toIntOrNull() ?: -1) ?: "" else raw)
                        }
                        "row" -> if (row.any { it.isNotBlank() }) sb.append(row.joinToString("\t")).append('\n')
                    }
                    XmlPullParser.TEXT -> if (inV) cell.append(p.text)
                }
                ev = p.next()
            }
            sb.append(FF)
        }
        return sb.toString()
    }

    private fun pptx(data: ByteArray): String {
        val z = unzip(data) { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }
        val sb = StringBuilder()
        for (name in z.keys.sortedBy { numberIn(it) }) {
            val p = parser(z[name] ?: continue)
            var inT = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> when (p.name) {
                        "a:t" -> inT = true
                        "a:br" -> sb.append('\n')
                    }
                    XmlPullParser.END_TAG -> when (p.name) {
                        "a:t" -> inT = false
                        "a:p" -> sb.append('\n')
                    }
                    XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                }
                ev = p.next()
            }
            sb.append(FF)
        }
        return sb.toString()
    }

    /** OpenDocument: odt (text), ods (tabulky – list = část), odp (prezentace – snímek = část). */
    private fun odf(data: ByteArray, kind: String): String {
        val z = unzip(data) { it == "content.xml" }
        val p = parser(z["content.xml"] ?: throw IOException("content.xml"))
        val sb = StringBuilder()
        var inBody = false
        var cellDepth = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "office:body" -> inBody = true
                    "table:table-cell" -> cellDepth++
                    "text:s" -> {
                        val c = p.getAttributeValue(null, "text:c")?.toIntOrNull() ?: 1
                        repeat(c.coerceIn(1, 100)) { sb.append(' ') }
                    }
                    "text:tab" -> sb.append('\t')
                    "text:line-break" -> sb.append('\n')
                }
                XmlPullParser.END_TAG -> when (p.name) {
                    "office:body" -> inBody = false
                    "text:p", "text:h" -> sb.append(if (cellDepth > 0) ' ' else '\n')
                    "table:table-cell" -> {
                        cellDepth--
                        sb.append('\t')
                    }
                    "table:table-row" -> sb.append('\n')
                    "table:table" -> if (kind == "ods") sb.append(FF)
                    "draw:page" -> if (kind == "odp") sb.append(FF)
                }
                XmlPullParser.TEXT -> if (inBody) sb.append(p.text)
            }
            ev = p.next()
        }
        return sb.toString()
    }

    // ---------- e-knihy ----------

    private fun attr(tag: String, name: String): String? =
        Regex("\\b$name\\s*=\\s*[\"']([^\"']*)[\"']").find(tag)?.groupValues?.get(1)

    private fun resolve(base: String, href: String): String {
        val parts = ArrayList<String>()
        if (base.isNotEmpty()) parts.addAll(base.split('/'))
        for (s in href.split('/')) {
            when (s) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                else -> parts.add(s)
            }
        }
        return parts.joinToString("/")
    }

    private fun epub(data: ByteArray): String {
        val z = unzip(data) { n ->
            val l = n.lowercase()
            l == "meta-inf/container.xml" || l.endsWith(".opf") || l.endsWith(".xhtml") || l.endsWith(".html") || l.endsWith(".htm")
        }
        val containerKey = z.keys.firstOrNull { it.lowercase() == "meta-inf/container.xml" }
        val container = containerKey?.let { z[it]?.toString(Charsets.UTF_8) }
        val opfPath = container?.let { attr(it, "full-path") } ?: z.keys.firstOrNull { it.lowercase().endsWith(".opf") }
        val order = ArrayList<String>()
        val opfBytes = opfPath?.let { z[it] }
        if (opfPath != null && opfBytes != null) {
            val opf = opfBytes.toString(Charsets.UTF_8)
            val base = opfPath.substringBeforeLast('/', "")
            val items = HashMap<String, String>()
            for (m in Regex("<(?:opf:)?item\\b[^>]*>").findAll(opf)) {
                val id = attr(m.value, "id") ?: continue
                val href = attr(m.value, "href") ?: continue
                items[id] = href
            }
            for (m in Regex("<(?:opf:)?itemref\\b[^>]*>").findAll(opf)) {
                val idref = attr(m.value, "idref") ?: continue
                val href = items[idref] ?: continue
                order.add(resolve(base, Uri.decode(href.substringBefore('#'))))
            }
        }
        if (order.none { z.containsKey(it) }) {
            order.clear()
            order.addAll(z.keys.filter { val l = it.lowercase(); l.endsWith("html") || l.endsWith(".htm") }.sorted())
        }
        val sb = StringBuilder()
        for (path in order) {
            val b = z[path] ?: continue
            val t = html(decode(b)).trim()
            if (t.isEmpty()) continue
            sb.append(t).append('\n').append(FF)
        }
        return sb.toString()
    }

    private fun fb2(data: ByteArray): String {
        val p = parser(data)
        val sb = StringBuilder()
        var inBinary = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "binary" -> inBinary = true
                    "empty-line" -> sb.append('\n')
                }
                XmlPullParser.END_TAG -> when (p.name) {
                    "binary" -> inBinary = false
                    "p", "v", "title", "subtitle", "text-author", "book-title", "author" -> sb.append('\n')
                }
                XmlPullParser.TEXT -> if (!inBinary) {
                    val t = p.text
                    if (t.isNotBlank()) sb.append(t)
                }
            }
            ev = p.next()
        }
        return sb.toString()
    }

    // ---------- RTF ----------

    private class RtfState(var skip: Boolean, var uc: Int) {
        fun copy() = RtfState(skip, uc)
    }

    private val RTF_SKIP = setOf(
        "fonttbl", "colortbl", "stylesheet", "info", "pict", "object", "header", "footer",
        "headerl", "headerr", "footerl", "footerr", "headerf", "footerf", "themedata", "colorschememapping",
        "datastore", "latentstyles", "listtable", "listoverridetable", "rsidtbl", "generator",
        "xmlnstbl", "mmathPr", "fldinst", "filetbl", "revtbl", "pgdsctbl", "bkmkstart", "bkmkend",
    )

    private fun rtf(b: ByteArray): String {
        val s = String(b, Charsets.ISO_8859_1)
        val out = StringBuilder()
        var cs: Charset = Charset.forName("windows-1252")
        val pending = ByteArrayOutputStream()
        fun flush() {
            if (pending.size() > 0) {
                out.append(String(pending.toByteArray(), cs))
                pending.reset()
            }
        }
        val stack = ArrayDeque<RtfState>()
        var cur = RtfState(false, 1)
        var skipChars = 0
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '{') {
                flush()
                stack.addLast(cur.copy())
                i++
            } else if (c == '}') {
                flush()
                cur = if (stack.isNotEmpty()) stack.removeLast() else RtfState(false, 1)
                i++
            } else if (c == '\\' && i + 1 < s.length) {
                val n = s[i + 1]
                if (n == '\'') {
                    val hex = s.substring(minOf(i + 2, s.length), minOf(i + 4, s.length))
                    i += 4
                    if (skipChars > 0) skipChars--
                    else if (!cur.skip) hex.toIntOrNull(16)?.let { pending.write(it) }
                } else if (n == '*') {
                    cur.skip = true
                    i += 2
                } else if (n.isLetter()) {
                    var j = i + 1
                    while (j < s.length && s[j].isLetter()) j++
                    val word = s.substring(i + 1, j)
                    var k = j
                    if (k < s.length && (s[k] == '-' || s[k].isDigit())) {
                        k++
                        while (k < s.length && s[k].isDigit()) k++
                    }
                    val param = s.substring(j, k).toIntOrNull()
                    if (k < s.length && s[k] == ' ') k++
                    i = k
                    flush()
                    val visible = !cur.skip
                    when (word) {
                        "par", "line", "sect", "page", "row" -> if (visible) out.append('\n')
                        "tab", "cell" -> if (visible) out.append('\t')
                        "ansicpg" -> if (param != null) {
                            try {
                                cs = Charset.forName("windows-$param")
                            } catch (e: Exception) {
                            }
                        }
                        "uc" -> cur.uc = param ?: 1
                        "u" -> {
                            if (visible && param != null) out.append((if (param < 0) param + 65536 else param).toChar())
                            skipChars = cur.uc
                        }
                        "emdash" -> if (visible) out.append('—')
                        "endash" -> if (visible) out.append('–')
                        "lquote" -> if (visible) out.append('‘')
                        "rquote" -> if (visible) out.append('’')
                        "ldblquote" -> if (visible) out.append('“')
                        "rdblquote" -> if (visible) out.append('”')
                        "bullet" -> if (visible) out.append('•')
                        else -> if (word in RTF_SKIP) cur.skip = true
                    }
                } else {
                    // řídicí symboly: \\ \{ \} \~ \- \_ a \<konec řádku> (= odstavec)
                    flush()
                    if (!cur.skip) {
                        when (n) {
                            '\\', '{', '}' -> out.append(n)
                            '~' -> out.append(' ')
                            '_' -> out.append('-')
                            '\n', '\r' -> out.append('\n')
                        }
                    }
                    i += 2
                }
            } else if (c == '\r' || c == '\n') {
                i++
            } else {
                if (skipChars > 0) {
                    skipChars--
                } else if (!cur.skip) {
                    flush()
                    out.append(c)
                }
                i++
            }
        }
        flush()
        return out.toString()
    }
}
