package cz.ales.dochledac

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var folders: List<String>
        get() = (sp.getStringSet("folders", null) ?: emptySet()).sorted()
        set(v) = sp.edit().putStringSet("folders", HashSet(v)).apply()

    var exts: Set<String>
        get() = sp.getStringSet("exts", null)?.toSet() ?: DEFAULT_EXTS
        set(v) = sp.edit().putStringSet("exts", HashSet(v)).apply()

    /** Vyloučené složky: "id:<documentId>" nebo "name:<název složky malými písmeny>". */
    var excluded: Set<String>
        get() = sp.getStringSet("excluded", null)?.toSet() ?: emptySet()
        set(v) = sp.edit().putStringSet("excluded", HashSet(v)).apply()

    var autoUpdate: Boolean
        get() = sp.getBoolean("auto", true)
        set(v) = sp.edit().putBoolean("auto", v).apply()

    /** Indexace na pozadí: 0 = vypnuto, jinak interval v hodinách. */
    var bgHours: Int
        get() = sp.getInt("bgHours", 0)
        set(v) = sp.edit().putInt("bgHours", v).apply()

    var bgChargingOnly: Boolean
        get() = sp.getBoolean("bgCharging", true)
        set(v) = sp.edit().putBoolean("bgCharging", v).apply()

    var ocr: Boolean
        get() = sp.getBoolean("ocr", false)
        set(v) = sp.edit().putBoolean("ocr", v).apply()

    var mode: Int
        get() = sp.getInt("mode", Query.MODE_WORDS)
        set(v) = sp.edit().putInt("mode", v).apply()

    var sort: Int
        get() = sp.getInt("sort", SORT_HITS)
        set(v) = sp.edit().putInt("sort", v).apply()

    var viewerTextSize: Float
        get() = sp.getFloat("viewerTextSize", 14f)
        set(v) = sp.edit().putFloat("viewerTextSize", v).apply()

    companion object {
        val DEFAULT_EXTS = setOf("txt", "srt", "md", "pdf", "docx", "epub")
        const val SORT_HITS = 0
        const val SORT_NAME = 1
        const val SORT_DATE = 2
    }
}
