package cz.ales.dochledac

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    companion object {
        const val ACTION_SEARCH = "cz.ales.dochledac.SEARCH"
        const val ACTION_REINDEX = "cz.ales.dochledac.REINDEX"
    }

    private val app get() = application as App
    private lateinit var search: TextInputEditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var pickFirst: Button
    private lateinit var adapter: ResultsAdapter
    private var mode = Query.MODE_WORDS
    private var searchJob: Job? = null
    private var lastVersion = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupScreen(R.layout.activity_main, false)
        search = findViewById(R.id.search)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        pickFirst = findViewById(R.id.pickFirst)

        val list = findViewById<RecyclerView>(R.id.list)
        adapter = ResultsAdapter(
            onOpen = { doc, line -> openViewer(doc, line) },
            onExternal = { doc, chooser -> openExternal(this, doc, chooser) },
        )
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) hideKeyboard()
            }
        })

        mode = app.prefs.mode
        val group = findViewById<ChipGroup>(R.id.modeGroup)
        group.check(
            when (mode) {
                Query.MODE_ANYWHERE -> R.id.chipAnywhere
                Query.MODE_NAMES -> R.id.chipNames
                else -> R.id.chipWords
            }
        )
        group.setOnCheckedStateChangeListener { _, ids ->
            mode = when {
                ids.contains(R.id.chipAnywhere) -> Query.MODE_ANYWHERE
                ids.contains(R.id.chipNames) -> Query.MODE_NAMES
                else -> Query.MODE_WORDS
            }
            app.prefs.mode = mode
            runSearch(0)
        }

        search.doAfterTextChanged { runSearch(180) }
        search.setOnEditorActionListener { _, _, _ ->
            hideKeyboard()
            runSearch(0)
            true
        }
        pickFirst.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Indexer.state.collect { renderIndex(it) }
            }
        }

        if (savedInstanceState == null) {
            if (app.prefs.autoUpdate && app.prefs.folders.isNotEmpty()) Indexer.start(this)
            handleIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Zkratky ikony, widget, „Hledat v DocHledači“ z označeného textu a sdílení textu. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val text: String? = when (i.action) {
            Intent.ACTION_PROCESS_TEXT -> i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        }
        when {
            text != null && text.isNotBlank() -> {
                search.setText(text.trim().take(200))
                search.setSelection(search.text?.length ?: 0)
                runSearch(0)
            }
            i.action == ACTION_SEARCH -> focusSearch()
            i.action == ACTION_REINDEX -> if (app.prefs.folders.isNotEmpty()) Indexer.start(this)
        }
    }

    private fun focusSearch() {
        search.requestFocus()
        search.post { WindowCompat.getInsetsController(window, search).show(WindowInsetsCompat.Type.ime()) }
    }

    override fun onResume() {
        super.onResume()
        ThemeMode.apply(app) // u režimu „podle západu slunce“ se téma přepne samo
        pickFirst.visibility = if (app.prefs.folders.isEmpty()) View.VISIBLE else View.GONE
        if (search.text.isNullOrBlank()) showIdle()
    }

    private fun renderIndex(s: IndexState) {
        if (s.running) {
            progress.visibility = View.VISIBLE
            if (s.total > 0) {
                progress.isIndeterminate = false
                progress.max = s.total
                progress.progress = s.done
            } else {
                progress.isIndeterminate = true
            }
            if (search.text.isNullOrBlank()) status.text = s.message
        } else {
            progress.visibility = View.GONE
            if (s.version != lastVersion) {
                lastVersion = s.version
                runSearch(0) // nový obsah indexu -> obnovit výsledky
            }
        }
    }

    private fun showIdle() {
        val st = Indexer.state.value
        if (st.running) {
            status.text = st.message
            return
        }
        lifecycleScope.launch {
            val (n, chars) = withContext(Dispatchers.IO) { Repo.stats(app) }
            if (!search.text.isNullOrBlank()) return@launch
            status.text = if (app.prefs.folders.isEmpty()) {
                getString(R.string.status_no_folder)
            } else {
                getString(R.string.status_index, qty(R.plurals.files, n), formatChars(this@MainActivity, chars)) +
                    (if (st.message.isNotEmpty()) "\n" + st.message else "")
            }
        }
    }

    private fun runSearch(delayMs: Long) {
        searchJob?.cancel()
        val q = search.text?.toString().orEmpty().trim()
        val m = mode
        val sort = app.prefs.sort
        searchJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            if (q.isEmpty()) {
                adapter.submit(emptyList())
                showIdle()
                return@launch
            }
            val t0 = SystemClock.elapsedRealtime()
            val res = try {
                withContext(Dispatchers.Default) { Searcher.search(app, q, m, sort) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status.text = getString(R.string.search_error, e.message ?: "")
                return@launch
            }
            val ms = SystemClock.elapsedRealtime() - t0
            adapter.submit(res.files)
            status.text = if (res.files.isEmpty()) {
                getString(R.string.status_nothing, ms)
            } else {
                getString(
                    R.string.status_found,
                    qty(R.plurals.files, res.files.size) + (if (res.truncated) "+" else ""),
                    qty(R.plurals.hits, res.totalHits),
                    ms,
                )
            }
        }
    }

    private fun openViewer(doc: Doc, line: Int) {
        hideKeyboard()
        startActivity(
            Intent(this, ViewerActivity::class.java)
                .putExtra(ViewerActivity.EXTRA_DOC, doc.id)
                .putExtra(ViewerActivity.EXTRA_QUERY, search.text?.toString().orEmpty())
                .putExtra(ViewerActivity.EXTRA_MODE, mode)
                .putExtra(ViewerActivity.EXTRA_LINE, line)
        )
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val id = when (app.prefs.sort) {
            Prefs.SORT_NAME -> R.id.sort_name
            Prefs.SORT_DATE -> R.id.sort_date
            else -> R.id.sort_hits
        }
        menu.findItem(id)?.isChecked = true
        return super.onPrepareOptionsMenu(menu)
    }

    private fun setSort(s: Int, item: MenuItem): Boolean {
        app.prefs.sort = s
        item.isChecked = true
        runSearch(0)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_refresh -> {
            if (app.prefs.folders.isEmpty()) startActivity(Intent(this, SettingsActivity::class.java))
            else Indexer.start(this)
            true
        }
        R.id.action_settings -> {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }
        R.id.sort_hits -> setSort(Prefs.SORT_HITS, item)
        R.id.sort_name -> setSort(Prefs.SORT_NAME, item)
        R.id.sort_date -> setSort(Prefs.SORT_DATE, item)
        R.id.action_help -> {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.help_title)
                .setMessage(R.string.help_text)
                .setPositiveButton(android.R.string.ok, null)
                .show()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}
