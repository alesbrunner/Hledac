package cz.ales.dochledac

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.text.format.DateUtils
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.text.HtmlCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Toast
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    companion object {
        const val ACTION_SEARCH = "cz.ales.dochledac.SEARCH"
        const val ACTION_REINDEX = "cz.ales.dochledac.REINDEX"
    }

    private val app get() = application as App
    private lateinit var search: TextInputEditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var pickFirst: Button
    private lateinit var adapter: ResultsAdapter
    private var mode = Query.MODE_WORDS
    private var searchJob: Job? = null
    private var lastVersion = -1
    private var lastResults: List<FileResult> = emptyList()
    private var filterExt: String? = null // null = všechny typy
    private lateinit var historyScroll: View
    private lateinit var historyGroup: ChipGroup
    private lateinit var filterScroll: View
    private lateinit var filterGroup: ChipGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupScreen(R.layout.activity_main, false)
        search = findViewById(R.id.search)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        pickFirst = findViewById(R.id.pickFirst)
        historyScroll = findViewById(R.id.historyScroll)
        historyGroup = findViewById(R.id.historyGroup)
        filterScroll = findViewById(R.id.filterScroll)
        filterGroup = findViewById(R.id.filterGroup)

        val list = findViewById<RecyclerView>(R.id.list)
        adapter = ResultsAdapter(
            onOpen = { doc, line -> openViewer(doc, line) },
            onExternal = { doc, chooser ->
                rememberQuery()
                if (chooser) AppPicker.pick(this, doc, false) else AppPicker.openDefault(this, doc)
            },
        )
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.addItemDecoration(ResultDivider())
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) hideKeyboard()
            }
        })

        mode = app.prefs.mode
        val group = findViewById<ChipGroup>(R.id.modeGroup)
        group.check(
            when (mode) {
                Query.MODE_ANYWHERE -> R.id.chipAnywhere
                Query.MODE_NAMES -> R.id.chipNames
                else -> R.id.chipWords
            }
        )
        group.setOnCheckedStateChangeListener { _, ids ->
            mode = when {
                ids.contains(R.id.chipAnywhere) -> Query.MODE_ANYWHERE
                ids.contains(R.id.chipNames) -> Query.MODE_NAMES
                else -> Query.MODE_WORDS
            }
            app.prefs.mode = mode
            runSearch(0)
        }

        search.doAfterTextChanged { runSearch(180) }
        search.setOnEditorActionListener { _, _, _ ->
            rememberQuery()
            hideKeyboard()
            runSearch(0)
            true
        }
        pickFirst.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        setupKeyBar()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Indexer.state.collect { renderIndex(it) }
            }
        }

        if (savedInstanceState == null) {
            if (app.prefs.autoUpdate && app.prefs.folders.isNotEmpty()) Indexer.start(this)
            handleIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Zkratky ikony, widget, „Hledat v DocHledači“ z označeného textu a sdílení textu. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val text: String? = when (i.action) {
            Intent.ACTION_PROCESS_TEXT -> i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        }
        when {
            text != null && text.isNotBlank() -> {
                search.setText(text.trim().take(200))
                search.setSelection(search.text?.length ?: 0)
                runSearch(0)
            }
            i.action == ACTION_SEARCH -> focusSearch()
            i.action == ACTION_REINDEX -> if (app.prefs.folders.isNotEmpty()) Indexer.start(this)
        }
    }

    private fun focusSearch() {
        search.requestFocus()
        search.post { WindowCompat.getInsetsController(window, search).show(WindowInsetsCompat.Type.ime()) }
    }

    override fun onResume() {
        super.onResume()
        ThemeMode.apply(app) // u režimu „podle západu slunce“ se téma přepne samo
        pickFirst.visibility = if (app.prefs.folders.isEmpty()) View.VISIBLE else View.GONE
        if (search.text.isNullOrBlank()) {
            showIdle()
            showHistory()
        }
    }

    private fun renderIndex(s: IndexState) {
        if (s.running) {
            progress.visibility = View.VISIBLE
            if (s.total > 0) {
                progress.isIndeterminate = false
                progress.max = s.total
                progress.progress = s.done
            } else {
                progress.isIndeterminate = true
            }
            if (search.text.isNullOrBlank()) status.text = s.message
        } else {
            progress.visibility = View.GONE
            if (s.version != lastVersion) {
                lastVersion = s.version
                runSearch(0) // nový obsah indexu -> obnovit výsledky
            }
        }
    }

    private fun showIdle() {
        val st = Indexer.state.value
        if (st.running) {
            status.text = st.message
            return
        }
        lifecycleScope.launch {
            val (n, chars) = withContext(Dispatchers.IO) { Repo.stats(app) }
            if (!search.text.isNullOrBlank()) return@launch
            status.text = if (app.prefs.folders.isEmpty()) {
                getString(R.string.status_no_folder)
            } else {
                getString(R.string.status_main, qty(R.plurals.files, n), lastIndexedText()) +
                    (if (st.note.isNotEmpty()) " · " + st.note else "")
            }
        }
    }

    /** „před 5 minutami“, „včera 17:05“… podle jazyka telefonu */
    private fun lastIndexedText(): String {
        val t = app.prefs.lastIndexed
        if (t <= 0L) return getString(R.string.never_indexed)
        val now = System.currentTimeMillis()
        return if (now - t < DateUtils.MINUTE_IN_MILLIS) getString(R.string.just_now)
        else DateUtils.getRelativeTimeSpanString(t, now, DateUtils.MINUTE_IN_MILLIS).toString().lowercase()
    }

    private fun runSearch(delayMs: Long) {
        searchJob?.cancel()
        val q = search.text?.toString().orEmpty().trim()
        val m = mode
        val sort = app.prefs.sort
        searchJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            if (q.isEmpty()) {
                lastResults = emptyList()
                filterScroll.visibility = View.GONE
                adapter.submit(emptyList())
                showHistory()
                showIdle()
                return@launch
            }
            historyScroll.visibility = View.GONE
            val t0 = SystemClock.elapsedRealtime()
            val res = try {
                withContext(Dispatchers.Default) { Searcher.search(app, q, m, sort) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status.text = getString(R.string.search_error, e.message ?: "")
                return@launch
            }
            val ms = SystemClock.elapsedRealtime() - t0
            lastResults = res.files
            buildFilters()
            status.text = if (res.files.isEmpty()) {
                getString(R.string.status_nothing, ms)
            } else {
                getString(
                    R.string.status_found,
                    qty(R.plurals.files, res.files.size) + (if (res.truncated) "+" else ""),
                    qty(R.plurals.hits, res.totalHits),
                    ms,
                )
            }
        }
    }

    /** Nápověda s nadpisy a příklady (HTML z textů aplikace). */
    private fun showHelp() {
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            text = HtmlCompat.fromHtml(getString(R.string.help_text), HtmlCompat.FROM_HTML_MODE_LEGACY)
            textSize = 15f
            setLineSpacing(0f, 1.15f)
            val p = (24 * dp).toInt()
            setPadding(p, (8 * dp).toInt(), p, (8 * dp).toInt())
        }
        val sv = ScrollView(this)
        sv.addView(tv)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.help_title)
            .setView(sv)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    // ---------- lišta nad klávesnicí ----------

    private fun setupKeyBar() {
        val bar = findViewById<View>(R.id.keyBar)
        val root = findViewById<View>(R.id.root)
        // viditelná jen při psaní do hledání (klávesnice je otevřená)
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val ime = ViewCompat.getRootWindowInsets(root)?.isVisible(WindowInsetsCompat.Type.ime()) == true
            val show = ime && search.hasFocus()
            val v = if (show) View.VISIBLE else View.GONE
            if (bar.visibility != v) bar.visibility = v
        }
        findViewById<View>(R.id.keyQuote).setOnClickListener { wrapQuotes() }
        findViewById<View>(R.id.keyOr).setOnClickListener { insertAtCursor(" | ") }
        val stem = findViewById<Chip>(R.id.keyStem)
        stem.isChecked = app.prefs.stem
        stem.setOnCheckedChangeListener { _, on ->
            app.prefs.stem = on
            runSearch(0)
        }
    }

    /** Hranice slova kolem kurzoru (nebo označený text). */
    private fun wordRange(): IntRange? {
        val t = search.text ?: return null
        var s = search.selectionStart.coerceIn(0, t.length)
        var e = search.selectionEnd.coerceIn(0, t.length)
        if (s > e) s = e.also { e = s }
        if (s != e) return s until e
        while (s > 0 && !t[s - 1].isWhitespace()) s--
        while (e < t.length && !t[e].isWhitespace()) e++
        return if (s < e) s until e else null
    }

    /** Obalí slovo u kurzoru uvozovkami; když tam žádné není, vloží "" s kurzorem uprostřed. */
    private fun wrapQuotes() {
        val t = search.text ?: return
        val r = wordRange()
        if (r == null) {
            val c = search.selectionStart.coerceIn(0, t.length)
            t.insert(c, "\"\"")
            search.setSelection(c + 1)
            return
        }
        val word = t.substring(r.first, r.last + 1).trim('"', '„', '“', '”')
        t.replace(r.first, r.last + 1, "\"$word\"")
        search.setSelection((r.first + word.length + 2).coerceAtMost(t.length))
    }

    private fun insertAtCursor(s: String) {
        val t = search.text ?: return
        val c = search.selectionStart.coerceIn(0, t.length)
        var ins = s
        if (c > 0 && t[c - 1] == ' ') ins = ins.trimStart()
        t.insert(c, ins)
        search.setSelection((c + ins.length).coerceAtMost(t.length))
    }

    // ---------- nejčastější hledání ----------

    private fun rememberQuery() {
        val q = search.text?.toString().orEmpty().trim()
        if (q.isNotEmpty()) app.prefs.recordSearch(q)
    }

    private fun showHistory() {
        historyGroup.removeAllViews()
        val top = app.prefs.topSearches(10)
        historyScroll.visibility = if (top.isEmpty()) View.GONE else View.VISIBLE
        for (q in top) {
            val chip = layoutInflater.inflate(R.layout.chip_history, historyGroup, false) as Chip
            chip.text = q
            chip.setOnClickListener {
                search.setText(q)
                search.setSelection(q.length)
            }
            chip.setOnLongClickListener {
                app.prefs.removeSearch(q)
                Toast.makeText(this, R.string.history_removed, Toast.LENGTH_SHORT).show()
                showHistory()
                true
            }
            historyGroup.addView(chip)
        }
    }

    // ---------- filtr podle přípony ----------

    private fun buildFilters() {
        val counts = lastResults.groupingBy { it.doc.ext.uppercase() }.eachCount()
        if (counts.size < 2) {
            filterExt = null
            filterScroll.visibility = View.GONE
            adapter.submit(lastResults)
            return
        }
        if (filterExt != null && filterExt !in counts) filterExt = null
        filterGroup.removeAllViews()
        fun addChip(label: String, ext: String?) {
            val chip = layoutInflater.inflate(R.layout.chip_filter, filterGroup, false) as Chip
            chip.text = label
            filterGroup.addView(chip)
            chip.isChecked = ext == filterExt
            chip.setOnClickListener {
                filterExt = ext
                chip.isChecked = true
                applyFilter()
            }
        }
        addChip(getString(R.string.filter_all, lastResults.size), null)
        for ((ext, n) in counts.entries.sortedByDescending { it.value }) addChip("$ext ($n)", ext)
        filterScroll.visibility = View.VISIBLE
        applyFilter()
    }

    private fun applyFilter() {
        val f = filterExt
        adapter.submit(if (f == null) lastResults else lastResults.filter { it.doc.ext.uppercase() == f })
    }

    private fun openViewer(doc: Doc, line: Int) {
        rememberQuery()
        hideKeyboard()
        startActivity(
            Intent(this, ViewerActivity::class.java)
                .putExtra(ViewerActivity.EXTRA_DOC, doc.id)
                .putExtra(ViewerActivity.EXTRA_QUERY, search.text?.toString().orEmpty())
                .putExtra(ViewerActivity.EXTRA_MODE, mode)
                .putExtra(ViewerActivity.EXTRA_LINE, line)
        )
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val id = when (app.prefs.sort) {
            Prefs.SORT_NAME -> R.id.sort_name
            Prefs.SORT_DATE -> R.id.sort_date
            else -> R.id.sort_hits
        }
        menu.findItem(id)?.isChecked = true
        return super.onPrepareOptionsMenu(menu)
    }

    private fun setSort(s: Int, item: MenuItem): Boolean {
        app.prefs.sort = s
        item.isChecked = true
        runSearch(0)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_refresh -> {
            if (app.prefs.folders.isEmpty()) startActivity(Intent(this, SettingsActivity::class.java))
            else Indexer.start(this)
            true
        }
        R.id.action_settings -> {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }
        R.id.sort_hits -> setSort(Prefs.SORT_HITS, item)
        R.id.sort_name -> setSort(Prefs.SORT_NAME, item)
        R.id.sort_date -> setSort(Prefs.SORT_DATE, item)
        R.id.action_help -> {
            showHelp()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}
