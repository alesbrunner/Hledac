package cz.ales.dochledac

/** Slovo nebo fráze (více slov za sebou), normalizované. */
class Term(val tokens: List<String>) {
    val isPhrase: Boolean get() = tokens.size > 1
}

/**
 * Dotaz:  slovo slovo   = obě slova (A ZÁROVEŇ)
 *         "přesná fráze"
 *         -slovo         = soubor nesmí obsahovat
 *         a | b, a OR b  = aspoň jedno
 */
class Query(raw: String, val mode: Int) {
    companion object {
        const val MODE_WORDS = 0
        const val MODE_ANYWHERE = 1
        const val MODE_NAMES = 2
    }

    /** Všechny skupiny musí platit; ve skupině stačí jedna z možností. */
    val groups: List<List<Term>>
    val excluded: List<Term>
    private val anywhere = mode != MODE_WORDS
    private val regexCache = HashMap<Term, Regex>()

    init {
        val g = ArrayList<MutableList<Term>>()
        val ex = ArrayList<Term>()
        var orNext = false
        for (m in Regex("(-?)\"([^\"]*)\"?|(\\S+)").findAll(raw)) {
            val neg: Boolean
            val text: String
            if (m.groups[2] != null) {
                neg = m.groupValues[1] == "-"
                text = m.groupValues[2]
            } else {
                val w = m.groupValues[3]
                if (w == "|" || w == "OR") {
                    orNext = true
                    continue
                }
                neg = w.length > 1 && w.startsWith("-")
                text = if (neg) w.substring(1) else w
            }
            val toks = TextFold.norm(text).split(' ').filter { it.isNotEmpty() }
            if (toks.isEmpty()) continue
            val t = Term(toks)
            if (neg) ex.add(t)
            else if (orNext && g.isNotEmpty()) g[g.size - 1].add(t)
            else g.add(mutableListOf(t))
            orNext = false
        }
        groups = g
        excluded = ex
    }

    val isEmpty: Boolean get() = groups.isEmpty()

    private fun find(t: Term, norm: String, out: MutableList<IntArray>, limit: Int) {
        if (!t.isPhrase) {
            val tok = t.tokens[0]
            var idx = norm.indexOf(tok)
            while (idx >= 0 && out.size < limit) {
                if (anywhere || idx == 0 || norm[idx - 1] == ' ') out.add(intArrayOf(idx, tok.length))
                idx = norm.indexOf(tok, idx + tok.length)
            }
        } else {
            val r = regexCache.getOrPut(t) {
                val body = t.tokens.joinToString(" +") { Regex.escape(it) }
                Regex(if (anywhere) body else "(?<![^ ])$body")
            }
            for (m in r.findAll(norm)) {
                if (out.size >= limit) break
                out.add(intArrayOf(m.range.first, m.range.last - m.range.first + 1))
            }
        }
    }

    private fun contains(t: Term, norm: String): Boolean {
        val tmp = ArrayList<IntArray>(1)
        find(t, norm, tmp, 1)
        return tmp.isNotEmpty()
    }

    /** Odpovídá soubor dotazu? (normalizovaný název a obsah) */
    fun matches(normName: String, normBody: String): Boolean =
        groups.all { g -> g.any { contains(it, normBody) || contains(it, normName) } } &&
            excluded.none { contains(it, normBody) || contains(it, normName) }

    /** Všechny výskyty hledaných slov, seřazené: [pozice, délka]. */
    fun findAll(norm: String, limit: Int = 50_000): List<IntArray> {
        val res = ArrayList<IntArray>()
        for (g in groups) for (t in g) find(t, norm, res, limit)
        res.sortBy { it[0] }
        return res
    }

    /** Dotaz pro fulltextový index SQLite (FTS4). OR má přednost před A ZÁROVEŇ. */
    fun ftsQuery(): String = groups.joinToString(" ") { g ->
        g.joinToString(" OR ") { t ->
            if (t.isPhrase) "\"" + t.tokens.joinToString(" ") + "*\"" else t.tokens[0] + "*"
        }
    }

    /** Podmínka pro režim „kdekoli v textu“ (hrubý výběr, přesně se ověří v matches). */
    fun sqlAnywhere(): Pair<String, Array<String>> {
        val args = ArrayList<String>()
        val cond = groups.joinToString(" AND ") { g ->
            "(" + g.joinToString(" OR ") { t ->
                "(" + t.tokens.joinToString(" AND ") { tok ->
                    args.add(tok)
                    args.add(tok)
                    "(instr(body, ?) > 0 OR instr(name, ?) > 0)"
                } + ")"
            } + ")"
        }
        return cond to args.toTypedArray()
    }
}
