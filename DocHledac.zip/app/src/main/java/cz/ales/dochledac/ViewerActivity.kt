package cz.ales.dochledac

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.format.DateFormat
import android.text.format.Formatter
import com.google.android.material.slider.Slider
import java.util.Date
import kotlin.math.roundToInt
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Náhled celého textu souboru. Text se zobrazuje po blocích (CHUNK řádků v jednom poli),
 * takže jde souvisle označit a kopírovat přes mnoho řádků; odkazy jsou klikací.
 */
class ViewerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_DOC = "doc"
        const val EXTRA_QUERY = "q"
        const val EXTRA_MODE = "mode"
        const val EXTRA_LINE = "line"
        const val CHUNK = 40
        const val CURRENT_HIT = 0xFFFF9800.toInt()
    }

    private val app get() = application as App
    private var doc: Doc? = null
    private var dt: DocText? = null
    private var adapter: ChunkAdapter? = null
    private var hits: List<IntArray> = emptyList()   // všechny výskyty [pozice, délka], seřazené
    private var idx = -1
    private var mode = Query.MODE_WORDS
    private var findJob: Job? = null
    private lateinit var list: RecyclerView
    private lateinit var counter: TextView
    private lateinit var find: EditText
    private lateinit var clearFind: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupScreen(R.layout.activity_viewer, true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        findViewById<View>(R.id.titleBox).setOnClickListener { toggleInfo() }
        val slider = findViewById<Slider>(R.id.sizeSlider)
        slider.value = app.prefs.viewerTextSize.coerceIn(10f, 30f).roundToInt().toFloat()
        slider.addOnChangeListener { _, value, fromUser -> if (fromUser) setTextSize(value) }
        list = findViewById(R.id.lines)
        counter = findViewById(R.id.counter)
        find = findViewById(R.id.find)
        clearFind = findViewById(R.id.clearFind)
        list.layoutManager = LinearLayoutManager(this)
        list.itemAnimator = null // bez prolínací animace – přepínání výsledků neposkakuje

        val id = intent.getLongExtra(EXTRA_DOC, -1)
        val q = savedInstanceState?.getString("q") ?: intent.getStringExtra(EXTRA_QUERY).orEmpty()
        val m = intent.getIntExtra(EXTRA_MODE, Query.MODE_WORDS)
        mode = if (m == Query.MODE_NAMES) Query.MODE_ANYWHERE else m
        val startLine = savedInstanceState?.getInt("line") ?: intent.getIntExtra(EXTRA_LINE, 0)
        find.setText(q)
        clearFind.visibility = if (q.isEmpty()) View.GONE else View.VISIBLE
        clearFind.setOnClickListener { find.setText("") }

        findViewById<View>(R.id.prev).setOnClickListener { step(-1) }
        findViewById<View>(R.id.next).setOnClickListener { step(1) }

        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.Default) {
                val d = Repo.doc(app, id) ?: return@withContext null
                d to DocText(Repo.loadText(app, id))
            }
            if (loaded == null) {
                finish()
                return@launch
            }
            show(loaded.first, loaded.second, startLine)
        }
    }

    private fun show(d: Doc, t: DocText, startLine: Int) {
        doc = d
        dt = t
        findViewById<TextView>(R.id.titleText).text = d.name
        findViewById<TextView>(R.id.infoName).text = d.name
        findViewById<TextView>(R.id.infoPath).text = d.path
        val date = DateFormat.getDateFormat(this).format(Date(d.mtime))
        findViewById<TextView>(R.id.infoMeta).text = getString(
            R.string.info_meta, d.ext.uppercase(), Formatter.formatShortFileSize(this, d.size), date,
            resources.getQuantityString(R.plurals.lines, t.lineCount, t.lineCount),
        )
        invalidateOptionsMenu()
        if (t.text.isEmpty()) {
            val msg = findViewById<TextView>(R.id.message)
            msg.visibility = View.VISIBLE
            msg.text = if (d.error != null) getString(R.string.viewer_read_error, d.error) else getString(R.string.viewer_no_text)
            findViewById<View>(R.id.findLayout).visibility = View.GONE
            return
        }
        val a = ChunkAdapter(t, app.prefs.viewerTextSize)
        adapter = a
        list.adapter = a
        find.doAfterTextChanged {
            clearFind.visibility = if (it.isNullOrEmpty()) View.GONE else View.VISIBLE
            scheduleFind(250, -1)
        }
        scheduleFind(0, startLine)
    }

    private fun scheduleFind(delayMs: Long, anchorLine: Int) {
        val t = dt ?: return
        val a = adapter ?: return
        findJob?.cancel()
        val raw = find.text?.toString().orEmpty()
        val m = mode
        val stem = app.prefs.stem
        findJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            val found = withContext(Dispatchers.Default) {
                val q = Query(raw, m, stem)
                if (q.isEmpty) emptyList() else q.findAll(t.norm)
            }
            val byLine = HashMap<Int, MutableList<IntArray>>()
            for (h in found) byLine.getOrPut(t.lineOf(h[0])) { ArrayList() }.add(h)
            hits = found
            a.hits = byLine
            a.current = -1
            a.notifyDataSetChanged()
            val ref = if (anchorLine >= 0) anchorLine else firstVisibleLine()
            if (found.isEmpty()) {
                idx = -1
                counter.text = if (raw.isBlank()) "" else getString(R.string.viewer_no_hits)
                if (anchorLine >= 0) scrollToLine(anchorLine)
            } else {
                val i = found.indexOfFirst { t.lineOf(it[0]) >= ref }
                idx = if (i < 0) found.size - 1 else i
                goTo()
            }
        }
    }

    private fun step(d: Int) {
        if (hits.isEmpty()) return
        idx = (idx + d + hits.size) % hits.size
        goTo()
    }

    private fun goTo() {
        val a = adapter ?: return
        val t = dt ?: return
        if (idx < 0 || idx >= hits.size) return
        val pos = hits[idx][0]
        val oldChunk = if (a.current >= 0) t.lineOf(a.current) / CHUNK else -1
        val newChunk = t.lineOf(pos) / CHUNK
        a.current = pos
        if (oldChunk >= 0 && oldChunk != newChunk) a.notifyItemChanged(oldChunk)
        a.notifyItemChanged(newChunk)
        counter.text = "${idx + 1} / ${hits.size}"
        scrollToPos(pos)
    }

    /** Posune seznam tak, aby daná pozice v textu byla ve třetině výšky obrazovky. */
    private fun scrollToPos(pos: Int) {
        val t = dt ?: return
        val chunk = t.lineOf(pos) / CHUNK
        val lm = list.layoutManager as LinearLayoutManager
        lm.scrollToPositionWithOffset(chunk, 0)
        list.post {
            val vh = list.findViewHolderForAdapterPosition(chunk) as? ChunkAdapter.VH ?: return@post
            val layout = vh.text.layout ?: return@post
            val off = (pos - t.lineStart(chunk * CHUNK)).coerceIn(0, vh.text.text.length)
            val y = vh.itemView.top + vh.text.top + layout.getLineTop(layout.getLineForOffset(off))
            list.scrollBy(0, y - list.height / 3)
        }
    }

    private fun scrollToLine(line: Int) {
        val t = dt ?: return
        scrollToPos(t.lineStart(line.coerceIn(0, t.lineCount - 1)))
    }

    private fun firstVisibleLine(): Int {
        val lm = list.layoutManager as LinearLayoutManager
        return lm.findFirstVisibleItemPosition().coerceAtLeast(0) * CHUNK
    }

    private fun currentLine(): Int {
        val t = dt ?: return 0
        return if (idx >= 0 && idx < hits.size) t.lineOf(hits[idx][0]) else firstVisibleLine()
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        if (Build.VERSION.SDK_INT < 33) Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
    }

    /** Výběr delšího úseku (přes hranice bloků): text kolem aktuálního místa v jednom poli. */
    private fun selectBlock() {
        val t = dt ?: return
        if (t.text.isEmpty()) return
        val c = currentLine().coerceIn(0, t.lineCount - 1)
        val from = (c - 30).coerceAtLeast(0)
        val to = (c + 300).coerceAtMost(t.lineCount - 1)
        val text = t.text.substring(t.lineStart(from), t.lineEnd(to)).replace('\u000C', '\n')
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setText(text)
            setTextIsSelectable(true)
            textSize = app.prefs.viewerTextSize
            val p = (20 * dp).toInt()
            setPadding(p, (8 * dp).toInt(), p, p)
        }
        val sv = ScrollView(this)
        sv.addView(tv)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.select_title)
            .setView(sv)
            .setPositiveButton(R.string.copy_all) { _, _ -> copy(text) }
            .setNegativeButton(R.string.close, null)
            .show()
        val offset = t.lineStart(c) - t.lineStart(from)
        tv.post {
            val layout = tv.layout ?: return@post
            sv.scrollTo(0, layout.getLineTop(layout.getLineForOffset(offset.coerceIn(0, text.length))))
        }
    }

    private fun setTextSize(size: Float) {
        val s = size.coerceIn(10f, 30f)
        if (s == app.prefs.viewerTextSize) return
        app.prefs.viewerTextSize = s
        val a = adapter ?: return
        a.textSize = s
        a.notifyDataSetChanged()
    }

    /** Klepnutí na název nebo šipku rozbalí/sbalí panel s informacemi o souboru. */
    private fun toggleInfo() {
        val panel = findViewById<View>(R.id.infoPanel)
        val open = panel.visibility != View.VISIBLE
        panel.visibility = if (open) View.VISIBLE else View.GONE
        findViewById<View>(R.id.titleArrow).animate().rotation(if (open) 180f else 0f).setDuration(150).start()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("q", find.text?.toString().orEmpty())
        if (adapter != null) outState.putInt("line", currentLine())
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_viewer, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val d = doc
        menu.findItem(R.id.action_page)?.isVisible = d != null && Formats.hasVisualPreview(d.ext)
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_open -> {
            doc?.let { AppPicker.openDefault(this, it) }
            true
        }
        R.id.action_open_with -> {
            doc?.let { AppPicker.pick(this, it, false) }
            true
        }
        R.id.action_select -> {
            selectBlock()
            true
        }
        R.id.action_page -> {
            val d = doc
            val t = dt
            if (d != null) {
                val page = if (t != null && t.hasPages && adapter != null) t.pageOf(currentLine()) else 1
                startActivity(
                    Intent(this, PageActivity::class.java)
                        .putExtra(PageActivity.EXTRA_DOC, d.id)
                        .putExtra(PageActivity.EXTRA_PAGE, page.coerceAtLeast(1))
                )
            }
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    /** Jeden prvek seznamu = blok CHUNK řádků; vlevo čísla řádků zarovnaná i u zalomených řádků. */
    class ChunkAdapter(private val dt: DocText, var textSize: Float) : RecyclerView.Adapter<ChunkAdapter.VH>() {
        var hits: Map<Int, List<IntArray>> = emptyMap()
        var current = -1 // pozice aktuálního výskytu v textu

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val num: TextView = v.findViewById(R.id.num)
            val text: TextView = v.findViewById(R.id.text)
        }

        override fun getItemCount(): Int = (dt.lineCount + CHUNK - 1) / CHUNK

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_viewer_line, parent, false))

        override fun onViewAttachedToWindow(holder: VH) {
            super.onViewAttachedToWindow(holder)
            // známá oprava: po recyklaci by jinak přestalo jít označovat
            holder.text.isEnabled = false
            holder.text.isEnabled = true
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val first = position * CHUNK
            val last = minOf(first + CHUNK, dt.lineCount) - 1
            val s = dt.lineStart(first)
            val e = dt.lineEnd(last).coerceAtLeast(s)
            val sb = SpannableStringBuilder(dt.text, s, e)
            // stejná délka textu → pozice výskytů sedí: konec stránky = nový řádek, \r = neviditelný znak
            for (i in 0 until sb.length) {
                val ch = sb[i]
                if (ch == '\u000C') sb.replace(i, i + 1, "\n")
                else if (ch == '\r') sb.replace(i, i + 1, "​")
            }
            for (line in first..last) {
                val hl = hits[line] ?: continue
                for (h in hl) {
                    val a = h[0] - s
                    val b = minOf(h[0] + h[1] - s, sb.length)
                    if (a < 0 || a >= b) continue
                    val color = if (h[0] == current) CURRENT_HIT else Highlight.HIT_COLOR
                    sb.setSpan(BackgroundColorSpan(color), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(StyleSpan(Typeface.BOLD), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            holder.text.textSize = textSize
            holder.num.textSize = textSize
            holder.text.text = sb // odkazy podtrhne a zprovozní android:autoLink v layoutu
            holder.num.text = ""
            holder.text.post { buildGutter(holder, position, first, last, s) }
        }

        /** Čísla řádků: každé číslo + tolik prázdných řádků, na kolik se řádek zalomil. */
        private fun buildGutter(holder: VH, position: Int, first: Int, last: Int, s: Int) {
            if (holder.bindingAdapterPosition != position) return
            val layout = holder.text.layout ?: return
            val sb = StringBuilder()
            for (line in first..last) {
                val v0 = layout.getLineForOffset((dt.lineStart(line) - s).coerceIn(0, holder.text.text.length))
                val v1 = if (line < last) layout.getLineForOffset((dt.lineStart(line + 1) - s).coerceIn(0, holder.text.text.length))
                else layout.lineCount
                sb.append(line + 1)
                repeat((v1 - v0).coerceAtLeast(1)) { sb.append('\n') }
            }
            holder.num.text = sb
        }
    }
}
