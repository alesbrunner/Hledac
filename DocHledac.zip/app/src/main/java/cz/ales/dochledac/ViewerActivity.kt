package cz.ales.dochledac

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.widget.EditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Náhled celého textu souboru: zvýraznění, skákání mezi výskyty, hledání v souboru. */
class ViewerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_DOC = "doc"
        const val EXTRA_QUERY = "q"
        const val EXTRA_MODE = "mode"
        const val EXTRA_LINE = "line"
    }

    private val app get() = application as App
    private var doc: Doc? = null
    private var dt: DocText? = null
    private var locator: Locator? = null
    private var adapter: LinesAdapter? = null
    private var hitLines = IntArray(0)
    private var idx = -1
    private var mode = Query.MODE_WORDS
    private var findJob: Job? = null
    private lateinit var list: RecyclerView
    private lateinit var counter: TextView
    private lateinit var find: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupScreen(R.layout.activity_viewer, true)
        supportActionBar?.title = ""
        list = findViewById(R.id.lines)
        counter = findViewById(R.id.counter)
        find = findViewById(R.id.find)
        list.layoutManager = LinearLayoutManager(this)

        val id = intent.getLongExtra(EXTRA_DOC, -1)
        val q = savedInstanceState?.getString("q") ?: intent.getStringExtra(EXTRA_QUERY).orEmpty()
        val m = intent.getIntExtra(EXTRA_MODE, Query.MODE_WORDS)
        mode = if (m == Query.MODE_NAMES) Query.MODE_ANYWHERE else m
        val startLine = savedInstanceState?.getInt("line") ?: intent.getIntExtra(EXTRA_LINE, 0)
        find.setText(q)

        findViewById<View>(R.id.prev).setOnClickListener { step(-1) }
        findViewById<View>(R.id.next).setOnClickListener { step(1) }

        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.Default) {
                val d = Repo.doc(app, id) ?: return@withContext null
                val t = DocText(Repo.loadText(app, id))
                Triple(d, t, Locator(app, t, d.ext))
            }
            if (loaded == null) {
                finish()
                return@launch
            }
            show(loaded.first, loaded.second, loaded.third, startLine)
        }
    }

    private fun show(d: Doc, t: DocText, loc: Locator, startLine: Int) {
        doc = d
        dt = t
        locator = loc
        supportActionBar?.title = d.name
        supportActionBar?.subtitle = d.path
        invalidateOptionsMenu()
        if (t.text.isEmpty()) {
            val msg = findViewById<TextView>(R.id.message)
            msg.visibility = View.VISIBLE
            msg.text = if (d.error != null) getString(R.string.viewer_read_error, d.error) else getString(R.string.viewer_no_text)
            findViewById<View>(R.id.findLayout).visibility = View.GONE
            return
        }
        val a = LinesAdapter(t, app.prefs.viewerTextSize)
        adapter = a
        list.adapter = a
        find.doAfterTextChanged { scheduleFind(250, -1) }
        scheduleFind(0, startLine)
    }

    private fun scheduleFind(delayMs: Long, anchor: Int) {
        val t = dt ?: return
        val a = adapter ?: return
        findJob?.cancel()
        val raw = find.text?.toString().orEmpty()
        val m = mode
        findJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            val map = withContext(Dispatchers.Default) {
                val q = Query(raw, m)
                val res = HashMap<Int, MutableList<IntArray>>()
                if (!q.isEmpty) for (h in q.findAll(t.norm)) res.getOrPut(t.lineOf(h[0])) { ArrayList() }.add(h)
                res
            }
            a.hits = map
            hitLines = map.keys.sorted().toIntArray()
            a.current = -1
            a.notifyDataSetChanged()
            val ref = if (anchor >= 0) anchor
            else (list.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition().coerceAtLeast(0)
            if (hitLines.isEmpty()) {
                idx = -1
                counter.text = if (raw.isBlank()) "" else getString(R.string.viewer_no_hits)
                if (anchor >= 0) list.scrollToPosition(anchor.coerceIn(0, t.lineCount - 1))
            } else {
                val i = hitLines.indexOfFirst { it >= ref }
                idx = if (i < 0) hitLines.size - 1 else i
                goTo()
            }
        }
    }

    private fun step(d: Int) {
        if (hitLines.isEmpty()) return
        idx = (idx + d + hitLines.size) % hitLines.size
        goTo()
    }

    private fun goTo() {
        val a = adapter ?: return
        if (idx < 0 || idx >= hitLines.size) return
        val line = hitLines[idx]
        val old = a.current
        a.current = line
        if (old >= 0) a.notifyItemChanged(old)
        a.notifyItemChanged(line)
        list.post {
            (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(line, list.height / 3)
        }
        counter.text = "${idx + 1} / ${hitLines.size}"
    }

    private fun currentLine(): Int =
        if (idx >= 0 && idx < hitLines.size) hitLines[idx]
        else (list.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition().coerceAtLeast(0)

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("text", text))
        if (Build.VERSION.SDK_INT < 33) Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
    }

    /** Výběr přes více řádků: úsek kolem aktuálního místa v jednom označitelném textu. */
    private fun selectBlock() {
        val t = dt ?: return
        if (t.text.isEmpty()) return
        val c = currentLine().coerceIn(0, t.lineCount - 1)
        val from = (c - 30).coerceAtLeast(0)
        val to = (c + 300).coerceAtMost(t.lineCount - 1)
        val text = t.text.substring(t.lineStart(from), t.lineEnd(to)).replace('\u000C', '\n')
        val dp = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setText(text)
            setTextIsSelectable(true)
            textSize = app.prefs.viewerTextSize
            val p = (20 * dp).toInt()
            setPadding(p, (8 * dp).toInt(), p, p)
        }
        val sv = ScrollView(this)
        sv.addView(tv)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.select_title)
            .setView(sv)
            .setPositiveButton(R.string.copy_all) { _, _ -> copy(text) }
            .setNegativeButton(R.string.close, null)
            .show()
        val offset = t.lineStart(c) - t.lineStart(from)
        tv.post {
            val layout = tv.layout ?: return@post
            sv.scrollTo(0, layout.getLineTop(layout.getLineForOffset(offset.coerceIn(0, text.length))))
        }
    }

    private fun changeTextSize(delta: Float) {
        val a = adapter ?: return
        val s = (app.prefs.viewerTextSize + delta).coerceIn(10f, 30f)
        app.prefs.viewerTextSize = s
        a.textSize = s
        a.notifyDataSetChanged()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("q", find.text?.toString().orEmpty())
        if (adapter != null) outState.putInt("line", currentLine())
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_viewer, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val d = doc
        menu.findItem(R.id.action_page)?.isVisible = d != null && Formats.hasVisualPreview(d.ext)
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_open -> {
            doc?.let { openExternal(this, it, false) }
            true
        }
        R.id.action_open_with -> {
            doc?.let { openExternal(this, it, true) }
            true
        }
        R.id.action_select -> {
            selectBlock()
            true
        }
        R.id.action_bigger -> {
            changeTextSize(2f)
            true
        }
        R.id.action_smaller -> {
            changeTextSize(-2f)
            true
        }
        R.id.action_page -> {
            val d = doc
            val t = dt
            if (d != null) {
                val page = if (t != null && t.hasPages && adapter != null) t.pageOf(currentLine()) else 1
                startActivity(
                    Intent(this, PageActivity::class.java)
                        .putExtra(PageActivity.EXTRA_DOC, d.id)
                        .putExtra(PageActivity.EXTRA_PAGE, page.coerceAtLeast(1))
                )
            }
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    private class LinesAdapter(
        private val dt: DocText,
        var textSize: Float,
    ) : RecyclerView.Adapter<LinesAdapter.VH>() {
        var hits: Map<Int, List<IntArray>> = emptyMap()
        var current = -1

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val num: TextView = v.findViewById(R.id.num)
            val text: TextView = v.findViewById(R.id.text)
        }

        override fun getItemCount(): Int = dt.lineCount

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val vh = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_viewer_line, parent, false))
            vh.text.setTextIsSelectable(true) // podržením označíš text a zkopíruješ
            return vh
        }

        override fun onViewAttachedToWindow(holder: VH) {
            super.onViewAttachedToWindow(holder)
            // známá oprava: po recyklaci řádku by jinak přestalo jít označovat
            holder.text.isEnabled = false
            holder.text.isEnabled = true
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.num.text = (position + 1).toString()
            holder.num.textSize = textSize * 0.75f
            holder.text.textSize = textSize
            val s = dt.lineStart(position)
            val e = dt.lineEnd(position)
            val h = hits[position]
            holder.text.text = if (h == null) dt.text.substring(s, e) else Highlight.build(dt.text, s, e, h, Int.MAX_VALUE)
            holder.itemView.setBackgroundColor(if (position == current) Highlight.CURRENT_LINE else Color.TRANSPARENT)
        }
    }
}
