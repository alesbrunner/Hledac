package cz.ales.dochledac

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar

fun Context.qty(res: Int, n: Int): String = resources.getQuantityString(res, n, n)

fun formatChars(ctx: Context, n: Long): String = when {
    n >= 1_000_000 -> ctx.getString(R.string.chars_millions, n / 1_000_000.0)
    n >= 1_000 -> ctx.getString(R.string.chars_thousands, (n / 1000).toInt())
    else -> n.toString()
}

fun openExternal(ctx: Context, doc: Doc) {
    val i = Intent(Intent.ACTION_VIEW)
        .setDataAndType(Uri.parse(doc.uri), Formats.mime(doc.ext))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        ctx.startActivity(Intent.createChooser(i, ctx.getString(R.string.open_with)))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, R.string.no_app, Toast.LENGTH_SHORT).show()
    }
}

fun Activity.hideKeyboard() {
    val v = currentFocus ?: return
    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
}

/**
 * Společné nastavení obrazovky: kreslení až k okrajům (vyžadováno od Androidu 15),
 * odsazení od systémových lišt a klávesnice, horní lišta.
 */
fun AppCompatActivity.setupScreen(layout: Int, up: Boolean) {
    enableEdgeToEdge()
    setContentView(layout)
    val root = findViewById<View>(R.id.root)
    ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
        val b = insets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
        )
        v.setPadding(b.left, b.top, b.right, b.bottom)
        WindowInsetsCompat.CONSUMED
    }
    setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
    supportActionBar?.setDisplayHomeAsUpEnabled(up)
}

object Paths {
    /** "primary:Documents/Knihy" -> "Interní/Documents/Knihy" */
    fun labelOfDocId(ctx: Context, id: String): String {
        val vol = id.substringBefore(':')
        val rest = id.substringAfter(':', "")
        val v = if (vol == "primary") ctx.getString(R.string.storage_internal) else ctx.getString(R.string.storage_sd, vol)
        return if (rest.isEmpty()) v else "$v/$rest"
    }

    fun label(ctx: Context, tree: Uri): String = try {
        labelOfDocId(ctx, DocumentsContract.getTreeDocumentId(tree))
    } catch (e: Exception) {
        tree.toString()
    }
}
